import java.applet.Applet;
import java.awt.event.*;
import java.awt.*;
import java.awt.geom.*;
import java.io.*;



public class ControlPanel {
    ListenSquare[] L=new ListenSquare[30];
    String[] S=new String[30];
    int[] state=new int[30];
    int mode=0;
    Color[] C=new Color[10];
    int count;
    String INFO;
    int INFO_LIVE;
 



    public ControlPanel() {}



    public ControlPanel(Color[] C,String S[], int state[],int count) {
	this.C=C;
	this.S=S;
	this.state=state;
	this.mode=mode;
	this.count=count;
	for(int i=0;i<count;++i) {
            L[i]=new ListenSquare(0,0,12,12,Color.white);
	    if(state[i]==1) L[i].on=1;
	}
	 L[20]=new ListenSquare(0,0,0,0);
	INFO="";
    }


    public ControlPanel(Color[] C,String S[], int state[],int count,int mode) {
	this.C=C;
	this.S=S;
	this.state=state;
	this.mode=mode;
	this.count=count;
	for(int i=0;i<count;++i) L[i]=new ListenSquare(0,0,12,12,Color.white);
	L[mode].on=1;
	L[20]=new ListenSquare(0,0,0,0);
	INFO="";
    }

    public ControlPanel(Color[] C,String S[], int state[],int count,Color[] COL) {
	this.C=C;
	this.S=S;
	this.state=state;
	this.mode=mode;
	this.count=count;
	for(int i=0;i<count;++i) L[i]=new ListenSquare(0,0,12,12,Color.white);
	for(int i=0;i<count;++i) {L[i].on=1;L[i].C=COL[i];}	
        L[20]=new ListenSquare(0,0,0,0);
	INFO="";
    }






    public int switchMode(Point X) {
	int test=-1;
	for(int i=0;i<count;++i) {
	    if(L[i].inside(X)==1) test=i;
	}
	if(test!=-1) {
	    for(int i=0;i<count;++i) {
		L[i].on=0;
	    }
	    L[test].on=1;
	    mode=test;
	}	

        if(L[20].inside(X)==1) test=20;
	return(test);
    }



    public void forceMode(int test) {
	for(int i=0;i<count;++i) {
		L[i].on=0;
	}
	L[test].on=1;
	mode=test;
    }






    public void turnOff() {
       for(int i=0;i<count;++i) {
	  L[i].on=0;
       }
       mode=-1;
    }






    public int toggle(Point X) {
	int test=-1;
	for(int i=0;i<count;++i) {
	    if(L[i].inside(X)==1) {test=i; L[i].on=1-L[i].on;}
	}
	if(L[20].inside(X)==1) test=20;
	return(test);
    }




    public int getValue(Point X) {
	int test=-1;
	for(int i=0;i<count;++i) {
	    if(L[i].inside(X)==1) {test=i;}
	}	
        if(L[20].inside(X)==1) test=20;
	return(test);
    }


    public int recolor(Point X,Color CC) {
	int test=-1;
	for(int i=0;i<count;++i) {
	    if(L[i].inside(X)==1) {test=i;L[i].C=CC;}
	}	
        if(L[20].inside(X)==1) test=20;
	return(test);
    }


    public void render(Graphics2D g,int x,int y,int w) {

	//the frame
	g.setColor(C[0]);  //background color
	g.fillRect(x,y,w,20+15*count);
	g.setColor(C[1]);  //background color
	g.drawRect(x,y,w,20+15*count);

	//the title  
        g.setFont(new Font("Helvetica",Font.PLAIN,10));
	g.setColor(C[2]);
	g.drawString(S[count],x+3,y+12);

	//the words
	g.setColor(C[3]);   //textcolor
	for(int i=0;i<count;++i) {
	    g.drawString(S[i],x+20,y+15*i+30);
	}

	//the boxes
	for(int i=0;i<count;++i) {
	    L[i].x=x+3;
	    L[i].y=y+20+15*i;
	}
	for(int i=0;i<count;++i) L[i].render2(g,C[4]);

	L[20].x=x+w-12;
	L[20].y=y;
	L[20].w=12;
	L[20].h=12;
	L[20].infoRender(g);

    }



    public void render2(Graphics2D g,int x,int y,int w) {

	//the frame
	g.setColor(C[0]);  //background color
	g.fillRect(x,y,w,20+15*count);
	g.setColor(C[1]);  //background color
	g.drawRect(x,y,w,20+15*count);

	//the title  
        g.setFont(new Font("Helvetica",Font.PLAIN,10));
	g.setColor(C[2]);
	g.drawString(S[count],x+3,y+12);

	//the words
	g.setColor(C[3]);   //textcolor
	for(int i=0;i<count;++i) {
	    g.drawString(S[i],x+20,y+15*i+30);
	}

	//the boxes
	for(int i=0;i<count;++i) {
	    L[i].x=x+3;
	    L[i].y=y+20+15*i;
	}
	for(int i=0;i<count;++i) L[i].render(g,L[i].C);

	L[20].x=x+w-12;
	L[20].y=y;
	L[20].w=12;
	L[20].h=12;
	L[20].infoRender(g);
    }







}

