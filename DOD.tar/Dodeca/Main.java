import java.applet.Applet;
import java.awt.*;
import java.applet.*;
import java.math.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.*;
import java.util.*;


public class Main extends Applet {
    ControlCanvas C;
    PopupPictureCanvas PP;
    Manager M;

    public static void main(String[] args) {  
        Main a=new Main();
        Frame F=new Frame();
	a.setBackground(Color.black);
        a.init();
	F.add(a);
	F.pack();
	F.addWindowListener(new WinList(F));
	F.setVisible(true);
    }


    public void init() { 
	M=new Manager();
	PP=new PopupPictureCanvas();
	C=new ControlCanvas();
	C.setSize(670,290);
	PP.P.M=M;
	M.P=PP.P;
	M.C=C;
	C.M=M;
	add(C);
	M.C.POP=new PopupManager(M,590,60);
    } 
}

