import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.awt.geom.*;


public class Output {
    FileOutputStream FS;
    String S;

    public Output(String S) {
	this.S=S;
	try {FS=new FileOutputStream(S);}
	catch(IOException e) {}
    }

    public void write(String S) {
	PrintStream PS=new PrintStream(FS);
	PS.print(S);
    }

    public void writeln(String S) {
	PrintStream PS=new PrintStream(FS);
	PS.println(S);
    }

}
