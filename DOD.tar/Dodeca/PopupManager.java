import java.applet.Applet;
import java.awt.*;
import java.applet.*;
import java.math.*;
import java.awt.event.*;
import java.awt.geom.*;


public class PopupManager {
    Manager M;
    int X,Y;
    ListenSquare FORMULA,INFO;

    public PopupManager(Manager m,int x,int y) {
	M=m;
	this.X=x;
	this.Y=y;
	FORMULA=new ListenSquare(X,Y+25,75,25);
	INFO=new ListenSquare(X,Y+50,75,25);
    }


    public void render(Graphics2D g) {
        Color[] COL1={new Color(150,0,0),new Color(150,0,0)};
	g.setColor(Color.black);
	g.fillRect(X,Y,75,75);
	g.setColor(Color.white);
	g.drawRect(X,Y,75,75);
	g.setFont(new Font("Helvetica",Font.PLAIN,16));
	g.drawString("popups",X+5,Y+18);
	FORMULA.render(g,"formulas",15,5,COL1[0]);
	INFO.render(g,"info",15,5,COL1[1]);
    }


    public void process(Point X) {

	if(FORMULA.inside(X)==1) {
	    PopupFormulaCanvas PF=new PopupFormulaCanvas();
	    PF.X.M=this.M;
	    M.X=PF.X;
	}

	if(INFO.inside(X)==1) {
	    PopupDocumentCanvas PD=new PopupDocumentCanvas();
	    PD.D.M=this.M;
	    M.D=PD.D;

	}

    }


}

