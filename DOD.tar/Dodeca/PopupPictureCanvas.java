import java.awt.*;

public class PopupPictureCanvas extends PopupPanel {
    PictureCanvas P;

    public PopupPictureCanvas() {
        super("Picture Window", 1080,1080);
        P=new PictureCanvas();
        P.setSize(1080,1080);
        add(P);
        P.setBackground(Color.black);
        setVisible(true);
        F.setSize(1080,1080);
    }

    public void resized(int w, int h){
	try {P.setSize(w,h);}
	catch(Exception e) {}
    }
    
}
