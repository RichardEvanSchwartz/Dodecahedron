import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.geom.*;
import java.math.*;


public class ChainList {


    public static Chain reflect09(Chain c) {
	int[] b=reflect09(c.B);
	return Chain.setChain(b);
    }
			
    public static int[] reflect09(int[] b) {
	int[] c=new int[b.length];
	for(int i=0;i<b.length;++i) c[i]=reflect09(b[i]);
	return c;
    }
    			
    public static int reflect09(int b) {
	int[] n={0,2,1,5,4,3,7,6,10,9,8,11};
	return n[b];
    }

    public static Chain[] setChain() {
	Chain[] CH=new Chain[500];
	int count=0;

	for(int N=1;N<6;++N) {
	  int LIM=(int)(Math.pow(5,N));
	  for(int i=0;i<LIM;++i) {
	    int[] a=Chain.base5(N,i);
	    int[] b=Chain.convert(a);
	    
	    boolean test2=newSequence(b,CH,count);
	    if((test2==true)&&(Chain.isGood(b)==true)) {
		Chain candidate=Chain.setChain(b);
		boolean test=SegmentTest.main(candidate);
		if(test==true) {
		    CH[count]=candidate;
		  ++count;
		}
	    }
	  }
	}

	System.out.println("count "+count);
	Chain[] CH2=new Chain[count];
	for(int i=0;i<count;++i) CH2[i]=CH[i];
	return CH2;
    }

    public static Chain[] merge(Chain[] CH1,Chain[] CH2) {
	int a1=CH1.length;
	int a2=CH2.length;
	Chain[] CH=new Chain[a1+a2];
	int count=0;
	for(int i=0;i<a1;++i) {
	    CH[count]=CH1[i];
	    ++count;
	}
	for(int i=0;i<a2;++i) {
	    CH[count]=CH2[i];
	    ++count;
	}
	return CH;
    }

    public static void swap(Chain[] CH,int a,int b) {
	Chain X=Chain.setChain(CH[a].B);
	CH[a]=Chain.setChain(CH[b].B);
	CH[b]=Chain.setChain(X.B);
    }

    

    public static Chain[] prune(int[] good,Chain[] CH) {
	int count=0;
	Chain[] CH2=new Chain[good.length];
	for(int i=0;i<good.length;++i) {
	    CH2[count]=Chain.setChain(CH[good[i]].B);
	    ++count;
	}
	return CH2;

    }


    public static Chain[] weedOutBilateral(Chain[] CH) {
	int count=0;
	Chain[] CH2=new Chain[CH.length];
	for(int i=0;i<CH.length;++i) {
            boolean test=true;
	    if(CH[i].B[0]==1) test=false;
	    if(CH[i].B[0]==5) test=false;
	    if((CH[i].B[0]==4)&&(CH[i].B[1]==6)) test=false;
	    if((CH[i].B[0]==4)&&(CH[i].B[1]==5)) test=false;
	    if(test==true) {
		CH2[count]=Chain.setChain(CH[i].B);
		++count;
	    }
	}
	Chain[] CH3=new Chain[count];
	for(int i=0;i<count;++i) CH3[i]=Chain.setChain(CH2[i].B);
	return CH3;
    }

    


    
    /**This weeds out redundancies*/

    public static boolean newSequence(int[] b,Chain[] CH,int count) {
	if(b==null) return false;
	for(int i=0;i<count;++i) {
	    if(ListHelp.match(b,CH[i].B)==true) return false;
	}
	return true;
    }
    
}


