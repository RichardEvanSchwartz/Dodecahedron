import java.applet.Applet;
import java.awt.*;
import java.applet.*;
import java.math.*;


public class Manager  {
    PictureCanvas P0;
    ControlCanvas C;
    
    public Manager() {
    }


    public void repaint() {
	P0.repaint();
	C.repaint();
    }



}

    

