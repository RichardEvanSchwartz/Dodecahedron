import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.geom.*;
import java.math.*;


public class ChainList {


    public static Chain reflect09(Chain c) {
	int[] b=reflect09(c.B);
	return Chain.setChain(b);
    }
			
    public static int[] reflect09(int[] b) {
	int[] c=new int[b.length];
	for(int i=0;i<b.length;++i) c[i]=reflect09(b[i]);
	return c;
    }
    			
    public static int reflect09(int b) {
	int[] n={0,2,1,5,4,3,7,6,10,9,8,11};
	return n[b];
    }
    


    public static Chain[] setChainGood() {
	Chain[] CH=setChainShort();
	int[] good={1,4,5,6,7,10,11,0,2,3,8,9,15,12};
	Chain[] CH2=prune(good,CH);
	return CH2;
    }


    public static Chain[] setChainBad() {
	Chain[] CH1=setChainShort();
	int[] good={13,14,16,17,18,19,20,21,22,23,24,25};
	Chain[] CH2=prune(good,CH1);
	Chain[] CH3=setChainLong();
	Chain[] CH4=merge(CH2,CH3);
	CH4=weedOutBilateral(CH4);
	swap(CH4,11,17);
	swap(CH4,12,18);
	swap(CH4,14,15);
	swap(CH4,14,11);
	swap(CH4,13,2);
	swap(CH4,12,0);
	swap(CH4,11,3);
	swap(CH4,3,1);
	CH4[0]=reflect09(CH4[0]);
	CH4[12]=reflect09(CH4[12]);
	CH4[14]=reflect09(CH4[14]);
	CH4[16]=reflect09(CH4[16]);

	
	return CH4;
    }


    /**These chains do not reach the top*/

    public static Chain[] setChainShort() {
	Chain[] CH=new Chain[50];
	int count=0;
	int max=0;
	int max2=0;

	for(int N=2;N<8;++N) {
	  int LIM=(int)(Math.pow(5,N));
	  for(int i=0;i<LIM;++i) {
	    int[] a=Chain.base5(N,i);
	    int[] b=Chain.convert(a);
	    if(max2<b.length) max2=b.length;

	    if(Chain.isGoodShort(b)==true) {
		Chain candidate=Chain.setChain(b);
		boolean test=SegmentTest.main(candidate);
		if(test==true) {
		    if(max<candidate.B.length) max=candidate.B.length;
		    CH[count]=candidate;
		  ++count;
		}
	    }
	  }
	}

	System.out.println("count "+count);
	System.out.println("max length "+max);
	System.out.println("max length tried "+max2);
	Chain[] CH2=new Chain[count];
	for(int i=0;i<count;++i) CH2[i]=CH[i];
	return CH2;
    }


    /**these chains reach the top*/

    public static Chain[] setChainLong() {
	Chain[] CH=new Chain[2000];
	int count=0;
        int max=0;
	for(int i=0;i<390635;++i) {
	    int[] a=Chain.base5(8,i);
	    int[] b=Chain.convert(a);
	    b=Chain.trim(b);
	    boolean test=newSequence(b,CH,count);

            if((test==true)&&(Chain.isGoodLong(b)==true)) {
                if(max<b.length) max=b.length;
	        Chain candidate=Chain.setChain(b);
		test=SegmentTest.main(candidate);
		if(test==true) {
		  CH[count]=candidate;
		  ++count;
		}
	    }
	}
        System.out.println("long count "+count);
        System.out.println("max length "+max);
	Chain[] CH2=new Chain[count];
	for(int i=0;i<count;++i) CH2[i]=CH[i];
	return CH2;
    }


    public static Chain[] merge(Chain[] CH1,Chain[] CH2) {
	int a1=CH1.length;
	int a2=CH2.length;
	Chain[] CH=new Chain[a1+a2];
	int count=0;
	for(int i=0;i<a1;++i) {
	    CH[count]=CH1[i];
	    ++count;
	}
	for(int i=0;i<a2;++i) {
	    CH[count]=CH2[i];
	    ++count;
	}
	return CH;
    }

    public static void swap(Chain[] CH,int a,int b) {
	Chain X=Chain.setChain(CH[a].B);
	CH[a]=Chain.setChain(CH[b].B);
	CH[b]=Chain.setChain(X.B);
    }

    

    public static Chain[] prune(int[] good,Chain[] CH) {
	int count=0;
	Chain[] CH2=new Chain[good.length];
	for(int i=0;i<good.length;++i) {
	    CH2[count]=Chain.setChain(CH[good[i]].B);
	    ++count;
	}
	return CH2;

    }


    public static Chain[] weedOutBilateral(Chain[] CH) {
	int count=0;
	Chain[] CH2=new Chain[CH.length];
	for(int i=0;i<CH.length;++i) {
            boolean test=true;
	    if(CH[i].B[0]==1) test=false;
	    if(CH[i].B[0]==5) test=false;
	    if((CH[i].B[0]==4)&&(CH[i].B[1]==6)) test=false;
	    if((CH[i].B[0]==4)&&(CH[i].B[1]==5)) test=false;
	    if(test==true) {
		CH2[count]=Chain.setChain(CH[i].B);
		++count;
	    }
	}
	Chain[] CH3=new Chain[count];
	for(int i=0;i<count;++i) CH3[i]=Chain.setChain(CH2[i].B);
	return CH3;
    }

    


    
    /**This weeds out redundancies*/

    public static boolean newSequence(int[] b,Chain[] CH,int count) {
	if(b==null) return false;
	for(int i=0;i<count;++i) {
	    if(ListHelp.match(b,CH[i].B)==true) return false;
	}
	return true;
    }
    
}


