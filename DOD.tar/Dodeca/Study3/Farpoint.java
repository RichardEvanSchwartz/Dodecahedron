import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.math.*;


public class Farpoint {

    public static int[] getTriple(Complex z) {
	Path2D.Double p=new Path2D.Double();
	int k=DecagonCombinatorics.stateNumber(z);
	if(k==-1) return null;
	int[][] a=DecagonCombinatorics.candidateTriples(k);
	int index=DecagonCombinatorics.farthestTriple(a,z);
	return a[index];
    }

    public static int[] getTriple(Complex z,int force) {
	Path2D.Double p=new Path2D.Double();
	int k=DecagonCombinatorics.stateNumber(z);
	int[][] a=DecagonCombinatorics.candidateTriples(k);
	return a[force];
    }

    public static Complex getFarpoint(Complex z) {
	Path2D.Double p=new Path2D.Double();
	int[] a=getTriple(z);
	if(a==null) return null;
	Complex w=DecagonCombinatorics.triplePoint(a,z);
	return w;
    }
    
    public static Complex getFarpoint(Complex z,int force) {
	Path2D.Double p=new Path2D.Double();
	int[] a=getTriple(z,force);
	if(a==null) return null;
	Complex w=DecagonCombinatorics.triplePoint(a,z);
	return w;
    }

    
}

