import java.awt.*;

public class ListHelp {

    public static boolean onList(int a,int[] list) {
	for(int i=0;i<list.length;++i) {
	    if(a==list[i]) return true;
	}
	return false;
    }


    public static boolean match(int[] a,int[] b) {
	if(a.length!=b.length) return false;
	for(int i=0;i<a.length;++i) {
	    if(a[i]!=b[i]) return false;
	}
	return true;
    }
    


    public static int[] reverse(int[] list1,int count) {
	int[] list2=new int[count];
	for(int i=0;i<count;++i) list2[i]=list1[count-1-i];
	return(list2);
    }

    public static int[] rotate(int[] list1,int k) {
	int n=list1.length;
	int[] list2=new int[n];
	for(int i=0;i<n;++i) list2[i]=list1[(i+k)%n];
	return(list2);
    }

    public static void print(int[] a) {
	for(int i=0;i<a.length;++i) System.out.print(a[i]+"  ");
	System.out.println("");
    }
    
    public static void print2(int[] a) {
	System.out.print("{");
	for(int i=0;i<a.length;++i) {
	    if(i<a.length-1) System.out.print(a[i]+",");
	    else System.out.print(a[i]+"},");
	}
    }
    

}
