import java.applet.Applet;
import java.awt.event.*;
import java.awt.*;


public class NumberRecognizer {


    public static int[] recognize(Complex z) {
	int[] J={0,0,0,0,0};
	double min=100;
	
	for(int i0=0;i0<=7;++i0) {
	for(int i1=-7;i1<=7;++i1) {
	for(int i2=-7;i2<=7;++i2) {
	for(int i3=-7;i3<=7;++i3) {
	for(int i4=-7;i4<=7;++i4) {
	    int[] I={i0,i1,i2,i3,i4};
	    Complex w=integerCombo(I);
	    double d=Complex.dist(z,w);
	    if(d<min) {
		min=d;
		for(int j=0;j<5;++j) J[j]=I[j];
	    }
	}}}}}
	return J;
    }
		
    public static int recognizeShort(Complex z) {
	for(int i=0;i<10;++i) {
	    Complex w=Chain.rootOfUnity10(i);
	    double d=Complex.dist(z,w);
	    if(d<.0000001) return i;
	}
	return -1;
    }
    
    public static Complex integerCombo(int[] I) {
	Complex z=new Complex(0,0);
	for(int i=0;i<5;++i) {
	    Complex w=Chain.rootOfUnity5(i);
	    w=w.scale(I[i]);
	    z=Complex.plus(z,w);
	}
	return z;
    }
    
}

