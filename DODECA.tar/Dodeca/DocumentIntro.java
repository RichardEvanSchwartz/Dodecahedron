import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.geom.*;
import java.math.*;

/**Documentation file*/


public class DocumentIntro {

    public DocumentIntro() {}


    public static void setup(DocumentCanvas D) {
    
	String S="Spider's Embrace 2";
        S=S+"\nby Rich Schwartz";


	S=S+"\n\nPURPOSE:\n\n";
	S=S+"The purpose of this program is to illustrate the structure of the antifarpoint (AF) map on the regular dodecahedron. AF is the composition, in either order, of the antipodal map and the farpoint map F.   Here F(p) is the point on the regular dodecahedron farthest from p.  Generically this point is unique.  This program is a sequel to Spider's Embrace 1, which does the same thing for the regular octahedron.";

	    S=S+"\n\nOPERATING INSTRUCTIONS";

	    S=S+"\n\nThis program has 4 windows.\n\n0. Control panel.  The small and colorful window controls the rest of the program. If you kill this window, the whole program stops.\n\n1. Info: The window with this text gives instructions for and information about the rest of the program. You can drag the text to scroll up and down.  If you click on the blue question (?) boxes scattered throughout the control panel, this window will show text which explains the relevant feature.  If you click the blue ?-box at the top of this window, it will return the text you are reading now. \n\n2. Picture window.  This is the main window.  It illustrates AF.\n\n3. Formula window: This gives the formulas for the 6 algebraic curves needed to describe AF.";

            S=S+"\n\nThe formula window and this info window are  killable and resurrectable. You bring up these other windows by clicking on the buttons on the lower left part of the control panel (the popups console) and you kill them in the usual way you kill windows on your computer.  Try bringing up the picture window, killing it, and then resurrecting it. You can also resize these popup windows in the usual way that you resize windows on your computer. The ?-box by the popups console has more info on how to do all this.";

	    S=S+"\n\nThis program is designed to work best with a 3 button mouse. On the picture and closeup windows, buttoms 1 and 3 zoom in and out of the picture and button 2 selects a new point.  You can also drag button-2 to continuously select a new point. If you don't have a 3 button mouse, you can use the buttons Z,X,C to emulate it.";

	    S=S+"\n\nMAIN STRUCTURE:";

	    S=S+"\n\nAll the action takes place in the plane. The central pentagon is one face of the dodecahedron.  There are two main geometric constructions going on: \n\nThe pentagon is divided into 15 smaller quadrilaterals which we call STATES.  Each of these states is divided into 4 smaller tiles which we call CITIES.  The map  AF varies analytically in each of CITY and within each state the 4 different branches of AF have a certain commonality to them. \n\n  Let C(p) denote the cut locus of the dodecahedron with respect to the antipodal point A(p).  The cut locus C(p) varies in a structurally stable way as p ranges inside a single city.  The point AF(p) is always a vertex of C(p).";

	    S=S+"\n\nThese two geometric constructions are superimposed over each other, and the two sliders on the control panel control the transparency of each construction.  This allows you to inspect one or the other construction more carefully.";

	    S=S+"\n\nGETTING STARTED:";
	    
	    S=S+"\n\nThe way to get started is to use the control panel labeled STUDY.  This control panel has 4 preset options.  You activate these options by pressing the buttons on this control panel.  Each option lets you study the constructions above, somewhat in isolation.  Push the question box in the STUDY control panel to read what the 4 options do.  Then try them out and drag the mouse over the picture window.   I have set up the program so that you can only select new points that are inside the central pentagon.  If you try dragging or clicking outside the central pentagon then nothing will happen.";

	    S=S+"\n\nFORMULAS:";

	    S=S+"\n\nThe 60 cities of are bounded by straight line segments and by some algebraic curves. Modulo the action of the dihedral group, there are 6 distinct algebraic curves.  At the same time, the cities have some internal vertices which are not vertices of the much simpler states.  You can see formulas for all of these things, and also formulas for AF, by opening up the FORMULA window.  All of this is explained in the documentation which you can read after opening up the FORMULA window.";

	    S=S+"\n\nGEOMETRIC CONSTRUCTION OF AF:";

	    S=S+"The MAP CONSTRUCTION feature on the control panel gives a geometric construction of AF in each of the 60 cities.";

	    
        D.setExplain(S);
        D.repaint();   
	D.Y0=0;
        D.Y1=0;
    }
}

