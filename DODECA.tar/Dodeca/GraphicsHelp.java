import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.geom.*;
import java.math.*;



public class GraphicsHelp {

    public static Path2D.Double makeDot(Complex z) {
	Path2D.Double gp=new Path2D.Double();
	gp.moveTo((z.x),(z.y));
	gp.lineTo((z.x),(z.y));
	return(gp);
    }

    public static Path2D.Double toPath(Complex[] Z) {
        Path2D.Double gp=new Path2D.Double();
	if(Z==null) return(gp);
	for(int i=0;i<Z.length;++i) {
	    if(i==0) gp.moveTo((Z[i].x),(Z[i].y));
	    if(i!=0) gp.lineTo((Z[i].x),(Z[i].y));
	}
	gp.closePath();
	return(gp);
    }

    public static void fill(Graphics2D g,PictureCanvas C,Complex Z,Color COL,int width) {
	Path2D.Double gp=makeDot(Z);
	gp=C.transform(gp);
	g.setColor(COL);
	g.setStroke(new BasicStroke(width));
	g.fill(gp);
	g.draw(gp);
	g.setStroke(new BasicStroke(1));
    }



}
