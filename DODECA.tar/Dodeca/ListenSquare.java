
import java.applet.Applet;
import java.awt.event.*;
import java.awt.*;
import java.awt.geom.*;

/*This is a basic class for a rectangular button button*/

public class ListenSquare {
    public double x,y,w,h;
    public int on;
    public int state;
    public Color C;


    public ListenSquare () {}
    /*square*/

    /*rectangle*/

    public ListenSquare(double x,double y,double w,double h,Color C) {
	this.x=x;
	this.y=y;
	this.C=C;
	this.w=w;
	this.h=h;
	this.on=0;
    }

    public ListenSquare(double x,double y,double w,double h) {
	this.x=x;
	this.y=y;
	this.C=null;
	this.w=w;
	this.h=h;
	this.on=1;
    }

    public int inside(Point p) {
        int test=0;
	if((p.x>x)&&(p.x<x+w)&&(p.y>y)&&(p.y<y+h)) test=1;
	return(test);
    }


    /* drawing methods */

    public void render(Graphics g,Color CC) {
	if(on==0) g.setColor(new Color(0,0,0));
	if(on>=1) g.setColor(CC);
	g.fillRect((int)(x),(int)(y),(int)(w),(int)(h));
	g.setColor(C);
	if(on!=0) g.setColor(Color.white);
	g.drawRect((int)(x),(int)(y),(int)(w),(int)(h));
    }

    public void render2(Graphics g,Color CC) {
	if(on==0) g.setColor(new Color(0,0,0));
	if(on>=1) g.setColor(CC);
	g.fillRect((int)(x),(int)(y),(int)(w),(int)(h));
	g.setColor(Color.white);
	g.drawRect((int)(x),(int)(y),(int)(w),(int)(h));
    }

    public void infoRender(Graphics g) {
	render(g,"?",10,0,new Color(40,80,255));
    }

    public void render(Graphics g,String S,int font,int offset,Color CC) {
	if(on==0) g.setColor(new Color(0,0,0));
	if(on>=1) g.setColor(CC);
	g.fillRect((int)(x),(int)(y),(int)(w),(int)(h));
	g.setColor(C);
	g.setColor(Color.white);
	g.drawRect((int)(x),(int)(y),(int)(w),(int)(h));
        g.setFont(new Font("Helvetica",Font.PLAIN,font));
	g.drawString(S,(int)(x+4),(int)(y+font+offset));
    }


    public void renderShrink(Graphics g,Color C) {
	g.setColor(C);
	g.fillRect((int)(x+7),(int)(y+7),(int)(w-13),(int)(h-13));
    }




    public void renderSmooth(Graphics2D g,Color C1,Color C2) {
        Polygon P=new Polygon();
        float X[]={(float)(this.x),(float)(this.x+0),(float)(this.x+this.w),(float)(this.x+this.w)};
        float Y[]={(float)(this.y),(float)(this.y+this.h),(float)(this.y+this.h),(float)(this.y+0)};
	GeneralPath path=new GeneralPath();
	path.moveTo(X[0],Y[0]);
	for(int i=1;i<4;++i) path.lineTo(X[i],Y[i]);
	path.closePath();
	g.setColor(C1);
	g.fill(path);
	g.setColor(C2);
	g.draw(path);
    }


}
