import java.applet.Applet;
import java.awt.*;
import java.applet.*;
import java.math.*;

/**This class lets the various windows
   talk to each other*/

public class Manager  {
    PictureCanvas P;
    ControlCanvas C;
    FormulaCanvas X;
    DocumentCanvas D;

    
    public Manager() {}


    public void repaint() {
	try {P.repaint();} catch(Exception e) {}
	try {C.repaint();} catch(Exception e) {}
	try {X.repaint();} catch(Exception e) {}
	try {D.repaint();} catch(Exception e) {}
    }


}

    

