F163 = {-4896*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 2448*Sqrt[2*(25 - 5*Sqrt[5])] + 
      5360*Sqrt[2*(5 - Sqrt[5])] - 2144*Sqrt[10*(5 - Sqrt[5])] - 
      448*Sqrt[2*(5 + Sqrt[5])] - 32*Sqrt[10*(5 + Sqrt[5])] + 
      780*Sqrt[50 - 10*Sqrt[5]]*x - 312*Sqrt[5*(50 - 10*Sqrt[5])]*x + 
      1900*Sqrt[10 - 2*Sqrt[5]]*x - 760*Sqrt[5*(10 - 2*Sqrt[5])]*x + 
      256*Sqrt[2*(5 + Sqrt[5])]*x - 136*Sqrt[10*(5 + Sqrt[5])]*x - 
      172*Sqrt[(50 - 10*Sqrt[5])/5]*x^2 + 86*Sqrt[50 - 10*Sqrt[5]]*x^2 + 
      150*Sqrt[10 - 2*Sqrt[5]]*x^2 - 60*Sqrt[5*(10 - 2*Sqrt[5])]*x^2 - 
      88*Sqrt[2*(5 + Sqrt[5])]*x^2 + 44*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      2*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 + Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      5*Sqrt[2*(5 - Sqrt[5])]*x^3 - 2*Sqrt[10*(5 - Sqrt[5])]*x^3 + 
      10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 4*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      48*Sqrt[5 - 2*Sqrt[5]]*x*y - 48*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      16*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      8*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 10*Sqrt[50 - 10*Sqrt[5]]*x^2*y^2 - 
      4*Sqrt[5*(50 - 10*Sqrt[5])]*x^2*y^2 - 30*Sqrt[10 - 2*Sqrt[5]]*x^2*y^2 + 
      12*Sqrt[5*(10 - 2*Sqrt[5])]*x^2*y^2 - 140*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 56*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 5*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 2*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      15*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 6*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      90*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      40*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     2232*Sqrt[(2*(25 - 5*Sqrt[5]))/5] - 1116*Sqrt[2*(25 - 5*Sqrt[5])] - 
      2500*Sqrt[2*(5 - Sqrt[5])] + 1000*Sqrt[10*(5 - Sqrt[5])] + 
      196*Sqrt[2*(5 + Sqrt[5])] + 100*Sqrt[10*(5 + Sqrt[5])] + 
      80*Sqrt[2*(25 - 5*Sqrt[5])]*x - 32*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      80*Sqrt[2*(5 - Sqrt[5])]*x - 32*Sqrt[10*(5 - Sqrt[5])]*x - 
      152*Sqrt[2*(5 + Sqrt[5])]*x + 96*Sqrt[10*(5 + Sqrt[5])]*x - 
      26*Sqrt[(50 - 10*Sqrt[5])/5]*x^2 + 13*Sqrt[50 - 10*Sqrt[5]]*x^2 + 
      5*Sqrt[10 - 2*Sqrt[5]]*x^2 - 2*Sqrt[5*(10 - 2*Sqrt[5])]*x^2 - 
      34*Sqrt[2*(5 + Sqrt[5])]*x^2 + 12*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      216*Sqrt[5 - 2*Sqrt[5]]*x*y + 104*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      32*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 32*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 
      45*Sqrt[50 - 10*Sqrt[5]]*x^2*y^2 - 18*Sqrt[5*(50 - 10*Sqrt[5])]*x^2*
       y^2 - 75*Sqrt[10 - 2*Sqrt[5]]*x^2*y^2 + 30*Sqrt[5*(10 - 2*Sqrt[5])]*
       x^2*y^2 - 250*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 
      116*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      60*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     1192*Sqrt[(2*(25 - 5*Sqrt[5]))/5] - 596*Sqrt[2*(25 - 5*Sqrt[5])] - 
      1300*Sqrt[2*(5 - Sqrt[5])] + 520*Sqrt[10*(5 - Sqrt[5])] + 
      176*Sqrt[2*(5 + Sqrt[5])] + 40*Sqrt[10*(5 + Sqrt[5])] + 
      10*Sqrt[2*(25 - 5*Sqrt[5])]*x - 4*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      10*Sqrt[2*(5 - Sqrt[5])]*x - 4*Sqrt[10*(5 - Sqrt[5])]*x + 
      28*Sqrt[2*(5 + Sqrt[5])]*x - 6*Sqrt[(50 - 10*Sqrt[5])/5]*x^2 + 
      3*Sqrt[50 - 10*Sqrt[5]]*x^2 - 25*Sqrt[10 - 2*Sqrt[5]]*x^2 + 
      10*Sqrt[5*(10 - 2*Sqrt[5])]*x^2 - 84*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      34*Sqrt[10*(5 + Sqrt[5])]*x^2 + 4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 
      2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      7*Sqrt[10*(5 + Sqrt[5])]*x^3 + 296*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      152*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 272*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 
      144*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 
      4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 55*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      22*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 + 165*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 - 66*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 420*Sqrt[2*(5 + Sqrt[5])]*
       x^2*y^2 - 186*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*
       y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*
       x^3*y^2 - 60*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*
       x^3*y^3, -496*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 
      248*Sqrt[2*(25 - 5*Sqrt[5])] + 520*Sqrt[2*(5 - Sqrt[5])] - 
      208*Sqrt[10*(5 - Sqrt[5])] - 8*Sqrt[2*(5 + Sqrt[5])] + 
      56*Sqrt[10*(5 + Sqrt[5])] + 520*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      208*Sqrt[10*(25 - 5*Sqrt[5])]*x + 1200*Sqrt[2*(5 - Sqrt[5])]*x - 
      480*Sqrt[10*(5 - Sqrt[5])]*x - 44*Sqrt[2*(5 + Sqrt[5])]*x - 
      36*Sqrt[10*(5 + Sqrt[5])]*x - 192*Sqrt[(50 - 10*Sqrt[5])/5]*x^2 + 
      96*Sqrt[50 - 10*Sqrt[5]]*x^2 + 180*Sqrt[10 - 2*Sqrt[5]]*x^2 - 
      72*Sqrt[5*(10 - 2*Sqrt[5])]*x^2 - 38*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      14*Sqrt[10*(5 + Sqrt[5])]*x^2 - 2*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 + 
      Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 5*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      2*Sqrt[10*(5 - Sqrt[5])]*x^3 + 10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      4*Sqrt[10*(5 + Sqrt[5])]*x^3 + 272*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      80*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 64*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 
      96*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 8*Sqrt[5 - 2*Sqrt[5]]*x^3*y - 
      80*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 32*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 60*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 24*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 190*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 86*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 5*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      2*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 15*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 6*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 90*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 40*Sqrt[5 - 2*Sqrt[5]]*x^3*
       y^3 + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -208*Sqrt[2*(25 - 5*Sqrt[5])] - 176*Sqrt[2*(5 - Sqrt[5])] + 
      512*Sqrt[2*(5 + Sqrt[5])] + 32*Sqrt[10*(5 + Sqrt[5])] - 
      20*Sqrt[2*(25 - 5*Sqrt[5])]*x - 100*Sqrt[2*(5 - Sqrt[5])]*x + 
      56*Sqrt[2*(5 + Sqrt[5])]*x + 64*Sqrt[10*(5 + Sqrt[5])]*x - 
      12*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 12*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      12*Sqrt[2*(5 + Sqrt[5])]*x^2 - 12*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      2*Sqrt[10 - 2*Sqrt[5]]*x^3 - 5*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      Sqrt[10*(5 + Sqrt[5])]*x^3 - 288*Sqrt[5 - 2*Sqrt[5]]*x*y - 
      64*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 96*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 
      32*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 12*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 
      4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 24*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      40*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 60*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 
      20*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 4*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 10*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 35*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 15*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 20*Sqrt[5 - 2*Sqrt[5]]*x^3*
       y^3 - 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -88*Sqrt[2*(25 - 5*Sqrt[5])] - 136*Sqrt[2*(5 - Sqrt[5])] + 
      232*Sqrt[2*(5 + Sqrt[5])] + 72*Sqrt[10*(5 + Sqrt[5])] - 
      8*Sqrt[2*(25 - 5*Sqrt[5])]*x - 160*Sqrt[2*(5 - Sqrt[5])]*x + 
      76*Sqrt[2*(5 + Sqrt[5])]*x + 100*Sqrt[10*(5 + Sqrt[5])]*x - 
      12*Sqrt[10 - 2*Sqrt[5]]*x^2 - 18*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      26*Sqrt[10*(5 + Sqrt[5])]*x^2 - Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      3*Sqrt[2*(5 - Sqrt[5])]*x^3 + 10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      4*Sqrt[10*(5 + Sqrt[5])]*x^3 + 112*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      112*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 96*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 
      8*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 104*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      220*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 350*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 
      150*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 11*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 25*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 90*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 8*(5 - 2*Sqrt[5])^(3/2)*x^3*
       y^3, -480*Sqrt[2*(25 - 5*Sqrt[5])] - 736*Sqrt[2*(5 - Sqrt[5])] + 
      912*Sqrt[2*(5 + Sqrt[5])] + 176*Sqrt[10*(5 + Sqrt[5])] + 
      20*Sqrt[2*(25 - 5*Sqrt[5])]*x + 20*Sqrt[2*(5 - Sqrt[5])]*x + 
      16*Sqrt[2*(5 + Sqrt[5])]*x + 24*Sqrt[10*(5 + Sqrt[5])]*x + 
      8*Sqrt[10 - 2*Sqrt[5]]*x^2 - 8*Sqrt[2*(5 + Sqrt[5])]*x^2 - 
      16*Sqrt[10*(5 + Sqrt[5])]*x^2 - 2*Sqrt[10 - 2*Sqrt[5]]*x^3 - 
      5*Sqrt[2*(5 + Sqrt[5])]*x^3 + Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      672*Sqrt[5 - 2*Sqrt[5]]*x*y + 256*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      384*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 192*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 
      12*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 
      28*Sqrt[50 - 10*Sqrt[5]]*x^2*y^2 + 60*Sqrt[10 - 2*Sqrt[5]]*x^2*y^2 + 
      16*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 4*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 10*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 35*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 15*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 20*Sqrt[5 - 2*Sqrt[5]]*x^3*
       y^3 - 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -3776*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 1888*Sqrt[2*(25 - 5*Sqrt[5])] + 
      4000*Sqrt[2*(5 - Sqrt[5])] - 1600*Sqrt[10*(5 - Sqrt[5])] - 
      528*Sqrt[2*(5 + Sqrt[5])] + 80*Sqrt[10*(5 + Sqrt[5])] - 
      20*Sqrt[2*(25 - 5*Sqrt[5])]*x + 8*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      180*Sqrt[2*(5 - Sqrt[5])]*x + 72*Sqrt[10*(5 - Sqrt[5])]*x - 
      224*Sqrt[2*(5 + Sqrt[5])]*x + 120*Sqrt[10*(5 + Sqrt[5])]*x + 
      28*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 - 14*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      30*Sqrt[2*(5 - Sqrt[5])]*x^2 + 12*Sqrt[10*(5 - Sqrt[5])]*x^2 + 
      32*Sqrt[2*(5 + Sqrt[5])]*x^2 - 4*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      2*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 + Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      5*Sqrt[2*(5 - Sqrt[5])]*x^3 - 2*Sqrt[10*(5 - Sqrt[5])]*x^3 + 
      10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 4*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      432*Sqrt[5 - 2*Sqrt[5]]*x*y + 240*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      464*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 208*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      8*Sqrt[5 - 2*Sqrt[5]]*x^3*y - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      4*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 50*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 + 20*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 100*Sqrt[2*(5 + Sqrt[5])]*
       x^2*y^2 - 48*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      5*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 2*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 15*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 6*Sqrt[10*(5 - Sqrt[5])]*x^3*
       y^2 + 90*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 40*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*
       y^3, 152*Sqrt[(2*(25 - 5*Sqrt[5]))/5] - 76*Sqrt[2*(25 - 5*Sqrt[5])] - 
      100*Sqrt[2*(5 - Sqrt[5])] + 40*Sqrt[10*(5 - Sqrt[5])] + 
      156*Sqrt[2*(5 + Sqrt[5])] - 20*Sqrt[10*(5 + Sqrt[5])] - 
      20*Sqrt[2*(25 - 5*Sqrt[5])]*x + 8*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      20*Sqrt[2*(5 - Sqrt[5])]*x + 8*Sqrt[10*(5 - Sqrt[5])]*x + 
      88*Sqrt[2*(5 + Sqrt[5])]*x - 24*Sqrt[10*(5 + Sqrt[5])]*x + 
      14*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 - 7*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      55*Sqrt[2*(5 - Sqrt[5])]*x^2 + 22*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      94*Sqrt[2*(5 + Sqrt[5])]*x^2 + 40*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      24*Sqrt[5 - 2*Sqrt[5]]*x*y - 8*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      48*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 
      15*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 6*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 65*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 26*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 130*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 56*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 60*Sqrt[5 - 2*Sqrt[5]]*x^3*
       y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -728*Sqrt[(50 - 10*Sqrt[5])/5] + 364*Sqrt[50 - 10*Sqrt[5]] + 
      780*Sqrt[10 - 2*Sqrt[5]] - 312*Sqrt[5*(10 - 2*Sqrt[5])] - 
      64*Sqrt[2*(5 + Sqrt[5])] + 24*Sqrt[10*(5 + Sqrt[5])] + 
      170*Sqrt[2*(25 - 5*Sqrt[5])]*x - 68*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      330*Sqrt[2*(5 - Sqrt[5])]*x - 132*Sqrt[10*(5 - Sqrt[5])]*x - 
      92*Sqrt[2*(5 + Sqrt[5])]*x + 56*Sqrt[10*(5 + Sqrt[5])]*x - 
      6*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 + 3*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      25*Sqrt[2*(5 - Sqrt[5])]*x^2 + 10*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      44*Sqrt[2*(5 + Sqrt[5])]*x^2 + 18*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      104*Sqrt[5 - 2*Sqrt[5]]*x*y - 56*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      48*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 
      65*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 26*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 195*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 78*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 - 580*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 
      262*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      60*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     48*Sqrt[2*(25 - 5*Sqrt[5])] - 16*Sqrt[2*(5 - Sqrt[5])] + 
      192*Sqrt[2*(5 + Sqrt[5])] + 160*Sqrt[10*(5 + Sqrt[5])] + 
      56*Sqrt[2*(25 - 5*Sqrt[5])]*x - 80*Sqrt[2*(5 - Sqrt[5])]*x + 
      36*Sqrt[2*(5 + Sqrt[5])]*x + 188*Sqrt[10*(5 + Sqrt[5])]*x + 
      2*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 2*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      22*Sqrt[2*(5 + Sqrt[5])]*x^2 + 14*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 3*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 4*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      512*Sqrt[5 - 2*Sqrt[5]]*x*y + 224*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      96*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 8*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 
      38*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 70*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 - 230*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 98*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 11*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      25*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 90*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 
      40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 8*(5 - 2*Sqrt[5])^(3/2)*x^3*y^3, 
     -336*Sqrt[2*(25 - 5*Sqrt[5])] - 496*Sqrt[2*(5 - Sqrt[5])] + 
      912*Sqrt[2*(5 + Sqrt[5])] + 208*Sqrt[10*(5 + Sqrt[5])] + 
      28*Sqrt[2*(25 - 5*Sqrt[5])]*x + 60*Sqrt[2*(5 - Sqrt[5])]*x + 
      16*Sqrt[2*(5 + Sqrt[5])]*x + 24*Sqrt[10*(5 + Sqrt[5])]*x + 
      8*Sqrt[2*(5 - Sqrt[5])]*x^2 - 8*Sqrt[2*(5 + Sqrt[5])]*x^2 - 
      16*Sqrt[10*(5 + Sqrt[5])]*x^2 - 2*Sqrt[10 - 2*Sqrt[5]]*x^3 - 
      5*Sqrt[2*(5 + Sqrt[5])]*x^3 + Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      1232*Sqrt[5 - 2*Sqrt[5]]*x*y + 592*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      384*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 192*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 
      12*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 
      36*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 60*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 - 60*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 44*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y^2 + 4*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 10*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 35*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 15*Sqrt[10*(5 + Sqrt[5])]*
       x^3*y^2 + 20*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 - 4*Sqrt[5*(5 - 2*Sqrt[5])]*
       x^3*y^3, -3856*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 
      1928*Sqrt[2*(25 - 5*Sqrt[5])] + 4200*Sqrt[2*(5 - Sqrt[5])] - 
      1680*Sqrt[10*(5 - Sqrt[5])] - 128*Sqrt[2*(5 + Sqrt[5])] + 
      80*Sqrt[10*(5 + Sqrt[5])] - 440*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      176*Sqrt[10*(25 - 5*Sqrt[5])]*x - 1080*Sqrt[2*(5 - Sqrt[5])]*x + 
      432*Sqrt[10*(5 - Sqrt[5])]*x - 184*Sqrt[2*(5 + Sqrt[5])]*x + 
      56*Sqrt[10*(5 + Sqrt[5])]*x + 88*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 - 
      44*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 100*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      40*Sqrt[10*(5 - Sqrt[5])]*x^2 - 8*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      8*Sqrt[10*(5 + Sqrt[5])]*x^2 - 2*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 + 
      Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 5*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      2*Sqrt[10*(5 - Sqrt[5])]*x^3 + 10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      4*Sqrt[10*(5 + Sqrt[5])]*x^3 + 672*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      320*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 464*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 
      208*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 8*Sqrt[5 - 2*Sqrt[5]]*x^3*y - 
      40*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 16*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 40*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 16*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 220*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 100*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 5*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      2*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 15*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 6*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 90*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 40*Sqrt[5 - 2*Sqrt[5]]*x^3*
       y^3 + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     192*Sqrt[(2*(25 - 5*Sqrt[5]))/5] - 96*Sqrt[2*(25 - 5*Sqrt[5])] - 
      160*Sqrt[2*(5 - Sqrt[5])] + 64*Sqrt[10*(5 - Sqrt[5])] + 
      256*Sqrt[2*(5 + Sqrt[5])] + 32*Sqrt[10*(5 + Sqrt[5])] - 
      100*Sqrt[2*(25 - 5*Sqrt[5])]*x + 40*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      260*Sqrt[2*(5 - Sqrt[5])]*x + 104*Sqrt[10*(5 - Sqrt[5])]*x - 
      72*Sqrt[2*(5 + Sqrt[5])]*x + 32*Sqrt[10*(5 + Sqrt[5])]*x + 
      24*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 - 12*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      60*Sqrt[2*(5 - Sqrt[5])]*x^2 + 24*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      64*Sqrt[2*(5 + Sqrt[5])]*x^2 + 24*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      224*Sqrt[5 - 2*Sqrt[5]]*x*y - 96*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      48*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 
      20*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 8*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 60*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 24*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 160*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 72*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 60*Sqrt[5 - 2*Sqrt[5]]*x^3*
       y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -1728*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 864*Sqrt[2*(25 - 5*Sqrt[5])] + 
      1920*Sqrt[2*(5 - Sqrt[5])] - 768*Sqrt[10*(5 - Sqrt[5])] + 
      16*Sqrt[2*(5 + Sqrt[5])] + 16*Sqrt[10*(5 + Sqrt[5])] + 
      280*Sqrt[2*(25 - 5*Sqrt[5])]*x - 112*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      640*Sqrt[2*(5 - Sqrt[5])]*x - 256*Sqrt[10*(5 - Sqrt[5])]*x + 
      68*Sqrt[2*(5 + Sqrt[5])]*x + 12*Sqrt[10*(5 + Sqrt[5])]*x - 
      16*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 + 8*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      20*Sqrt[2*(5 - Sqrt[5])]*x^2 + 8*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      74*Sqrt[2*(5 + Sqrt[5])]*x^2 + 34*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      304*Sqrt[5 - 2*Sqrt[5]]*x*y - 112*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      48*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 
      60*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 24*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 200*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 80*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 - 550*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 
      246*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      60*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     2672*Sqrt[(2*(25 - 5*Sqrt[5]))/5] - 1336*Sqrt[2*(25 - 5*Sqrt[5])] - 
      2920*Sqrt[2*(5 - Sqrt[5])] + 1168*Sqrt[10*(5 - Sqrt[5])] + 
      456*Sqrt[2*(5 + Sqrt[5])] + 104*Sqrt[10*(5 + Sqrt[5])] + 
      100*Sqrt[2*(25 - 5*Sqrt[5])]*x - 40*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      180*Sqrt[2*(5 - Sqrt[5])]*x - 72*Sqrt[10*(5 - Sqrt[5])]*x + 
      8*Sqrt[2*(5 + Sqrt[5])]*x + 64*Sqrt[10*(5 + Sqrt[5])]*x - 
      36*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 + 18*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      10*Sqrt[2*(5 - Sqrt[5])]*x^2 - 4*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      64*Sqrt[2*(5 + Sqrt[5])]*x^2 + 28*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      496*Sqrt[5 - 2*Sqrt[5]]*x*y + 240*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      32*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 32*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 
      50*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 20*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 70*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 28*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 132*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 60*Sqrt[5 - 2*Sqrt[5]]*x^3*
       y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -208*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 104*Sqrt[2*(25 - 5*Sqrt[5])] + 
      200*Sqrt[2*(5 - Sqrt[5])] - 80*Sqrt[10*(5 - Sqrt[5])] + 
      96*Sqrt[2*(5 + Sqrt[5])] + 80*Sqrt[10*(5 + Sqrt[5])] + 
      20*Sqrt[2*(25 - 5*Sqrt[5])]*x - 8*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      20*Sqrt[2*(5 - Sqrt[5])]*x + 8*Sqrt[10*(5 - Sqrt[5])]*x + 
      88*Sqrt[2/5]*(5 + Sqrt[5])^(3/2)*x - 44*Sqrt[2]*(5 + Sqrt[5])^(3/2)*x + 
      4*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 - 2*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      30*Sqrt[2*(5 - Sqrt[5])]*x^2 + 12*Sqrt[10*(5 - Sqrt[5])]*x^2 + 
      36*Sqrt[2/5]*(5 + Sqrt[5])^(3/2)*x^2 - 18*Sqrt[2]*(5 + Sqrt[5])^(3/2)*
       x^2 + 4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      576*Sqrt[5 - 2*Sqrt[5]]*x*y + 256*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      272*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 144*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 
      50*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 20*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 170*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 68*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 + 390*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 
      170*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      60*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -3456*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 1728*Sqrt[2*(25 - 5*Sqrt[5])] + 
      3840*Sqrt[2*(5 - Sqrt[5])] - 1536*Sqrt[10*(5 - Sqrt[5])] + 
      32*Sqrt[2*(5 + Sqrt[5])] + 32*Sqrt[10*(5 + Sqrt[5])] + 
      280*Sqrt[2*(25 - 5*Sqrt[5])]*x - 112*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      720*Sqrt[2*(5 - Sqrt[5])]*x - 288*Sqrt[10*(5 - Sqrt[5])]*x - 
      4*Sqrt[2*(5 + Sqrt[5])]*x - 124*Sqrt[10*(5 + Sqrt[5])]*x - 
      132*Sqrt[(50 - 10*Sqrt[5])/5]*x^2 + 66*Sqrt[50 - 10*Sqrt[5]]*x^2 + 
      110*Sqrt[10 - 2*Sqrt[5]]*x^2 - 44*Sqrt[5*(10 - 2*Sqrt[5])]*x^2 - 
      78*Sqrt[2*(5 + Sqrt[5])]*x^2 + 26*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      2*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 + Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      5*Sqrt[2*(5 - Sqrt[5])]*x^3 - 2*Sqrt[10*(5 - Sqrt[5])]*x^3 + 
      10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 4*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      32*Sqrt[5 - 2*Sqrt[5]]*x*y + 64*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      64*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 96*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      8*Sqrt[5 - 2*Sqrt[5]]*x^3*y - 50*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      20*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 30*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 + 12*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 70*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 34*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 5*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 2*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      15*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 6*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      90*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      40*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     384*Sqrt[(2*(25 - 5*Sqrt[5]))/5] - 192*Sqrt[2*(25 - 5*Sqrt[5])] - 
      320*Sqrt[2*(5 - Sqrt[5])] + 128*Sqrt[10*(5 - Sqrt[5])] + 
      512*Sqrt[2*(5 + Sqrt[5])] + 64*Sqrt[10*(5 + Sqrt[5])] - 
      180*Sqrt[2*(25 - 5*Sqrt[5])]*x + 72*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      420*Sqrt[2*(5 - Sqrt[5])]*x + 168*Sqrt[10*(5 - Sqrt[5])]*x + 
      56*Sqrt[2*(5 + Sqrt[5])]*x + 64*Sqrt[10*(5 + Sqrt[5])]*x + 
      168*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 - 84*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2 - 180*Sqrt[2*(5 - Sqrt[5])]*x^2 + 72*Sqrt[10*(5 - Sqrt[5])]*x^2 + 
      12*Sqrt[2*(5 + Sqrt[5])]*x^2 - 12*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      8*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 - 4*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      10*Sqrt[2*(5 - Sqrt[5])]*x^3 + 4*Sqrt[10*(5 - Sqrt[5])]*x^3 - 
      5*Sqrt[2*(5 + Sqrt[5])]*x^3 + Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      688*Sqrt[5 - 2*Sqrt[5]]*x*y - 304*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      96*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 32*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 
      12*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 
      40*Sqrt[50 - 10*Sqrt[5]]*x^2*y^2 + 16*Sqrt[5*(50 - 10*Sqrt[5])]*x^2*
       y^2 + 120*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 48*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 10*Sqrt[10 - 2*Sqrt[5]]*x^3*y^2 + 4*Sqrt[5*(10 - 2*Sqrt[5])]*
       x^3*y^2 - 35*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 15*Sqrt[10*(5 + Sqrt[5])]*
       x^3*y^2 + 20*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 - 4*Sqrt[5*(5 - 2*Sqrt[5])]*
       x^3*y^3, -3856*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 
      1928*Sqrt[2*(25 - 5*Sqrt[5])] + 4200*Sqrt[2*(5 - Sqrt[5])] - 
      1680*Sqrt[10*(5 - Sqrt[5])] - 128*Sqrt[2*(5 + Sqrt[5])] + 
      80*Sqrt[10*(5 + Sqrt[5])] + 1080*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      432*Sqrt[10*(25 - 5*Sqrt[5])]*x + 2520*Sqrt[2*(5 - Sqrt[5])]*x - 
      1008*Sqrt[10*(5 - Sqrt[5])]*x + 216*Sqrt[2*(5 + Sqrt[5])]*x - 
      24*Sqrt[10*(5 + Sqrt[5])]*x - 232*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 + 
      116*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 220*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      88*Sqrt[10*(5 - Sqrt[5])]*x^2 - 48*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      32*Sqrt[10*(5 + Sqrt[5])]*x^2 - 2*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 + 
      Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 5*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      2*Sqrt[10*(5 - Sqrt[5])]*x^3 + 10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      4*Sqrt[10*(5 + Sqrt[5])]*x^3 - 128*Sqrt[5 - 2*Sqrt[5]]*x*y - 
      32*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 16*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 
      16*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 8*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 
      40*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 16*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 120*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 48*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 - 260*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 
      108*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 5*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 2*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 15*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 6*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 90*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      40*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -360*Sqrt[2*(25 - 5*Sqrt[5])] + 144*Sqrt[10*(25 - 5*Sqrt[5])] - 
      640*Sqrt[2*(5 - Sqrt[5])] + 256*Sqrt[10*(5 - Sqrt[5])] + 
      460*Sqrt[2*(5 + Sqrt[5])] - 92*Sqrt[10*(5 + Sqrt[5])] + 
      20*Sqrt[2*(25 - 5*Sqrt[5])]*x - 8*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      160*Sqrt[2*(5 - Sqrt[5])]*x - 64*Sqrt[10*(5 - Sqrt[5])]*x + 
      190*Sqrt[2*(5 + Sqrt[5])]*x - 38*Sqrt[10*(5 + Sqrt[5])]*x + 
      10*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 4*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 
      35*Sqrt[2*(5 + Sqrt[5])]*x^2 + 19*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      200*Sqrt[5 - 2*Sqrt[5]]*x*y + 104*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      50*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 20*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 100*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 40*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 - 365*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 
      165*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2, -1600*Sqrt[2*(25 - 5*Sqrt[5])] + 
      640*Sqrt[10*(25 - 5*Sqrt[5])] - 3520*Sqrt[2*(5 - Sqrt[5])] + 
      1408*Sqrt[10*(5 - Sqrt[5])] + 480*Sqrt[2*(5 + Sqrt[5])] + 
      224*Sqrt[10*(5 + Sqrt[5])] + 140*Sqrt[50 - 10*Sqrt[5]]*x - 
      56*Sqrt[5*(50 - 10*Sqrt[5])]*x + 300*Sqrt[10 - 2*Sqrt[5]]*x - 
      120*Sqrt[5*(10 - 2*Sqrt[5])]*x + 40*Sqrt[2*(5 + Sqrt[5])]*x - 
      16*Sqrt[10*(5 + Sqrt[5])]*x + 10*Sqrt[50 - 10*Sqrt[5]]*x^2 - 
      4*Sqrt[5*(50 - 10*Sqrt[5])]*x^2 - 30*Sqrt[10 - 2*Sqrt[5]]*x^2 + 
      12*Sqrt[5*(10 - 2*Sqrt[5])]*x^2 - 120*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      36*Sqrt[10*(5 + Sqrt[5])]*x^2 - 5*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      2*Sqrt[5*(50 - 10*Sqrt[5])]*x^3 - 5*Sqrt[10 - 2*Sqrt[5]]*x^3 + 
      2*Sqrt[5*(10 - 2*Sqrt[5])]*x^3 + 20*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3 + 1280*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      448*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 640*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 
      192*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 8*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 
      90*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 36*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 350*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 140*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 + 880*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 
      380*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 15*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 6*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 25*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 10*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      200*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 90*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      80*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 40*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -1600*Sqrt[2*(25 - 5*Sqrt[5])] + 640*Sqrt[10*(25 - 5*Sqrt[5])] - 
      3520*Sqrt[2*(5 - Sqrt[5])] + 1408*Sqrt[10*(5 - Sqrt[5])] + 
      480*Sqrt[2*(5 + Sqrt[5])] + 224*Sqrt[10*(5 + Sqrt[5])] - 
      400*Sqrt[2*(25 - 5*Sqrt[5])]*x + 160*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      1000*Sqrt[2*(5 - Sqrt[5])]*x + 400*Sqrt[10*(5 - Sqrt[5])]*x - 
      140*Sqrt[2*(5 + Sqrt[5])]*x + 44*Sqrt[10*(5 + Sqrt[5])]*x + 
      40*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 16*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 
      20*Sqrt[2*(5 - Sqrt[5])]*x^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      130*Sqrt[2*(5 + Sqrt[5])]*x^2 + 58*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      10*Sqrt[10 - 2*Sqrt[5]]*x^3 - 4*Sqrt[5*(10 - 2*Sqrt[5])]*x^3 + 
      35*Sqrt[2*(5 + Sqrt[5])]*x^3 - 15*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      240*Sqrt[5 - 2*Sqrt[5]]*x*y + 240*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      80*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 240*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      20*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 
      140*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 56*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 200*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 80*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 + 730*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 
      330*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 20*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 8*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 50*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 20*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      325*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 145*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 140*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 60*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*
       y^3, -192*Sqrt[2*(25 - 5*Sqrt[5])] - 320*Sqrt[2*(5 - Sqrt[5])] + 
      480*Sqrt[2*(5 + Sqrt[5])] + 224*Sqrt[10*(5 + Sqrt[5])] - 
      280*Sqrt[10 - 2*Sqrt[5]]*x - 60*Sqrt[2*(5 + Sqrt[5])]*x + 
      124*Sqrt[10*(5 + Sqrt[5])]*x + 2*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      50*Sqrt[2*(5 - Sqrt[5])]*x^2 - 70*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      26*Sqrt[10*(5 + Sqrt[5])]*x^2 - 3*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      5*Sqrt[2*(5 - Sqrt[5])]*x^3 + 20*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3 - 320*Sqrt[5 - 2*Sqrt[5]]*x*y - 
      320*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 96*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 
      8*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 130*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 290*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 390*Sqrt[2*(5 + Sqrt[5])]*
       x^2*y^2 - 170*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      25*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 55*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 + 200*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 90*Sqrt[10*(5 + Sqrt[5])]*
       x^3*y^2 - 80*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 40*Sqrt[5*(5 - 2*Sqrt[5])]*
       x^3*y^3, 84*Sqrt[2*(25 - 5*Sqrt[5])] + 196*Sqrt[2*(5 - Sqrt[5])] - 
      32*Sqrt[2*(5 + Sqrt[5])] - 24*Sqrt[10*(5 + Sqrt[5])] + 
      32*Sqrt[2*(25 - 5*Sqrt[5])]*x + 56*Sqrt[2*(5 - Sqrt[5])]*x + 
      2*Sqrt[2*(5 + Sqrt[5])]*x + 14*Sqrt[10*(5 + Sqrt[5])]*x + 
      Sqrt[50 - 10*Sqrt[5]]*x^2 + 5*Sqrt[10 - 2*Sqrt[5]]*x^2 + 
      4*Sqrt[2*(5 + Sqrt[5])]*x^2 - 92*Sqrt[5 - 2*Sqrt[5]]*x*y - 
      44*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 4*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 
      4*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 5*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      15*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 20*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 
      8*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2, -2840*Sqrt[2*(25 - 5*Sqrt[5])] + 
      1136*Sqrt[10*(25 - 5*Sqrt[5])] - 6200*Sqrt[2*(5 - Sqrt[5])] + 
      2480*Sqrt[10*(5 - Sqrt[5])] + 1280*Sqrt[2*(5 + Sqrt[5])] + 
      400*Sqrt[10*(5 + Sqrt[5])] + 320*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      128*Sqrt[10*(25 - 5*Sqrt[5])]*x + 720*Sqrt[2*(5 - Sqrt[5])]*x - 
      288*Sqrt[10*(5 - Sqrt[5])]*x + 240*Sqrt[2*(5 + Sqrt[5])]*x + 
      32*Sqrt[10*(5 + Sqrt[5])]*x + 40*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      16*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 40*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      16*Sqrt[10*(5 - Sqrt[5])]*x^2 - 140*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      52*Sqrt[10*(5 + Sqrt[5])]*x^2 - 5*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      2*Sqrt[5*(50 - 10*Sqrt[5])]*x^3 - 5*Sqrt[10 - 2*Sqrt[5]]*x^3 + 
      2*Sqrt[5*(10 - 2*Sqrt[5])]*x^3 + 20*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3 + 1920*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      864*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 240*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 
      112*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 8*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 
      100*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 40*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 300*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 120*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 + 40*Sqrt[2]*(5 + Sqrt[5])^(3/2)*x^2*y^2 - 
      16*Sqrt[10]*(5 + Sqrt[5])^(3/2)*x^2*y^2 - 15*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 6*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      25*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 10*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      200*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 90*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      80*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 40*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     28*Sqrt[2*(5 - Sqrt[5])] + 12*Sqrt[10*(5 - Sqrt[5])] + 
      84*Sqrt[2*(5 + Sqrt[5])] + 36*Sqrt[10*(5 + Sqrt[5])] - 
      8*Sqrt[2*(5 - Sqrt[5])]*x - 4*Sqrt[10*(5 - Sqrt[5])]*x - 
      16*Sqrt[2*(5 + Sqrt[5])]*x - 8*Sqrt[10*(5 + Sqrt[5])]*x - 
      3*Sqrt[2*(5 + Sqrt[5])]*x^2 - Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      204*Sqrt[5 - 2*Sqrt[5]]*x*y + 92*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      84*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 36*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 
      5*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - Sqrt[10*(5 + Sqrt[5])]*x^2*y^2, 
     20*Sqrt[2*(5 - Sqrt[5])] + 4*Sqrt[10*(5 - Sqrt[5])] + 
      60*Sqrt[2*(5 + Sqrt[5])] + 12*Sqrt[10*(5 + Sqrt[5])] - 
      4*Sqrt[50 - 10*Sqrt[5]]*x - 8*Sqrt[10*(5 + Sqrt[5])]*x - 
      5*Sqrt[2*(5 + Sqrt[5])]*x^2 + Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      20*Sqrt[5 - 2*Sqrt[5]]*x*y - 20*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      35*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 15*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2, 
     2320*Sqrt[2*(25 - 5*Sqrt[5])] - 928*Sqrt[10*(25 - 5*Sqrt[5])] + 
      5200*Sqrt[2*(5 - Sqrt[5])] - 2080*Sqrt[10*(5 - Sqrt[5])] + 
      320*Sqrt[2*(5 + Sqrt[5])] + 160*Sqrt[10*(5 + Sqrt[5])] + 
      680*Sqrt[2*(25 - 5*Sqrt[5])]*x - 272*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      1680*Sqrt[2*(5 - Sqrt[5])]*x - 672*Sqrt[10*(5 - Sqrt[5])]*x + 
      420*Sqrt[2*(5 + Sqrt[5])]*x - 100*Sqrt[10*(5 + Sqrt[5])]*x + 
      10*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 4*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 
      50*Sqrt[2*(5 - Sqrt[5])]*x^2 + 20*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      170*Sqrt[2*(5 + Sqrt[5])]*x^2 + 70*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      5*Sqrt[50 - 10*Sqrt[5]]*x^3 + 2*Sqrt[5*(50 - 10*Sqrt[5])]*x^3 - 
      5*Sqrt[10 - 2*Sqrt[5]]*x^3 + 2*Sqrt[5*(10 - 2*Sqrt[5])]*x^3 + 
      20*Sqrt[2*(5 + Sqrt[5])]*x^3 - 10*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      960*Sqrt[5 - 2*Sqrt[5]]*x*y - 480*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      32*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 8*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 
      30*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 12*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 150*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 60*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 - 390*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 
      170*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 15*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 6*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 25*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 10*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      200*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 90*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      80*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 40*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     2160*Sqrt[2*(25 - 5*Sqrt[5])] - 864*Sqrt[10*(25 - 5*Sqrt[5])] + 
      4560*Sqrt[2*(5 - Sqrt[5])] - 1824*Sqrt[10*(5 - Sqrt[5])] - 
      80*Sqrt[2*(5 + Sqrt[5])] + 368*Sqrt[10*(5 + Sqrt[5])] + 
      900*Sqrt[2*(25 - 5*Sqrt[5])]*x - 360*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      1860*Sqrt[2*(5 - Sqrt[5])]*x - 744*Sqrt[10*(5 - Sqrt[5])]*x + 
      264*Sqrt[10*(5 + Sqrt[5])]*x + 80*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      32*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 120*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      48*Sqrt[10*(5 - Sqrt[5])]*x^2 - 40*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      48*Sqrt[10*(5 + Sqrt[5])]*x^2 + 10*Sqrt[10 - 2*Sqrt[5]]*x^3 - 
      4*Sqrt[5*(10 - 2*Sqrt[5])]*x^3 + 35*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      15*Sqrt[10*(5 + Sqrt[5])]*x^3 + 400*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      208*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 160*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 
      32*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 20*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 
      4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 220*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 88*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 500*Sqrt[2*(5 - Sqrt[5])]*
       x^2*y^2 + 200*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 
      1580*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 700*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y^2 - 20*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      8*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 50*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 20*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 325*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 145*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      140*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 60*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -496*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 248*Sqrt[2*(25 - 5*Sqrt[5])] + 
      520*Sqrt[2*(5 - Sqrt[5])] - 208*Sqrt[10*(5 - Sqrt[5])] - 
      8*Sqrt[2*(5 + Sqrt[5])] + 56*Sqrt[10*(5 + Sqrt[5])] + 
      520*Sqrt[50 - 10*Sqrt[5]]*x - 208*Sqrt[5*(50 - 10*Sqrt[5])]*x + 
      1200*Sqrt[10 - 2*Sqrt[5]]*x - 480*Sqrt[5*(10 - 2*Sqrt[5])]*x - 
      44*Sqrt[2*(5 + Sqrt[5])]*x - 36*Sqrt[10*(5 + Sqrt[5])]*x - 
      192*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 + 96*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2 + 180*Sqrt[2*(5 - Sqrt[5])]*x^2 - 72*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      38*Sqrt[2*(5 + Sqrt[5])]*x^2 + 14*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      2*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 + Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      5*Sqrt[2*(5 - Sqrt[5])]*x^3 - 2*Sqrt[10*(5 - Sqrt[5])]*x^3 + 
      10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 4*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      48*Sqrt[5 - 2*Sqrt[5]]*x*y + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      16*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      8*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 80*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      32*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 100*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 + 40*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 290*Sqrt[2*(5 + Sqrt[5])]*
       x^2*y^2 + 122*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      5*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 2*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 15*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 6*Sqrt[10*(5 - Sqrt[5])]*x^3*
       y^2 + 90*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 40*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*
       y^3, 1192*Sqrt[(2*(25 - 5*Sqrt[5]))/5] - 
      596*Sqrt[2*(25 - 5*Sqrt[5])] - 1300*Sqrt[2*(5 - Sqrt[5])] + 
      520*Sqrt[10*(5 - Sqrt[5])] + 176*Sqrt[2*(5 + Sqrt[5])] + 
      40*Sqrt[10*(5 + Sqrt[5])] + 10*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      4*Sqrt[10*(25 - 5*Sqrt[5])]*x + 10*Sqrt[2*(5 - Sqrt[5])]*x - 
      4*Sqrt[10*(5 - Sqrt[5])]*x + 28*Sqrt[2*(5 + Sqrt[5])]*x - 
      6*Sqrt[(50 - 10*Sqrt[5])/5]*x^2 + 3*Sqrt[50 - 10*Sqrt[5]]*x^2 - 
      25*Sqrt[10 - 2*Sqrt[5]]*x^2 + 10*Sqrt[5*(10 - 2*Sqrt[5])]*x^2 - 
      84*Sqrt[2*(5 + Sqrt[5])]*x^2 + 34*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      56*Sqrt[5 - 2*Sqrt[5]]*x*y + 40*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      32*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 32*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 
      75*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 30*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 185*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 74*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 - 560*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 
      254*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      60*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     2232*Sqrt[(2*(25 - 5*Sqrt[5]))/5] - 1116*Sqrt[2*(25 - 5*Sqrt[5])] - 
      2500*Sqrt[2*(5 - Sqrt[5])] + 1000*Sqrt[10*(5 - Sqrt[5])] + 
      196*Sqrt[2*(5 + Sqrt[5])] + 100*Sqrt[10*(5 + Sqrt[5])] + 
      80*Sqrt[2*(25 - 5*Sqrt[5])]*x - 32*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      80*Sqrt[2*(5 - Sqrt[5])]*x - 32*Sqrt[10*(5 - Sqrt[5])]*x - 
      152*Sqrt[2*(5 + Sqrt[5])]*x + 96*Sqrt[10*(5 + Sqrt[5])]*x - 
      26*Sqrt[(50 - 10*Sqrt[5])/5]*x^2 + 13*Sqrt[50 - 10*Sqrt[5]]*x^2 + 
      5*Sqrt[10 - 2*Sqrt[5]]*x^2 - 2*Sqrt[5*(10 - 2*Sqrt[5])]*x^2 - 
      34*Sqrt[2*(5 + Sqrt[5])]*x^2 + 12*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      216*Sqrt[5 - 2*Sqrt[5]]*x*y + 72*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      272*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 144*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 
      25*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 10*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 55*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 22*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 110*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 48*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 60*Sqrt[5 - 2*Sqrt[5]]*x^3*
       y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -4896*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 2448*Sqrt[2*(25 - 5*Sqrt[5])] + 
      5360*Sqrt[2*(5 - Sqrt[5])] - 2144*Sqrt[10*(5 - Sqrt[5])] - 
      448*Sqrt[2*(5 + Sqrt[5])] - 32*Sqrt[10*(5 + Sqrt[5])] + 
      780*Sqrt[2*(25 - 5*Sqrt[5])]*x - 312*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      1900*Sqrt[2*(5 - Sqrt[5])]*x - 760*Sqrt[10*(5 - Sqrt[5])]*x + 
      256*Sqrt[2*(5 + Sqrt[5])]*x - 136*Sqrt[10*(5 + Sqrt[5])]*x - 
      172*Sqrt[(50 - 10*Sqrt[5])/5]*x^2 + 86*Sqrt[50 - 10*Sqrt[5]]*x^2 + 
      150*Sqrt[10 - 2*Sqrt[5]]*x^2 - 60*Sqrt[5*(10 - 2*Sqrt[5])]*x^2 - 
      88*Sqrt[2*(5 + Sqrt[5])]*x^2 + 44*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      2*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 + Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      5*Sqrt[2*(5 - Sqrt[5])]*x^3 - 2*Sqrt[10*(5 - Sqrt[5])]*x^3 + 
      10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 4*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      272*Sqrt[5 - 2*Sqrt[5]]*x*y + 208*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      64*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 96*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      8*Sqrt[5 - 2*Sqrt[5]]*x^3*y - 10*Sqrt[50 - 10*Sqrt[5]]*x^2*y^2 + 
      4*Sqrt[5*(50 - 10*Sqrt[5])]*x^2*y^2 - 10*Sqrt[10 - 2*Sqrt[5]]*x^2*y^2 + 
      4*Sqrt[5*(10 - 2*Sqrt[5])]*x^2*y^2 + 40*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 
      20*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 5*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 2*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 15*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 6*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 90*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      40*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -208*Sqrt[2*(25 - 5*Sqrt[5])] - 176*Sqrt[2*(5 - Sqrt[5])] + 
      512*Sqrt[2*(5 + Sqrt[5])] + 32*Sqrt[10*(5 + Sqrt[5])] - 
      20*Sqrt[2*(25 - 5*Sqrt[5])]*x - 100*Sqrt[2*(5 - Sqrt[5])]*x + 
      56*Sqrt[2*(5 + Sqrt[5])]*x + 64*Sqrt[10*(5 + Sqrt[5])]*x - 
      12*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 12*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      12*Sqrt[2*(5 + Sqrt[5])]*x^2 - 12*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      2*Sqrt[10 - 2*Sqrt[5]]*x^3 - 5*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      Sqrt[10*(5 + Sqrt[5])]*x^3 + 192*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      32*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 96*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 
      32*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 12*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 
      4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 28*Sqrt[50 - 10*Sqrt[5]]*x^2*y^2 + 
      60*Sqrt[10 - 2*Sqrt[5]]*x^2*y^2 + 16*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      4*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 10*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      35*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 15*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      20*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 - 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     152*Sqrt[(2*(25 - 5*Sqrt[5]))/5] - 76*Sqrt[2*(25 - 5*Sqrt[5])] - 
      100*Sqrt[2*(5 - Sqrt[5])] + 40*Sqrt[10*(5 - Sqrt[5])] + 
      156*Sqrt[2*(5 + Sqrt[5])] - 20*Sqrt[10*(5 + Sqrt[5])] - 
      20*Sqrt[2*(25 - 5*Sqrt[5])]*x + 8*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      20*Sqrt[2*(5 - Sqrt[5])]*x + 8*Sqrt[10*(5 - Sqrt[5])]*x + 
      88*Sqrt[2*(5 + Sqrt[5])]*x - 24*Sqrt[10*(5 + Sqrt[5])]*x + 
      14*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 - 7*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      55*Sqrt[2*(5 - Sqrt[5])]*x^2 + 22*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      94*Sqrt[2*(5 + Sqrt[5])]*x^2 + 40*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      24*Sqrt[5 - 2*Sqrt[5]]*x*y + 24*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      48*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 
      35*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 14*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 85*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 34*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 270*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 124*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 60*Sqrt[5 - 2*Sqrt[5]]*x^3*
       y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     288*Sqrt[2*(25 - 5*Sqrt[5])] + 224*Sqrt[2*(5 - Sqrt[5])] - 
      528*Sqrt[2*(5 + Sqrt[5])] + 80*Sqrt[10*(5 + Sqrt[5])] + 
      52*Sqrt[2*(25 - 5*Sqrt[5])]*x - 140*Sqrt[2*(5 - Sqrt[5])]*x - 
      224*Sqrt[2*(5 + Sqrt[5])]*x + 120*Sqrt[10*(5 + Sqrt[5])]*x - 
      2*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 2*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      32*Sqrt[2*(5 + Sqrt[5])]*x^2 - 4*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 3*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 4*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      112*Sqrt[5 - 2*Sqrt[5]]*x*y - 16*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      96*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 8*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 
      6*Sqrt[50 - 10*Sqrt[5]]*x^2*y^2 - 10*Sqrt[10 - 2*Sqrt[5]]*x^2*y^2 - 
      200*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 84*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      11*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 25*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 + 90*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 8*(5 - 2*Sqrt[5])^(3/2)*x^3*y^3, -480*Sqrt[2*(25 - 5*Sqrt[5])] - 
      736*Sqrt[2*(5 - Sqrt[5])] + 912*Sqrt[2*(5 + Sqrt[5])] + 
      176*Sqrt[10*(5 + Sqrt[5])] + 20*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      20*Sqrt[2*(5 - Sqrt[5])]*x + 16*Sqrt[2*(5 + Sqrt[5])]*x + 
      24*Sqrt[10*(5 + Sqrt[5])]*x + 8*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      8*Sqrt[2*(5 + Sqrt[5])]*x^2 - 16*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      2*Sqrt[10 - 2*Sqrt[5]]*x^3 - 5*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      Sqrt[10*(5 + Sqrt[5])]*x^3 + 192*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      160*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 384*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 
      192*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 12*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 
      4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 24*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      40*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 60*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 
      20*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 4*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 10*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 35*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 15*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 20*Sqrt[5 - 2*Sqrt[5]]*x^3*
       y^3 - 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -88*Sqrt[2*(25 - 5*Sqrt[5])] - 136*Sqrt[2*(5 - Sqrt[5])] + 
      232*Sqrt[2*(5 + Sqrt[5])] + 72*Sqrt[10*(5 + Sqrt[5])] - 
      8*Sqrt[2*(25 - 5*Sqrt[5])]*x - 160*Sqrt[2*(5 - Sqrt[5])]*x + 
      76*Sqrt[2*(5 + Sqrt[5])]*x + 100*Sqrt[10*(5 + Sqrt[5])]*x - 
      12*Sqrt[10 - 2*Sqrt[5]]*x^2 - 18*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      26*Sqrt[10*(5 + Sqrt[5])]*x^2 - Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      3*Sqrt[2*(5 - Sqrt[5])]*x^3 + 10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      4*Sqrt[10*(5 + Sqrt[5])]*x^3 + 432*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      176*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 464*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 
      208*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 8*Sqrt[5 - 2*Sqrt[5]]*x^3*y - 
      88*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 180*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 + 250*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 114*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 11*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      25*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 90*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 
      40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 8*(5 - 2*Sqrt[5])^(3/2)*x^3*y^3, 
     -728*Sqrt[(50 - 10*Sqrt[5])/5] + 364*Sqrt[50 - 10*Sqrt[5]] + 
      780*Sqrt[10 - 2*Sqrt[5]] - 312*Sqrt[5*(10 - 2*Sqrt[5])] - 
      64*Sqrt[2*(5 + Sqrt[5])] + 24*Sqrt[10*(5 + Sqrt[5])] + 
      170*Sqrt[2*(25 - 5*Sqrt[5])]*x - 68*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      330*Sqrt[2*(5 - Sqrt[5])]*x - 132*Sqrt[10*(5 - Sqrt[5])]*x - 
      92*Sqrt[2*(5 + Sqrt[5])]*x + 56*Sqrt[10*(5 + Sqrt[5])]*x - 
      6*Sqrt[(50 - 10*Sqrt[5])/5]*x^2 + 3*Sqrt[50 - 10*Sqrt[5]]*x^2 - 
      25*Sqrt[10 - 2*Sqrt[5]]*x^2 + 10*Sqrt[5*(10 - 2*Sqrt[5])]*x^2 - 
      44*Sqrt[2*(5 + Sqrt[5])]*x^2 + 18*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      136*Sqrt[5 - 2*Sqrt[5]]*x*y + 56*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      48*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 
      45*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 18*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 175*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 70*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 + 440*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 
      194*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      60*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     192*Sqrt[(2*(25 - 5*Sqrt[5]))/5] - 96*Sqrt[2*(25 - 5*Sqrt[5])] - 
      160*Sqrt[2*(5 - Sqrt[5])] + 64*Sqrt[10*(5 - Sqrt[5])] + 
      256*Sqrt[2*(5 + Sqrt[5])] + 32*Sqrt[10*(5 + Sqrt[5])] - 
      100*Sqrt[2*(25 - 5*Sqrt[5])]*x + 40*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      260*Sqrt[2*(5 - Sqrt[5])]*x + 104*Sqrt[10*(5 - Sqrt[5])]*x - 
      72*Sqrt[2*(5 + Sqrt[5])]*x + 32*Sqrt[10*(5 + Sqrt[5])]*x + 
      24*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 - 12*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      60*Sqrt[2*(5 - Sqrt[5])]*x^2 + 24*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      64*Sqrt[2*(5 + Sqrt[5])]*x^2 + 24*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      256*Sqrt[5 - 2*Sqrt[5]]*x*y + 128*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      48*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 
      40*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 16*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 80*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 32*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 300*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 140*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 60*Sqrt[5 - 2*Sqrt[5]]*x^3*
       y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     248*Sqrt[2*(25 - 5*Sqrt[5])] + 344*Sqrt[2*(5 - Sqrt[5])] - 
      128*Sqrt[2*(5 + Sqrt[5])] + 80*Sqrt[10*(5 + Sqrt[5])] - 
      8*Sqrt[2*(25 - 5*Sqrt[5])]*x - 200*Sqrt[2*(5 - Sqrt[5])]*x - 
      184*Sqrt[2*(5 + Sqrt[5])]*x + 56*Sqrt[10*(5 + Sqrt[5])]*x - 
      4*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 12*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      8*Sqrt[2*(5 + Sqrt[5])]*x^2 + 8*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 3*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 4*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      128*Sqrt[5 - 2*Sqrt[5]]*x*y - 32*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      96*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 8*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 
      72*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 160*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 - 320*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 136*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 11*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      25*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 90*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 
      40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 8*(5 - 2*Sqrt[5])^(3/2)*x^3*y^3, 
     5344*Sqrt[(2*(25 - 5*Sqrt[5]))/5] - 2672*Sqrt[2*(25 - 5*Sqrt[5])] - 
      5840*Sqrt[2*(5 - Sqrt[5])] + 2336*Sqrt[10*(5 - Sqrt[5])] + 
      912*Sqrt[2*(5 + Sqrt[5])] + 208*Sqrt[10*(5 + Sqrt[5])] + 
      260*Sqrt[2*(25 - 5*Sqrt[5])]*x - 104*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      580*Sqrt[2*(5 - Sqrt[5])]*x - 232*Sqrt[10*(5 - Sqrt[5])]*x + 
      16*Sqrt[2*(5 + Sqrt[5])]*x + 24*Sqrt[10*(5 + Sqrt[5])]*x - 
      32*Sqrt[(50 - 10*Sqrt[5])/5]*x^2 + 16*Sqrt[50 - 10*Sqrt[5]]*x^2 + 
      40*Sqrt[10 - 2*Sqrt[5]]*x^2 - 16*Sqrt[5*(10 - 2*Sqrt[5])]*x^2 - 
      8*Sqrt[2*(5 + Sqrt[5])]*x^2 - 16*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      8*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 - 4*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      10*Sqrt[2*(5 - Sqrt[5])]*x^3 + 4*Sqrt[10*(5 - Sqrt[5])]*x^3 - 
      5*Sqrt[2*(5 + Sqrt[5])]*x^3 + Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      208*Sqrt[5 - 2*Sqrt[5]]*x*y - 80*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      384*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 192*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 
      12*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 
      40*Sqrt[50 - 10*Sqrt[5]]*x^2*y^2 + 16*Sqrt[5*(50 - 10*Sqrt[5])]*x^2*
       y^2 + 120*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 48*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 10*Sqrt[10 - 2*Sqrt[5]]*x^3*y^2 + 4*Sqrt[5*(10 - 2*Sqrt[5])]*
       x^3*y^2 - 35*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 15*Sqrt[10*(5 + Sqrt[5])]*
       x^3*y^2 + 20*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 - 4*Sqrt[5*(5 - 2*Sqrt[5])]*
       x^3*y^3, -416*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 
      208*Sqrt[2*(25 - 5*Sqrt[5])] + 400*Sqrt[2*(5 - Sqrt[5])] - 
      160*Sqrt[10*(5 - Sqrt[5])] + 192*Sqrt[2*(5 + Sqrt[5])] + 
      160*Sqrt[10*(5 + Sqrt[5])] + 120*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      48*Sqrt[10*(25 - 5*Sqrt[5])]*x + 160*Sqrt[2*(5 - Sqrt[5])]*x - 
      64*Sqrt[10*(5 - Sqrt[5])]*x + 36*Sqrt[2*(5 + Sqrt[5])]*x + 
      188*Sqrt[10*(5 + Sqrt[5])]*x - 12*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 + 
      6*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 10*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      4*Sqrt[10*(5 - Sqrt[5])]*x^2 + 22*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      14*Sqrt[10*(5 + Sqrt[5])]*x^2 - 2*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 + 
      Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 5*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      2*Sqrt[10*(5 - Sqrt[5])]*x^3 + 10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      4*Sqrt[10*(5 + Sqrt[5])]*x^3 + 352*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      192*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 464*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 
      208*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 8*Sqrt[5 - 2*Sqrt[5]]*x^3*y - 
      50*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 20*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 70*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 28*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 130*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 62*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 5*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      2*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 15*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 6*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 90*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 40*Sqrt[5 - 2*Sqrt[5]]*x^3*
       y^3 + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -1728*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 864*Sqrt[2*(25 - 5*Sqrt[5])] + 
      1920*Sqrt[2*(5 - Sqrt[5])] - 768*Sqrt[10*(5 - Sqrt[5])] + 
      16*Sqrt[2*(5 + Sqrt[5])] + 16*Sqrt[10*(5 + Sqrt[5])] + 
      280*Sqrt[2*(25 - 5*Sqrt[5])]*x - 112*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      640*Sqrt[2*(5 - Sqrt[5])]*x - 256*Sqrt[10*(5 - Sqrt[5])]*x + 
      68*Sqrt[2*(5 + Sqrt[5])]*x + 12*Sqrt[10*(5 + Sqrt[5])]*x - 
      16*Sqrt[(50 - 10*Sqrt[5])/5]*x^2 + 8*Sqrt[50 - 10*Sqrt[5]]*x^2 - 
      20*Sqrt[10 - 2*Sqrt[5]]*x^2 + 8*Sqrt[5*(10 - 2*Sqrt[5])]*x^2 - 
      74*Sqrt[2*(5 + Sqrt[5])]*x^2 + 34*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      416*Sqrt[5 - 2*Sqrt[5]]*x*y + 192*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      48*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 
      40*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 16*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 180*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 72*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 + 410*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 
      178*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      60*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -64*Sqrt[2*(25 - 5*Sqrt[5])] + 64*Sqrt[2*(5 - Sqrt[5])] + 
      512*Sqrt[2*(5 + Sqrt[5])] + 64*Sqrt[10*(5 + Sqrt[5])] - 
      12*Sqrt[2*(25 - 5*Sqrt[5])]*x - 60*Sqrt[2*(5 - Sqrt[5])]*x + 
      56*Sqrt[2*(5 + Sqrt[5])]*x + 64*Sqrt[10*(5 + Sqrt[5])]*x - 
      12*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 12*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      12*Sqrt[2*(5 + Sqrt[5])]*x^2 - 12*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      2*Sqrt[10 - 2*Sqrt[5]]*x^3 - 5*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      Sqrt[10*(5 + Sqrt[5])]*x^3 + 752*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      368*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 96*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 
      32*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 12*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 
      4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 36*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      60*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 60*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 
      44*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 4*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 10*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 35*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 15*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 20*Sqrt[5 - 2*Sqrt[5]]*x^3*
       y^3 - 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -3456*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 1728*Sqrt[2*(25 - 5*Sqrt[5])] + 
      3840*Sqrt[2*(5 - Sqrt[5])] - 1536*Sqrt[10*(5 - Sqrt[5])] + 
      32*Sqrt[2*(5 + Sqrt[5])] + 32*Sqrt[10*(5 + Sqrt[5])] + 
      280*Sqrt[2*(25 - 5*Sqrt[5])]*x - 112*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      720*Sqrt[2*(5 - Sqrt[5])]*x - 288*Sqrt[10*(5 - Sqrt[5])]*x - 
      4*Sqrt[2*(5 + Sqrt[5])]*x - 124*Sqrt[10*(5 + Sqrt[5])]*x - 
      132*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 + 66*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2 + 110*Sqrt[2*(5 - Sqrt[5])]*x^2 - 44*Sqrt[10*(5 - Sqrt[5])]*x^2 + 
      52*Sqrt[2/5]*(5 + Sqrt[5])^(3/2)*x^2 - 26*Sqrt[2]*(5 + Sqrt[5])^(3/2)*
       x^2 - 2*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 + Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3 + 5*Sqrt[2*(5 - Sqrt[5])]*x^3 - 2*Sqrt[10*(5 - Sqrt[5])]*x^3 + 
      10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 4*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      192*Sqrt[5 - 2*Sqrt[5]]*x*y + 96*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      16*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      8*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 50*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      20*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 10*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 + 4*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 170*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 70*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 5*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 2*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      15*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 6*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      90*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      40*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -208*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 104*Sqrt[2*(25 - 5*Sqrt[5])] + 
      200*Sqrt[2*(5 - Sqrt[5])] - 80*Sqrt[10*(5 - Sqrt[5])] + 
      96*Sqrt[2*(5 + Sqrt[5])] + 80*Sqrt[10*(5 + Sqrt[5])] + 
      20*Sqrt[50 - 10*Sqrt[5]]*x - 8*Sqrt[5*(50 - 10*Sqrt[5])]*x - 
      20*Sqrt[10 - 2*Sqrt[5]]*x + 8*Sqrt[5*(10 - 2*Sqrt[5])]*x - 
      132*Sqrt[2*(5 + Sqrt[5])]*x + 44*Sqrt[10*(5 + Sqrt[5])]*x + 
      4*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 - 2*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      30*Sqrt[2*(5 - Sqrt[5])]*x^2 + 12*Sqrt[10*(5 - Sqrt[5])]*x^2 + 
      36*Sqrt[2/5]*(5 + Sqrt[5])^(3/2)*x^2 - 18*Sqrt[2]*(5 + Sqrt[5])^(3/2)*
       x^2 + 4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      144*Sqrt[5 - 2*Sqrt[5]]*x*y - 48*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      32*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 32*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 
      70*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 28*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 190*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 76*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 - 530*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 
      238*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      60*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     2672*Sqrt[(2*(25 - 5*Sqrt[5]))/5] - 1336*Sqrt[2*(25 - 5*Sqrt[5])] - 
      2920*Sqrt[2*(5 - Sqrt[5])] + 1168*Sqrt[10*(5 - Sqrt[5])] + 
      456*Sqrt[2*(5 + Sqrt[5])] + 104*Sqrt[10*(5 + Sqrt[5])] + 
      100*Sqrt[2*(25 - 5*Sqrt[5])]*x - 40*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      180*Sqrt[2*(5 - Sqrt[5])]*x - 72*Sqrt[10*(5 - Sqrt[5])]*x + 
      8*Sqrt[2*(5 + Sqrt[5])]*x + 64*Sqrt[10*(5 + Sqrt[5])]*x - 
      36*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 + 18*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      10*Sqrt[2*(5 - Sqrt[5])]*x^2 - 4*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      64*Sqrt[2*(5 + Sqrt[5])]*x^2 + 28*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 - 2*Sqrt[50 - 10*Sqrt[5]]*x^3 + 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 - 7*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      16*Sqrt[5 - 2*Sqrt[5]]*x*y + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      272*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 144*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 
      30*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 12*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 50*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 20*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 140*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 64*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 20*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 145*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 60*Sqrt[5 - 2*Sqrt[5]]*x^3*
       y^3 + 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -3856*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 1928*Sqrt[2*(25 - 5*Sqrt[5])] + 
      4200*Sqrt[2*(5 - Sqrt[5])] - 1680*Sqrt[10*(5 - Sqrt[5])] - 
      128*Sqrt[2*(5 + Sqrt[5])] + 80*Sqrt[10*(5 + Sqrt[5])] + 
      1080*Sqrt[2*(25 - 5*Sqrt[5])]*x - 432*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      2520*Sqrt[2*(5 - Sqrt[5])]*x - 1008*Sqrt[10*(5 - Sqrt[5])]*x + 
      216*Sqrt[2*(5 + Sqrt[5])]*x - 24*Sqrt[10*(5 + Sqrt[5])]*x - 
      232*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 + 116*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2 + 220*Sqrt[2*(5 - Sqrt[5])]*x^2 - 88*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      48*Sqrt[2*(5 + Sqrt[5])]*x^2 + 32*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      2*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 + Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      5*Sqrt[2*(5 - Sqrt[5])]*x^3 - 2*Sqrt[10*(5 - Sqrt[5])]*x^3 + 
      10*Sqrt[2*(5 + Sqrt[5])]*x^3 - 4*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      672*Sqrt[5 - 2*Sqrt[5]]*x*y + 320*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      64*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 96*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      8*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 160*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 
      72*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 160*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 
      72*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 5*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 2*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 15*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 6*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 90*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      40*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -192*Sqrt[2*(25 - 5*Sqrt[5])] - 320*Sqrt[2*(5 - Sqrt[5])] + 
      480*Sqrt[2*(5 + Sqrt[5])] + 224*Sqrt[10*(5 + Sqrt[5])] - 
      280*Sqrt[10 - 2*Sqrt[5]]*x - 60*Sqrt[2*(5 + Sqrt[5])]*x + 
      124*Sqrt[10*(5 + Sqrt[5])]*x + 2*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      50*Sqrt[2*(5 - Sqrt[5])]*x^2 - 70*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      26*Sqrt[10*(5 + Sqrt[5])]*x^2 - 3*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      5*Sqrt[2*(5 - Sqrt[5])]*x^3 + 20*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3 + 480*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      288*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 160*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 
      32*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 8*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 
      170*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 370*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 - 570*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 270*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 25*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      55*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 200*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 
      90*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 80*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 
      40*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, -1600*Sqrt[2*(25 - 5*Sqrt[5])] + 
      640*Sqrt[10*(25 - 5*Sqrt[5])] - 3520*Sqrt[2*(5 - Sqrt[5])] + 
      1408*Sqrt[10*(5 - Sqrt[5])] + 480*Sqrt[2*(5 + Sqrt[5])] + 
      224*Sqrt[10*(5 + Sqrt[5])] - 400*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      160*Sqrt[10*(25 - 5*Sqrt[5])]*x - 1000*Sqrt[2*(5 - Sqrt[5])]*x + 
      400*Sqrt[10*(5 - Sqrt[5])]*x - 140*Sqrt[2*(5 + Sqrt[5])]*x + 
      44*Sqrt[10*(5 + Sqrt[5])]*x + 40*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      16*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 20*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      8*Sqrt[10*(5 - Sqrt[5])]*x^2 - 130*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      58*Sqrt[10*(5 + Sqrt[5])]*x^2 + 10*Sqrt[10 - 2*Sqrt[5]]*x^3 - 
      4*Sqrt[5*(10 - 2*Sqrt[5])]*x^3 + 35*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      15*Sqrt[10*(5 + Sqrt[5])]*x^3 + 240*Sqrt[5 - 2*Sqrt[5]]*x*y - 
      80*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 80*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 
      80*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 20*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 
      4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 64*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 300*Sqrt[2*(5 - Sqrt[5])]*
       x^2*y^2 + 120*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 
      1070*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 470*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y^2 - 20*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      8*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 50*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 20*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 325*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 145*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      140*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 60*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -1600*Sqrt[2*(25 - 5*Sqrt[5])] + 640*Sqrt[10*(25 - 5*Sqrt[5])] - 
      3520*Sqrt[2*(5 - Sqrt[5])] + 1408*Sqrt[10*(5 - Sqrt[5])] + 
      480*Sqrt[2*(5 + Sqrt[5])] + 224*Sqrt[10*(5 + Sqrt[5])] + 
      140*Sqrt[50 - 10*Sqrt[5]]*x - 56*Sqrt[5*(50 - 10*Sqrt[5])]*x + 
      300*Sqrt[10 - 2*Sqrt[5]]*x - 120*Sqrt[5*(10 - 2*Sqrt[5])]*x + 
      40*Sqrt[2*(5 + Sqrt[5])]*x - 16*Sqrt[10*(5 + Sqrt[5])]*x + 
      10*Sqrt[50 - 10*Sqrt[5]]*x^2 - 4*Sqrt[5*(50 - 10*Sqrt[5])]*x^2 - 
      30*Sqrt[10 - 2*Sqrt[5]]*x^2 + 12*Sqrt[5*(10 - 2*Sqrt[5])]*x^2 - 
      120*Sqrt[2*(5 + Sqrt[5])]*x^2 + 36*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      5*Sqrt[50 - 10*Sqrt[5]]*x^3 + 2*Sqrt[5*(50 - 10*Sqrt[5])]*x^3 - 
      5*Sqrt[10 - 2*Sqrt[5]]*x^3 + 2*Sqrt[5*(10 - 2*Sqrt[5])]*x^3 + 
      20*Sqrt[2*(5 + Sqrt[5])]*x^3 - 10*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      320*Sqrt[5 - 2*Sqrt[5]]*x*y - 224*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 
      8*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 130*Sqrt[50 - 10*Sqrt[5]]*x^2*y^2 - 
      52*Sqrt[5*(50 - 10*Sqrt[5])]*x^2*y^2 - 350*Sqrt[10 - 2*Sqrt[5]]*x^2*
       y^2 + 140*Sqrt[5*(10 - 2*Sqrt[5])]*x^2*y^2 - 
      1060*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 480*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y^2 - 15*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      6*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 25*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 10*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 200*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 90*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      80*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 40*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -72*Sqrt[2*(25 - 5*Sqrt[5])] - 128*Sqrt[2*(5 - Sqrt[5])] + 
      276*Sqrt[2*(5 + Sqrt[5])] + 92*Sqrt[10*(5 + Sqrt[5])] + 
      4*Sqrt[2*(25 - 5*Sqrt[5])]*x + 32*Sqrt[2*(5 - Sqrt[5])]*x + 
      114*Sqrt[2*(5 + Sqrt[5])]*x + 38*Sqrt[10*(5 + Sqrt[5])]*x + 
      2*Sqrt[50 - 10*Sqrt[5]]*x^2 + 3*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      5*Sqrt[10*(5 + Sqrt[5])]*x^2 + 136*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      72*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 328*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 
      152*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 10*Sqrt[50 - 10*Sqrt[5]]*x^2*y^2 + 
      20*Sqrt[10 - 2*Sqrt[5]]*x^2*y^2 + 35*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 
      19*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2, 420*Sqrt[2*(25 - 5*Sqrt[5])] - 
      168*Sqrt[10*(25 - 5*Sqrt[5])] + 980*Sqrt[2*(5 - Sqrt[5])] - 
      392*Sqrt[10*(5 - Sqrt[5])] + 80*Sqrt[2*(5 + Sqrt[5])] - 
      56*Sqrt[10*(5 + Sqrt[5])] + 160*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x + 280*Sqrt[2*(5 - Sqrt[5])]*x - 
      112*Sqrt[10*(5 - Sqrt[5])]*x - 130*Sqrt[2*(5 + Sqrt[5])]*x + 
      66*Sqrt[10*(5 + Sqrt[5])]*x + 5*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      2*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 25*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      10*Sqrt[10*(5 - Sqrt[5])]*x^2 + 20*Sqrt[2*(5 + Sqrt[5])]*x^2 - 
      8*Sqrt[10*(5 + Sqrt[5])]*x^2 + 100*Sqrt[5 - 2*Sqrt[5]]*x*y + 
      52*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 25*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      10*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 + 75*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 - 30*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 180*Sqrt[2*(5 + Sqrt[5])]*
       x^2*y^2 - 80*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2, 
     2320*Sqrt[2*(25 - 5*Sqrt[5])] - 928*Sqrt[10*(25 - 5*Sqrt[5])] + 
      5200*Sqrt[2*(5 - Sqrt[5])] - 2080*Sqrt[10*(5 - Sqrt[5])] + 
      320*Sqrt[2*(5 + Sqrt[5])] + 160*Sqrt[10*(5 + Sqrt[5])] + 
      680*Sqrt[2*(25 - 5*Sqrt[5])]*x - 272*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      1680*Sqrt[2*(5 - Sqrt[5])]*x - 672*Sqrt[10*(5 - Sqrt[5])]*x + 
      420*Sqrt[2*(5 + Sqrt[5])]*x - 100*Sqrt[10*(5 + Sqrt[5])]*x + 
      10*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 4*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 
      50*Sqrt[2*(5 - Sqrt[5])]*x^2 + 20*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      170*Sqrt[2*(5 + Sqrt[5])]*x^2 + 70*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      5*Sqrt[50 - 10*Sqrt[5]]*x^3 + 2*Sqrt[5*(50 - 10*Sqrt[5])]*x^3 - 
      5*Sqrt[10 - 2*Sqrt[5]]*x^3 + 2*Sqrt[5*(10 - 2*Sqrt[5])]*x^3 + 
      20*Sqrt[2*(5 + Sqrt[5])]*x^3 - 10*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      1440*Sqrt[5 - 2*Sqrt[5]]*x*y + 768*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      240*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 
      8*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      4*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 + 150*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 - 60*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 
      70*Sqrt[2]*(5 + Sqrt[5])^(3/2)*x^2*y^2 - 
      28*Sqrt[10]*(5 + Sqrt[5])^(3/2)*x^2*y^2 - 15*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 6*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      25*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 10*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      200*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 90*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      80*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 40*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     28*Sqrt[2*(5 - Sqrt[5])] + 12*Sqrt[10*(5 - Sqrt[5])] + 
      84*Sqrt[2*(5 + Sqrt[5])] + 36*Sqrt[10*(5 + Sqrt[5])] - 
      8*Sqrt[2*(5 - Sqrt[5])]*x - 4*Sqrt[10*(5 - Sqrt[5])]*x - 
      16*Sqrt[2*(5 + Sqrt[5])]*x - 8*Sqrt[10*(5 + Sqrt[5])]*x - 
      3*Sqrt[2*(5 + Sqrt[5])]*x^2 - Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      120*Sqrt[5 - 2*Sqrt[5]]*x*y + 56*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      5*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - Sqrt[10*(5 + Sqrt[5])]*x^2*y^2, 
     20*Sqrt[2*(5 - Sqrt[5])] + 4*Sqrt[10*(5 - Sqrt[5])] + 
      60*Sqrt[2*(5 + Sqrt[5])] + 12*Sqrt[10*(5 + Sqrt[5])] - 
      4*Sqrt[50 - 10*Sqrt[5]]*x - 8*Sqrt[10*(5 + Sqrt[5])]*x - 
      5*Sqrt[2*(5 + Sqrt[5])]*x^2 + Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      20*Sqrt[5 - 2*Sqrt[5]]*x*y - 20*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      35*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 15*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2, 
     -2840*Sqrt[2*(25 - 5*Sqrt[5])] + 1136*Sqrt[10*(25 - 5*Sqrt[5])] - 
      6200*Sqrt[2*(5 - Sqrt[5])] + 2480*Sqrt[10*(5 - Sqrt[5])] + 
      1280*Sqrt[2*(5 + Sqrt[5])] + 400*Sqrt[10*(5 + Sqrt[5])] + 
      320*Sqrt[2*(25 - 5*Sqrt[5])]*x - 128*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      720*Sqrt[2*(5 - Sqrt[5])]*x - 288*Sqrt[10*(5 - Sqrt[5])]*x + 
      240*Sqrt[2*(5 + Sqrt[5])]*x + 32*Sqrt[10*(5 + Sqrt[5])]*x + 
      40*Sqrt[50 - 10*Sqrt[5]]*x^2 - 16*Sqrt[5*(50 - 10*Sqrt[5])]*x^2 + 
      40*Sqrt[10 - 2*Sqrt[5]]*x^2 - 16*Sqrt[5*(10 - 2*Sqrt[5])]*x^2 - 
      140*Sqrt[2*(5 + Sqrt[5])]*x^2 + 52*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      5*Sqrt[50 - 10*Sqrt[5]]*x^3 + 2*Sqrt[5*(50 - 10*Sqrt[5])]*x^3 - 
      5*Sqrt[10 - 2*Sqrt[5]]*x^3 + 2*Sqrt[5*(10 - 2*Sqrt[5])]*x^3 + 
      20*Sqrt[2*(5 + Sqrt[5])]*x^3 - 10*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      480*Sqrt[5 - 2*Sqrt[5]]*x*y - 192*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      480*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 256*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 
      8*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 60*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      24*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 300*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 + 120*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 300*Sqrt[2*(5 + Sqrt[5])]*
       x^2*y^2 + 140*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      15*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 6*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 25*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 10*Sqrt[10*(5 - Sqrt[5])]*x^3*
       y^2 + 200*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 90*Sqrt[10*(5 + Sqrt[5])]*
       x^3*y^2 - 80*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 40*Sqrt[5*(5 - 2*Sqrt[5])]*
       x^3*y^3, 2160*Sqrt[2*(25 - 5*Sqrt[5])] - 
      864*Sqrt[10*(25 - 5*Sqrt[5])] + 4560*Sqrt[2*(5 - Sqrt[5])] - 
      1824*Sqrt[10*(5 - Sqrt[5])] - 80*Sqrt[2*(5 + Sqrt[5])] + 
      368*Sqrt[10*(5 + Sqrt[5])] + 900*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      360*Sqrt[10*(25 - 5*Sqrt[5])]*x + 1860*Sqrt[2*(5 - Sqrt[5])]*x - 
      744*Sqrt[10*(5 - Sqrt[5])]*x + 264*Sqrt[10*(5 + Sqrt[5])]*x + 
      80*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 32*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 
      120*Sqrt[2*(5 - Sqrt[5])]*x^2 - 48*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      40*Sqrt[2*(5 + Sqrt[5])]*x^2 + 48*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      10*Sqrt[10 - 2*Sqrt[5]]*x^3 - 4*Sqrt[5*(10 - 2*Sqrt[5])]*x^3 + 
      35*Sqrt[2*(5 + Sqrt[5])]*x^3 - 15*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      880*Sqrt[5 - 2*Sqrt[5]]*x*y + 304*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      320*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 128*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      20*Sqrt[5 - 2*Sqrt[5]]*x^3*y + 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y - 
      200*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 400*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 160*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 + 1240*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 
      560*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 20*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 8*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 50*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 20*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      325*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 145*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 140*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 60*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*
       y^3}
 
F831 = {760*Sqrt[25 - 5*Sqrt[5]] - 304*Sqrt[5*(25 - 5*Sqrt[5])] + 
      3400*Sqrt[5 - Sqrt[5]] - 1360*Sqrt[5*(5 - Sqrt[5])] + 
      2480*Sqrt[5 + Sqrt[5]] - 1200*Sqrt[5*(5 + Sqrt[5])] - 
      140*Sqrt[25 - 5*Sqrt[5]]*x + 56*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      2100*Sqrt[5 - Sqrt[5]]*x - 840*Sqrt[5*(5 - Sqrt[5])]*x + 
      3640*Sqrt[5 + Sqrt[5]]*x - 1520*Sqrt[5*(5 + Sqrt[5])]*x - 
      200*Sqrt[25 - 5*Sqrt[5]]*x^2 + 80*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      200*Sqrt[5 - Sqrt[5]]*x^2 + 80*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      80*Sqrt[5 + Sqrt[5]]*x^2 - 20*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 - 100*Sqrt[5 - Sqrt[5]]*x^3 + 
      40*Sqrt[5*(5 - Sqrt[5])]*x^3 - 200*Sqrt[5 + Sqrt[5]]*x^3 + 
      80*Sqrt[5*(5 + Sqrt[5])]*x^3 - 10*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 1750*Sqrt[5 - Sqrt[5]]*x*y + 
      700*Sqrt[5*(5 - Sqrt[5])]*x*y - 2630*Sqrt[5 + Sqrt[5]]*x*y + 
      1130*Sqrt[5*(5 + Sqrt[5])]*x*y + 390*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      156*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 350*Sqrt[5 - Sqrt[5]]*x^2*y - 
      140*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 200*Sqrt[5 + Sqrt[5]]*x^2*y + 
      20*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 150*Sqrt[5 - Sqrt[5]]*x^3*y - 
      60*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 730*Sqrt[5 + Sqrt[5]]*x^3*y - 
      310*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 185*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      74*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 - 75*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      30*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 65*(5 + Sqrt[5])^(3/2)*x^2*y^2 - 
      26*Sqrt[5]*(5 + Sqrt[5])^(3/2)*x^2*y^2 + 75*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^2 - 30*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 125*Sqrt[5 - Sqrt[5]]*x^3*
       y^2 + 50*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 - 940*Sqrt[5 + Sqrt[5]]*x^3*
       y^2 + 410*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 + 50*Sqrt[5 - Sqrt[5]]*x^3*
       y^3 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 430*Sqrt[5 + Sqrt[5]]*x^3*
       y^3 - 190*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     376*Sqrt[(25 - 5*Sqrt[5])/5] - 188*Sqrt[25 - 5*Sqrt[5]] - 
      380*Sqrt[5 - Sqrt[5]] + 152*Sqrt[5*(5 - Sqrt[5])] + 
      96*Sqrt[5 + Sqrt[5]] - 8*Sqrt[5*(5 + Sqrt[5])] - 
      904*Sqrt[(25 - 5*Sqrt[5])/5]*x + 452*Sqrt[25 - 5*Sqrt[5]]*x + 
      220*Sqrt[5 - Sqrt[5]]*x - 88*Sqrt[5*(5 - Sqrt[5])]*x - 
      1212*Sqrt[5 + Sqrt[5]]*x + 532*Sqrt[5*(5 + Sqrt[5])]*x - 
      200*Sqrt[25 - 5*Sqrt[5]]*x^2 + 80*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      796*Sqrt[5 + Sqrt[5]]*x^2 - 364*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 16*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      120*Sqrt[5 + Sqrt[5]]*x^3 + 56*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      584*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 292*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      260*Sqrt[5 - Sqrt[5]]*x*y - 104*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      1364*Sqrt[5 + Sqrt[5]]*x*y - 604*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      636*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 318*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      330*Sqrt[5 - Sqrt[5]]*x^2*y + 132*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      1880*Sqrt[5 + Sqrt[5]]*x^2*y + 852*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 36*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      60*Sqrt[5 - Sqrt[5]]*x^3*y - 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      456*Sqrt[5 + Sqrt[5]]*x^3*y - 208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      324*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 162*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 300*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 120*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 1169*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 525*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 598*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 270*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 18*Sqrt[25 - 5*Sqrt[5]]*
       x^3*y^3 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 276*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 124*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, 96*Sqrt[(25 - 5*Sqrt[5])/5] - 48*Sqrt[25 - 5*Sqrt[5]] - 
      280*Sqrt[5 - Sqrt[5]] + 112*Sqrt[5*(5 - Sqrt[5])] - 
      244*Sqrt[5 + Sqrt[5]] + 132*Sqrt[5*(5 + Sqrt[5])] - 
      224*Sqrt[(25 - 5*Sqrt[5])/5]*x + 112*Sqrt[25 - 5*Sqrt[5]]*x + 
      320*Sqrt[5 - Sqrt[5]]*x - 128*Sqrt[5*(5 - Sqrt[5])]*x + 
      48*Sqrt[5 + Sqrt[5]]*x - 32*Sqrt[5*(5 + Sqrt[5])]*x - 
      160*Sqrt[25 - 5*Sqrt[5]]*x^2 + 64*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      40*Sqrt[5 - Sqrt[5]]*x^2 - 16*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      476*Sqrt[5 + Sqrt[5]]*x^2 - 220*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 16*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      120*Sqrt[5 + Sqrt[5]]*x^3 + 56*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      4*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 2*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      330*Sqrt[5 - Sqrt[5]]*x*y + 132*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      416*Sqrt[5 + Sqrt[5]]*x*y + 196*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      456*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 228*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      340*Sqrt[5 - Sqrt[5]]*x^2*y + 136*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      980*Sqrt[5 + Sqrt[5]]*x^2*y + 444*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 36*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      60*Sqrt[5 - Sqrt[5]]*x^3*y - 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      456*Sqrt[5 + Sqrt[5]]*x^3*y - 208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      184*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 92*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 230*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 92*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 449*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 201*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 598*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 270*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 18*Sqrt[25 - 5*Sqrt[5]]*
       x^3*y^3 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 276*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 124*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -24*Sqrt[(25 - 5*Sqrt[5])/5] + 12*Sqrt[25 - 5*Sqrt[5]] + 
      140*Sqrt[5 - Sqrt[5]] - 56*Sqrt[5*(5 - Sqrt[5])] + 
      176*Sqrt[5 + Sqrt[5]] - 72*Sqrt[5*(5 + Sqrt[5])] - 
      264*Sqrt[(25 - 5*Sqrt[5])/5]*x + 132*Sqrt[25 - 5*Sqrt[5]]*x + 
      340*Sqrt[5 - Sqrt[5]]*x - 136*Sqrt[5*(5 - Sqrt[5])]*x + 
      48*Sqrt[5 + Sqrt[5]]*x - 40*Sqrt[5*(5 + Sqrt[5])]*x - 
      60*Sqrt[25 - 5*Sqrt[5]]*x^2 + 24*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      60*Sqrt[5 - Sqrt[5]]*x^2 + 24*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      216*Sqrt[5 + Sqrt[5]]*x^2 - 80*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 4*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      20*Sqrt[5 - Sqrt[5]]*x^3 + 8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      40*Sqrt[5 + Sqrt[5]]*x^3 + 16*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      24*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 12*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      260*Sqrt[5 - Sqrt[5]]*x*y + 104*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      416*Sqrt[5 + Sqrt[5]]*x*y + 184*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      436*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 218*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      550*Sqrt[5 - Sqrt[5]]*x^2*y - 220*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      90*Sqrt[5 + Sqrt[5]]*x^2*y + 38*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      146*Sqrt[5 + Sqrt[5]]*x^3*y - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      174*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 87*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 375*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 150*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 176*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 74*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 25*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 188*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 82*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 + 10*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     16*Sqrt[(25 - 5*Sqrt[5])/5] - 8*Sqrt[25 - 5*Sqrt[5]] - 
      440*Sqrt[5 - Sqrt[5]] + 176*Sqrt[5*(5 - Sqrt[5])] - 
      624*Sqrt[5 + Sqrt[5]] + 304*Sqrt[5*(5 + Sqrt[5])] - 
      104*Sqrt[(25 - 5*Sqrt[5])/5]*x + 52*Sqrt[25 - 5*Sqrt[5]]*x + 
      180*Sqrt[5 - Sqrt[5]]*x - 72*Sqrt[5*(5 - Sqrt[5])]*x + 
      88*Sqrt[5 + Sqrt[5]]*x - 32*Sqrt[5*(5 + Sqrt[5])]*x - 
      60*Sqrt[25 - 5*Sqrt[5]]*x^2 + 24*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      180*Sqrt[5 - Sqrt[5]]*x^2 + 72*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      84*Sqrt[5 + Sqrt[5]]*x^2 + 12*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      40*Sqrt[5 - Sqrt[5]]*x^3 - 16*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      20*Sqrt[5 + Sqrt[5]]*x^3 - 4*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      104*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 52*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      340*Sqrt[5 - Sqrt[5]]*x*y + 136*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      316*Sqrt[5 + Sqrt[5]]*x*y + 132*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      496*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 248*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      720*Sqrt[5 - Sqrt[5]]*x^2*y - 288*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      240*Sqrt[5 + Sqrt[5]]*x^2*y - 72*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      64*Sqrt[5 + Sqrt[5]]*x^3*y + 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      224*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 112*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 380*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 152*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 176*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 68*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 77*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 29*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 14*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 7*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 + 5*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 2*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -28*Sqrt[25 - 5*Sqrt[5]] - 140*Sqrt[5 - Sqrt[5]] + 
      120*Sqrt[5 + Sqrt[5]] + 112*Sqrt[5*(5 + Sqrt[5])] + 
      52*Sqrt[25 - 5*Sqrt[5]]*x - 60*Sqrt[5 - Sqrt[5]]*x + 
      160*Sqrt[5 + Sqrt[5]]*x + 216*Sqrt[5*(5 + Sqrt[5])]*x + 
      60*Sqrt[25 - 5*Sqrt[5]]*x^2 + 300*Sqrt[5 - Sqrt[5]]*x^2 - 
      88*Sqrt[5*(5 + Sqrt[5])]*x^2 - 4*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 40*Sqrt[5 + Sqrt[5]]*x^3 - 
      72*Sqrt[25 - 5*Sqrt[5]]*x*y + 40*Sqrt[5 - Sqrt[5]]*x*y + 
      100*Sqrt[5 + Sqrt[5]]*x*y - 132*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      42*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 470*Sqrt[5 - Sqrt[5]]*x^2*y - 
      90*Sqrt[5 + Sqrt[5]]*x^2*y + 150*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 30*Sqrt[5 - Sqrt[5]]*x^3*y + 
      110*Sqrt[5 + Sqrt[5]]*x^3*y - 18*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      7*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 225*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      80*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 82*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 25*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      120*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 34*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      8*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 10*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      50*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 18*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     416*Sqrt[(25 - 5*Sqrt[5])/5] - 208*Sqrt[25 - 5*Sqrt[5]] - 
      960*Sqrt[5 - Sqrt[5]] + 384*Sqrt[5*(5 - Sqrt[5])] - 
      704*Sqrt[5 + Sqrt[5]] + 368*Sqrt[5*(5 + Sqrt[5])] - 
      744*Sqrt[(25 - 5*Sqrt[5])/5]*x + 372*Sqrt[25 - 5*Sqrt[5]]*x + 
      980*Sqrt[5 - Sqrt[5]]*x - 392*Sqrt[5*(5 - Sqrt[5])]*x + 
      168*Sqrt[5 + Sqrt[5]]*x - 112*Sqrt[5*(5 + Sqrt[5])]*x - 
      180*Sqrt[25 - 5*Sqrt[5]]*x^2 + 72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      460*Sqrt[5 - Sqrt[5]]*x^2 + 184*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      28*(5 + Sqrt[5])^(3/2)*x^2 + (56*(5 + Sqrt[5])^(3/2)*x^2)/Sqrt[5] - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      40*Sqrt[5 - Sqrt[5]]*x^3 - 16*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      20*Sqrt[5 + Sqrt[5]]*x^3 - 4*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      104*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 52*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      420*Sqrt[5 - Sqrt[5]]*x*y + 168*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      476*Sqrt[5 + Sqrt[5]]*x*y + 228*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      216*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 108*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      420*Sqrt[5 - Sqrt[5]]*x^2*y - 168*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      240*Sqrt[5 + Sqrt[5]]*x^2*y - 96*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      64*Sqrt[5 + Sqrt[5]]*x^3*y + 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 + 8*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      120*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 48*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 - 
      166*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 74*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      77*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 29*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      14*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 7*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      5*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 2*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     160*Sqrt[25 - 5*Sqrt[5]] - 64*Sqrt[5*(25 - 5*Sqrt[5])] + 
      3600*Sqrt[5 - Sqrt[5]] - 1440*Sqrt[5*(5 - Sqrt[5])] + 
      4880*Sqrt[5 + Sqrt[5]] - 2240*Sqrt[5*(5 + Sqrt[5])] + 
      60*Sqrt[25 - 5*Sqrt[5]]*x - 24*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      3700*Sqrt[5 - Sqrt[5]]*x + 1480*Sqrt[5*(5 - Sqrt[5])]*x - 
      5760*Sqrt[5 + Sqrt[5]]*x + 2680*Sqrt[5*(5 + Sqrt[5])]*x + 
      200*Sqrt[25 - 5*Sqrt[5]]*x^2 - 80*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      1400*Sqrt[5 - Sqrt[5]]*x^2 - 560*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      1880*Sqrt[5 + Sqrt[5]]*x^2 - 840*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 - 
      100*Sqrt[5 - Sqrt[5]]*x^3 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      200*Sqrt[5 + Sqrt[5]]*x^3 + 80*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      610*Sqrt[25 - 5*Sqrt[5]]*x*y + 244*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 
      3450*Sqrt[5 - Sqrt[5]]*x*y - 1380*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      7270*Sqrt[5 + Sqrt[5]]*x*y - 3330*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      490*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 196*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      1350*Sqrt[5 - Sqrt[5]]*x^2*y + 540*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      4900*Sqrt[5 + Sqrt[5]]*x^2*y + 2200*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 
      150*Sqrt[5 - Sqrt[5]]*x^3*y - 60*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      730*Sqrt[5 + Sqrt[5]]*x^3*y - 310*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      485*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 194*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 525*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 210*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 3145*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 1415*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 75*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 30*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 125*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 50*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 940*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 410*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 430*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 190*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -184*Sqrt[(25 - 5*Sqrt[5])/5] + 92*Sqrt[25 - 5*Sqrt[5]] - 
      180*Sqrt[5 - Sqrt[5]] + 72*Sqrt[5*(5 - Sqrt[5])] - 
      584*Sqrt[5 + Sqrt[5]] + 272*Sqrt[5*(5 + Sqrt[5])] + 
      136*Sqrt[(25 - 5*Sqrt[5])/5]*x - 68*Sqrt[25 - 5*Sqrt[5]]*x + 
      260*Sqrt[5 - Sqrt[5]]*x - 104*Sqrt[5*(5 - Sqrt[5])]*x + 
      588*Sqrt[5 + Sqrt[5]]*x - 260*Sqrt[5*(5 + Sqrt[5])]*x - 
      120*Sqrt[25 - 5*Sqrt[5]]*x^2 + 48*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      80*Sqrt[5 - Sqrt[5]]*x^2 - 32*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      396*Sqrt[5 + Sqrt[5]]*x^2 - 188*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 16*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      120*Sqrt[5 + Sqrt[5]]*x^3 + 56*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      216*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 108*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      460*Sqrt[5 - Sqrt[5]]*x*y + 184*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      1036*Sqrt[5 + Sqrt[5]]*x*y + 452*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      956*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 478*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      470*Sqrt[5 - Sqrt[5]]*x^2*y - 188*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      600*Sqrt[5 + Sqrt[5]]*x^2*y + 292*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 36*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      60*Sqrt[5 - Sqrt[5]]*x^3*y - 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      456*Sqrt[5 + Sqrt[5]]*x^3*y - 208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      484*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 242*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 300*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 120*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 169*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 85*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 598*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 270*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 18*Sqrt[25 - 5*Sqrt[5]]*
       x^3*y^3 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 276*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 124*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -64*Sqrt[(25 - 5*Sqrt[5])/5] + 32*Sqrt[25 - 5*Sqrt[5]] + 
      280*Sqrt[5 - Sqrt[5]] - 112*Sqrt[5*(5 - Sqrt[5])] + 
      316*Sqrt[5 + Sqrt[5]] - 140*Sqrt[5*(5 + Sqrt[5])] - 
      384*Sqrt[(25 - 5*Sqrt[5])/5]*x + 192*Sqrt[25 - 5*Sqrt[5]]*x - 
      80*Sqrt[5 - Sqrt[5]]*x + 32*Sqrt[5*(5 - Sqrt[5])]*x - 
      752*Sqrt[5 + Sqrt[5]]*x + 352*Sqrt[5*(5 + Sqrt[5])]*x - 
      160*Sqrt[25 - 5*Sqrt[5]]*x^2 + 64*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      40*Sqrt[5 - Sqrt[5]]*x^2 - 16*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      716*Sqrt[5 + Sqrt[5]]*x^2 - 332*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 16*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      120*Sqrt[5 + Sqrt[5]]*x^3 + 56*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      484*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 242*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      310*Sqrt[5 - Sqrt[5]]*x*y - 124*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      1224*Sqrt[5 + Sqrt[5]]*x*y - 564*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      696*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 348*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      220*Sqrt[5 - Sqrt[5]]*x^2*y + 88*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      1780*Sqrt[5 + Sqrt[5]]*x^2*y + 812*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 36*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      60*Sqrt[5 - Sqrt[5]]*x^3*y - 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      456*Sqrt[5 + Sqrt[5]]*x^3*y - 208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      424*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 212*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 230*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 92*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 1209*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 545*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 598*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 270*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 18*Sqrt[25 - 5*Sqrt[5]]*
       x^3*y^3 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 276*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 124*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -64*Sqrt[(25 - 5*Sqrt[5])/5] + 32*Sqrt[25 - 5*Sqrt[5]] + 
      240*Sqrt[5 - Sqrt[5]] - 96*Sqrt[5*(5 - Sqrt[5])] + 
      296*Sqrt[5 + Sqrt[5]] - 104*Sqrt[5*(5 + Sqrt[5])] - 
      544*Sqrt[(25 - 5*Sqrt[5])/5]*x + 272*Sqrt[25 - 5*Sqrt[5]]*x + 
      120*Sqrt[5 - Sqrt[5]]*x - 48*Sqrt[5*(5 - Sqrt[5])]*x - 
      652*Sqrt[5 + Sqrt[5]]*x + 348*Sqrt[5*(5 + Sqrt[5])]*x + 
      20*Sqrt[25 - 5*Sqrt[5]]*x^2 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      220*Sqrt[5 - Sqrt[5]]*x^2 - 88*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      276*Sqrt[5 + Sqrt[5]]*x^2 - 140*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 4*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      20*Sqrt[5 - Sqrt[5]]*x^3 + 8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      40*Sqrt[5 + Sqrt[5]]*x^3 + 16*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      404*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 202*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      110*Sqrt[5 - Sqrt[5]]*x*y - 44*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      784*Sqrt[5 + Sqrt[5]]*x*y - 372*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 18*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      370*Sqrt[5 - Sqrt[5]]*x^2*y + 148*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      650*Sqrt[5 + Sqrt[5]]*x^2*y + 310*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      146*Sqrt[5 + Sqrt[5]]*x^3*y - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      54*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 27*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      195*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 78*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      399*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 185*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 - 
      188*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 82*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      10*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     176*Sqrt[(25 - 5*Sqrt[5])/5] - 88*Sqrt[25 - 5*Sqrt[5]] - 
      600*Sqrt[5 - Sqrt[5]] + 240*Sqrt[5*(5 - Sqrt[5])] - 
      544*Sqrt[5 + Sqrt[5]] + 304*Sqrt[5*(5 + Sqrt[5])] - 
      664*Sqrt[(25 - 5*Sqrt[5])/5]*x + 332*Sqrt[25 - 5*Sqrt[5]]*x + 
      860*Sqrt[5 - Sqrt[5]]*x - 344*Sqrt[5*(5 - Sqrt[5])]*x + 
      168*Sqrt[5 + Sqrt[5]]*x - 112*Sqrt[5*(5 + Sqrt[5])]*x - 
      180*Sqrt[25 - 5*Sqrt[5]]*x^2 + 72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      460*Sqrt[5 - Sqrt[5]]*x^2 + 184*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      28*(5 + Sqrt[5])^(3/2)*x^2 + (56*(5 + Sqrt[5])^(3/2)*x^2)/Sqrt[5] - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      40*Sqrt[5 - Sqrt[5]]*x^3 - 16*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      20*Sqrt[5 + Sqrt[5]]*x^3 - 4*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      24*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 12*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      280*Sqrt[5 - Sqrt[5]]*x*y + 112*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      386*Sqrt[5 + Sqrt[5]]*x*y + 202*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      216*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 108*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      440*Sqrt[5 - Sqrt[5]]*x^2*y - 176*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      270*Sqrt[5 + Sqrt[5]]*x^2*y - 110*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      64*Sqrt[5 + Sqrt[5]]*x^3*y + 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 + 18*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      110*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 44*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 - 
      196*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 88*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      77*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 29*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      14*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 7*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      5*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 2*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -304*Sqrt[(25 - 5*Sqrt[5])/5] + 152*Sqrt[25 - 5*Sqrt[5]] + 
      640*Sqrt[5 - Sqrt[5]] - 256*Sqrt[5*(5 - Sqrt[5])] + 
      476*Sqrt[5 + Sqrt[5]] - 204*Sqrt[5*(5 + Sqrt[5])] + 
      456*Sqrt[(25 - 5*Sqrt[5])/5]*x - 228*Sqrt[25 - 5*Sqrt[5]]*x - 
      980*Sqrt[5 - Sqrt[5]]*x + 392*Sqrt[5*(5 - Sqrt[5])]*x - 
      712*Sqrt[5 + Sqrt[5]]*x + 304*Sqrt[5*(5 + Sqrt[5])]*x + 
      80*Sqrt[25 - 5*Sqrt[5]]*x^2 - 32*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      360*Sqrt[5 - Sqrt[5]]*x^2 - 144*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      276*Sqrt[5 + Sqrt[5]]*x^2 - 116*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 4*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      20*Sqrt[5 - Sqrt[5]]*x^3 + 8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      40*Sqrt[5 + Sqrt[5]]*x^3 + 16*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      236*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 118*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      810*Sqrt[5 - Sqrt[5]]*x*y - 324*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      794*Sqrt[5 + Sqrt[5]]*x*y - 350*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      136*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 68*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      300*Sqrt[5 - Sqrt[5]]*x^2*y + 120*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      720*Sqrt[5 + Sqrt[5]]*x^2*y + 312*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      146*Sqrt[5 + Sqrt[5]]*x^3*y - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      174*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 87*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 85*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 34*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 454*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 200*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 25*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 188*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 82*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 + 10*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -112*Sqrt[(25 - 5*Sqrt[5])/5] + 56*Sqrt[25 - 5*Sqrt[5]] - 
      40*Sqrt[5 - Sqrt[5]] + 16*Sqrt[5*(5 - Sqrt[5])] - 
      232*Sqrt[5 + Sqrt[5]] + 120*Sqrt[5*(5 + Sqrt[5])] + 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x - 4*Sqrt[25 - 5*Sqrt[5]]*x - 
      100*Sqrt[5 - Sqrt[5]]*x + 40*Sqrt[5*(5 - Sqrt[5])]*x - 
      136*Sqrt[5 + Sqrt[5]]*x + 48*Sqrt[5*(5 + Sqrt[5])]*x - 
      60*Sqrt[25 - 5*Sqrt[5]]*x^2 + 24*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      60*Sqrt[5 - Sqrt[5]]*x^2 - 24*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      308*Sqrt[5 + Sqrt[5]]*x^2 - 140*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      60*Sqrt[5 + Sqrt[5]]*x^3 + 28*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      52*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 26*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      90*Sqrt[5 - Sqrt[5]]*x*y + 36*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      68*Sqrt[5 + Sqrt[5]]*x*y + 32*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      508*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 254*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      190*Sqrt[5 - Sqrt[5]]*x^2*y - 76*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      600*Sqrt[5 + Sqrt[5]]*x^2*y + 276*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      228*Sqrt[5 + Sqrt[5]]*x^3*y - 104*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      272*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 136*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 120*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 48*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 282*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 130*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 299*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 135*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 18*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 9*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 + 25*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 138*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -192*Sqrt[(25 - 5*Sqrt[5])/5] + 96*Sqrt[25 - 5*Sqrt[5]] + 
      240*Sqrt[5 - Sqrt[5]] - 96*Sqrt[5*(5 - Sqrt[5])] + 
      16*(5 + Sqrt[5])^(3/2) - (32*(5 + Sqrt[5])^(3/2))/Sqrt[5] - 
      112*Sqrt[(25 - 5*Sqrt[5])/5]*x + 56*Sqrt[25 - 5*Sqrt[5]]*x + 
      160*Sqrt[5 - Sqrt[5]]*x - 64*Sqrt[5*(5 - Sqrt[5])]*x + 
      84*Sqrt[5 + Sqrt[5]]*x - 20*Sqrt[5*(5 + Sqrt[5])]*x - 
      80*Sqrt[25 - 5*Sqrt[5]]*x^2 + 32*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      248*Sqrt[5 + Sqrt[5]]*x^2 - 120*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      60*Sqrt[5 + Sqrt[5]]*x^3 + 28*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      192*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 96*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      120*Sqrt[5 - Sqrt[5]]*x*y + 48*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      112*Sqrt[5 + Sqrt[5]]*x*y - 64*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      328*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 164*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      60*Sqrt[5 - Sqrt[5]]*x^2*y + 24*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      600*Sqrt[5 + Sqrt[5]]*x^2*y + 280*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      228*Sqrt[5 + Sqrt[5]]*x^3*y - 104*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      192*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 96*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 80*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 32*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 412*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 188*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 299*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 135*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 18*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 9*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 + 25*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 138*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, 88*Sqrt[(25 - 5*Sqrt[5])/5] - 44*Sqrt[25 - 5*Sqrt[5]] - 
      300*Sqrt[5 - Sqrt[5]] + 120*Sqrt[5*(5 - Sqrt[5])] - 
      272*Sqrt[5 + Sqrt[5]] + 152*Sqrt[5*(5 + Sqrt[5])] - 
      432*Sqrt[(25 - 5*Sqrt[5])/5]*x + 216*Sqrt[25 - 5*Sqrt[5]]*x + 
      400*Sqrt[5 - Sqrt[5]]*x - 160*Sqrt[5*(5 - Sqrt[5])]*x - 
      116*Sqrt[5 + Sqrt[5]]*x + 52*Sqrt[5*(5 + Sqrt[5])]*x - 
      100*Sqrt[25 - 5*Sqrt[5]]*x^2 + 40*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      20*Sqrt[5 - Sqrt[5]]*x^2 + 8*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      288*Sqrt[5 + Sqrt[5]]*x^2 - 136*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      60*Sqrt[5 + Sqrt[5]]*x^3 + 28*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      92*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 46*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      30*Sqrt[5 - Sqrt[5]]*x*y + 12*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      92*Sqrt[5 + Sqrt[5]]*x*y - 40*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      288*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 144*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      120*Sqrt[5 - Sqrt[5]]*x^2*y + 48*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      640*Sqrt[5 + Sqrt[5]]*x^2*y + 296*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      228*Sqrt[5 + Sqrt[5]]*x^3*y - 104*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      132*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 66*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 120*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 48*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 387*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 175*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 299*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 135*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 18*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 9*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 + 25*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 138*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -32*Sqrt[(25 - 5*Sqrt[5])/5] + 16*Sqrt[25 - 5*Sqrt[5]] + 
      120*Sqrt[5 - Sqrt[5]] - 48*Sqrt[5*(5 - Sqrt[5])] + 
      148*Sqrt[5 + Sqrt[5]] - 52*Sqrt[5*(5 + Sqrt[5])] - 
      112*Sqrt[(25 - 5*Sqrt[5])/5]*x + 56*Sqrt[25 - 5*Sqrt[5]]*x - 
      160*Sqrt[5 - Sqrt[5]]*x + 64*Sqrt[5*(5 - Sqrt[5])]*x - 
      436*Sqrt[5 + Sqrt[5]]*x + 180*Sqrt[5*(5 + Sqrt[5])]*x - 
      80*Sqrt[25 - 5*Sqrt[5]]*x^2 + 32*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      40*Sqrt[5 - Sqrt[5]]*x^2 - 16*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      348*Sqrt[5 + Sqrt[5]]*x^2 - 156*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      60*Sqrt[5 + Sqrt[5]]*x^3 + 28*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 6*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      210*Sqrt[5 - Sqrt[5]]*x*y - 84*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      332*Sqrt[5 + Sqrt[5]]*x*y - 136*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      248*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 124*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      220*Sqrt[5 - Sqrt[5]]*x^2*y + 88*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      780*Sqrt[5 + Sqrt[5]]*x^2*y + 348*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      228*Sqrt[5 + Sqrt[5]]*x^3*y - 104*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      112*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 56*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 150*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 60*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 417*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 185*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 299*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 135*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 18*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 9*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 + 25*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 138*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -384*Sqrt[(25 - 5*Sqrt[5])/5] + 192*Sqrt[25 - 5*Sqrt[5]] + 
      480*Sqrt[5 - Sqrt[5]] - 192*Sqrt[5*(5 - Sqrt[5])] + 
      32*(5 + Sqrt[5])^(3/2) - (64*(5 + Sqrt[5])^(3/2))/Sqrt[5] + 
      336*Sqrt[(25 - 5*Sqrt[5])/5]*x - 168*Sqrt[25 - 5*Sqrt[5]]*x - 
      80*Sqrt[5 - Sqrt[5]]*x + 32*Sqrt[5*(5 - Sqrt[5])]*x + 
      428*Sqrt[5 + Sqrt[5]]*x - 236*Sqrt[5*(5 + Sqrt[5])]*x - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^2 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      20*Sqrt[5 - Sqrt[5]]*x^2 - 8*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      116*Sqrt[5 + Sqrt[5]]*x^2 - 28*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 4*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      20*Sqrt[5 - Sqrt[5]]*x^3 + 8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      40*Sqrt[5 + Sqrt[5]]*x^3 + 16*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      316*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 158*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      130*Sqrt[5 - Sqrt[5]]*x*y + 52*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      756*Sqrt[5 + Sqrt[5]]*x*y + 352*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      316*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 158*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      450*Sqrt[5 - Sqrt[5]]*x^2*y - 180*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      170*Sqrt[5 + Sqrt[5]]*x^2*y - 86*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      146*Sqrt[5 + Sqrt[5]]*x^3*y - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      134*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 67*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 345*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 138*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 331*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 145*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 25*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 188*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 82*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 + 10*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -224*Sqrt[(25 - 5*Sqrt[5])/5] + 112*Sqrt[25 - 5*Sqrt[5]] - 
      80*Sqrt[5 - Sqrt[5]] + 32*Sqrt[5*(5 - Sqrt[5])] - 
      464*Sqrt[5 + Sqrt[5]] + 240*Sqrt[5*(5 + Sqrt[5])] - 
      24*Sqrt[(25 - 5*Sqrt[5])/5]*x + 12*Sqrt[25 - 5*Sqrt[5]]*x + 
      60*Sqrt[5 - Sqrt[5]]*x - 24*Sqrt[5*(5 - Sqrt[5])]*x + 
      88*Sqrt[5 + Sqrt[5]]*x - 32*Sqrt[5*(5 + Sqrt[5])]*x - 
      60*Sqrt[25 - 5*Sqrt[5]]*x^2 + 24*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      180*Sqrt[5 - Sqrt[5]]*x^2 + 72*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      84*Sqrt[5 + Sqrt[5]]*x^2 + 12*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      40*Sqrt[5 - Sqrt[5]]*x^3 - 16*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      20*Sqrt[5 + Sqrt[5]]*x^3 - 4*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      104*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 52*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      280*Sqrt[5 - Sqrt[5]]*x*y + 112*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      326*Sqrt[5 + Sqrt[5]]*x*y + 126*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      496*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 248*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      700*Sqrt[5 - Sqrt[5]]*x^2*y - 280*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      210*Sqrt[5 + Sqrt[5]]*x^2*y - 58*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      64*Sqrt[5 + Sqrt[5]]*x^3*y + 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      244*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 122*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 390*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 156*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 146*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 54*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 77*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 29*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 14*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 7*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 + 5*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 2*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     760*Sqrt[25 - 5*Sqrt[5]] - 304*Sqrt[5*(25 - 5*Sqrt[5])] + 
      3200*Sqrt[5 - Sqrt[5]] - 1280*Sqrt[5*(5 - Sqrt[5])] + 
      2380*Sqrt[5 + Sqrt[5]] - 1020*Sqrt[5*(5 + Sqrt[5])] + 
      1260*Sqrt[25 - 5*Sqrt[5]]*x - 504*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      3900*Sqrt[5 - Sqrt[5]]*x - 1560*Sqrt[5*(5 - Sqrt[5])]*x + 
      2040*Sqrt[5 + Sqrt[5]]*x - 720*Sqrt[5*(5 + Sqrt[5])]*x - 
      400*Sqrt[25 - 5*Sqrt[5]]*x^2 + 160*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      600*Sqrt[5 - Sqrt[5]]*x^2 + 240*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      580*Sqrt[5 + Sqrt[5]]*x^2 - 260*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 - 
      100*Sqrt[5 - Sqrt[5]]*x^3 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      200*Sqrt[5 + Sqrt[5]]*x^3 + 80*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      1010*Sqrt[25 - 5*Sqrt[5]]*x*y + 404*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 
      2550*Sqrt[5 - Sqrt[5]]*x*y + 1020*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      730*Sqrt[5 + Sqrt[5]]*x*y + 230*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      540*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 216*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      500*Sqrt[5 - Sqrt[5]]*x^2*y - 200*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      1500*Sqrt[5 + Sqrt[5]]*x^2*y + 660*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 
      150*Sqrt[5 - Sqrt[5]]*x^3*y - 60*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      730*Sqrt[5 + Sqrt[5]]*x^3*y - 310*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      235*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 94*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 25*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 10*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 1070*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 480*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 75*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 30*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 125*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 50*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 940*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 410*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 430*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 190*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -40*Sqrt[25 - 5*Sqrt[5]] + 48*Sqrt[5 - Sqrt[5]] + 
      188*Sqrt[5 + Sqrt[5]] - 12*Sqrt[5*(5 + Sqrt[5])] + 
      80*Sqrt[25 - 5*Sqrt[5]]*x + 48*Sqrt[5 - Sqrt[5]]*x - 
      64*Sqrt[5 + Sqrt[5]]*x + 80*Sqrt[5*(5 + Sqrt[5])]*x - 
      8*Sqrt[25 - 5*Sqrt[5]]*x^2 - 12*Sqrt[5 + Sqrt[5]]*x^2 - 
      20*Sqrt[5*(5 + Sqrt[5])]*x^2 - 38*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      58*Sqrt[5 - Sqrt[5]]*x*y + 96*Sqrt[5 + Sqrt[5]]*x*y - 
      68*Sqrt[5*(5 + Sqrt[5])]*x*y + 8*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      8*Sqrt[5 - Sqrt[5]]*x^2*y + 32*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      2*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 7*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      11*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, -80*Sqrt[25 - 5*Sqrt[5]] + 
      32*Sqrt[5*(25 - 5*Sqrt[5])] - 240*Sqrt[5 - Sqrt[5]] + 
      96*Sqrt[5*(5 - Sqrt[5])] - 80*Sqrt[5 + Sqrt[5]] + 
      80*Sqrt[5*(5 + Sqrt[5])] + 180*Sqrt[25 - 5*Sqrt[5]]*x - 
      72*Sqrt[5*(25 - 5*Sqrt[5])]*x + 500*Sqrt[5 - Sqrt[5]]*x - 
      200*Sqrt[5*(5 - Sqrt[5])]*x - 40*Sqrt[5 + Sqrt[5]]*x - 
      16*Sqrt[5*(5 + Sqrt[5])]*x - 200*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      80*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 200*Sqrt[5 - Sqrt[5]]*x^2 + 
      80*Sqrt[5*(5 - Sqrt[5])]*x^2 + 360*Sqrt[5 + Sqrt[5]]*x^2 - 
      168*Sqrt[5*(5 + Sqrt[5])]*x^2 + 20*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 + 20*Sqrt[5 - Sqrt[5]]*x^3 - 
      8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 80*Sqrt[5 + Sqrt[5]]*x^3 + 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3 + 50*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      20*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 190*Sqrt[5 - Sqrt[5]]*x*y + 
      76*Sqrt[5*(5 - Sqrt[5])]*x*y - 200*Sqrt[5 + Sqrt[5]]*x*y + 
      116*Sqrt[5*(5 + Sqrt[5])]*x*y + 230*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      92*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 70*Sqrt[5 - Sqrt[5]]*x^2*y + 
      28*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 770*Sqrt[5 + Sqrt[5]]*x^2*y + 
      350*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 30*Sqrt[5 - Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 310*Sqrt[5 + Sqrt[5]]*x^3*y - 
      146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 75*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      30*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 + 155*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      62*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 355*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      157*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 75*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 
      30*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 - 410*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      188*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 + 40*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 
      16*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 190*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      86*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, -80*Sqrt[25 - 5*Sqrt[5]] + 
      32*Sqrt[5*(25 - 5*Sqrt[5])] - 240*Sqrt[5 - Sqrt[5]] + 
      96*Sqrt[5*(5 - Sqrt[5])] - 80*Sqrt[5 + Sqrt[5]] + 
      80*Sqrt[5*(5 + Sqrt[5])] + 40*Sqrt[25 - 5*Sqrt[5]]*x - 
      16*Sqrt[5*(25 - 5*Sqrt[5])]*x - 160*Sqrt[5 - Sqrt[5]]*x + 
      64*Sqrt[5*(5 - Sqrt[5])]*x - 580*Sqrt[5 + Sqrt[5]]*x + 
      212*Sqrt[5*(5 + Sqrt[5])]*x - 40*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 360*Sqrt[5 - Sqrt[5]]*x^2 - 
      144*Sqrt[5*(5 - Sqrt[5])]*x^2 + 720*Sqrt[5 + Sqrt[5]]*x^2 - 
      304*Sqrt[5*(5 + Sqrt[5])]*x^2 - 40*Sqrt[5 - Sqrt[5]]*x^3 + 
      16*Sqrt[5*(5 - Sqrt[5])]*x^3 - 140*Sqrt[5 + Sqrt[5]]*x^3 + 
      60*Sqrt[5*(5 + Sqrt[5])]*x^3 + 60*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      24*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 180*Sqrt[5 - Sqrt[5]]*x*y - 
      72*Sqrt[5*(5 - Sqrt[5])]*x*y + 40*(5 + Sqrt[5])^(3/2)*x*y - 
      16*Sqrt[5]*(5 + Sqrt[5])^(3/2)*x*y + 300*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      120*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 220*Sqrt[5 - Sqrt[5]]*x^2*y + 
      88*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 1520*Sqrt[5 + Sqrt[5]]*x^2*y + 
      664*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 90*Sqrt[5 - Sqrt[5]]*x^3*y - 
      36*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 520*Sqrt[5 + Sqrt[5]]*x^3*y - 
      228*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 180*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 + 20*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      8*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 770*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      342*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 50*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      20*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 
      40*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 - 675*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      299*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 + 45*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 
      18*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 310*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      138*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, -80*Sqrt[25 - 5*Sqrt[5]] + 
      32*Sqrt[5*(25 - 5*Sqrt[5])] - 240*Sqrt[5 - Sqrt[5]] + 
      96*Sqrt[5*(5 - Sqrt[5])] - 80*Sqrt[5 + Sqrt[5]] + 
      80*Sqrt[5*(5 + Sqrt[5])] + 80*Sqrt[25 - 5*Sqrt[5]]*x - 
      32*Sqrt[5*(25 - 5*Sqrt[5])]*x - 200*Sqrt[5 - Sqrt[5]]*x + 
      80*Sqrt[5*(5 - Sqrt[5])]*x - 740*Sqrt[5 + Sqrt[5]]*x + 
      324*Sqrt[5*(5 + Sqrt[5])]*x - 100*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      40*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 100*Sqrt[5 - Sqrt[5]]*x^2 - 
      40*Sqrt[5*(5 - Sqrt[5])]*x^2 + 460*Sqrt[5 + Sqrt[5]]*x^2 - 
      228*Sqrt[5*(5 + Sqrt[5])]*x^2 + 20*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 + 20*Sqrt[5 - Sqrt[5]]*x^3 - 
      8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 80*Sqrt[5 + Sqrt[5]]*x^3 + 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3 - 110*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      44*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 110*Sqrt[5 - Sqrt[5]]*x*y + 
      44*Sqrt[5*(5 - Sqrt[5])]*x*y + 400*Sqrt[5 + Sqrt[5]]*x*y - 
      188*Sqrt[5*(5 + Sqrt[5])]*x*y + 390*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      156*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 250*Sqrt[5 - Sqrt[5]]*x^2*y - 
      100*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 790*Sqrt[5 + Sqrt[5]]*x^2*y + 
      394*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 30*Sqrt[5 - Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 310*Sqrt[5 + Sqrt[5]]*x^3*y - 
      146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 205*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      82*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 - 175*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      70*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 285*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      143*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 75*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 
      30*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 - 410*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      188*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 + 40*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 
      16*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 190*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      86*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 100*Sqrt[25 - 5*Sqrt[5]] - 
      40*Sqrt[5*(25 - 5*Sqrt[5])] + 420*Sqrt[5 - Sqrt[5]] - 
      168*Sqrt[5*(5 - Sqrt[5])] + 280*Sqrt[5 + Sqrt[5]] - 
      128*Sqrt[5*(5 + Sqrt[5])] + 320*Sqrt[5 - Sqrt[5]]*x - 
      128*Sqrt[5*(5 - Sqrt[5])]*x + 440*Sqrt[5 + Sqrt[5]]*x - 
      176*Sqrt[5*(5 + Sqrt[5])]*x - 20*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 100*Sqrt[5 - Sqrt[5]]*x^2 + 
      40*Sqrt[5*(5 - Sqrt[5])]*x^2 - 80*Sqrt[5 + Sqrt[5]]*x^2 + 
      32*Sqrt[5*(5 + Sqrt[5])]*x^2 - 300*Sqrt[5 - Sqrt[5]]*x*y + 
      120*Sqrt[5*(5 - Sqrt[5])]*x*y - 410*Sqrt[5 + Sqrt[5]]*x*y + 
      170*Sqrt[5*(5 + Sqrt[5])]*x*y + 10*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 150*Sqrt[5 - Sqrt[5]]*x^2*y - 
      60*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 180*Sqrt[5 + Sqrt[5]]*x^2*y - 
      76*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 5*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      2*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 - 75*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      30*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 - 120*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      52*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, -40*Sqrt[25 - 5*Sqrt[5]] + 
      16*Sqrt[5*(25 - 5*Sqrt[5])] - 480*Sqrt[5 - Sqrt[5]] + 
      192*Sqrt[5*(5 - Sqrt[5])] - 500*Sqrt[5 + Sqrt[5]] + 
      324*Sqrt[5*(5 + Sqrt[5])] + 420*Sqrt[25 - 5*Sqrt[5]]*x - 
      168*Sqrt[5*(25 - 5*Sqrt[5])]*x + 1220*Sqrt[5 - Sqrt[5]]*x - 
      488*Sqrt[5*(5 - Sqrt[5])]*x + 320*Sqrt[5 + Sqrt[5]]*x - 
      168*Sqrt[5*(5 + Sqrt[5])]*x - 240*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      96*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 280*Sqrt[5 - Sqrt[5]]*x^2 + 
      112*Sqrt[5*(5 - Sqrt[5])]*x^2 + 260*Sqrt[5 + Sqrt[5]]*x^2 - 
      132*Sqrt[5*(5 + Sqrt[5])]*x^2 + 20*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 + 20*Sqrt[5 - Sqrt[5]]*x^3 - 
      8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 80*Sqrt[5 + Sqrt[5]]*x^3 + 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3 - 10*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 590*Sqrt[5 - Sqrt[5]]*x*y + 
      236*Sqrt[5*(5 - Sqrt[5])]*x*y - 690*Sqrt[5 + Sqrt[5]]*x*y + 
      350*Sqrt[5*(5 + Sqrt[5])]*x*y + 260*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      104*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 180*Sqrt[5 - Sqrt[5]]*x^2*y - 
      72*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 280*Sqrt[5 + Sqrt[5]]*x^2*y + 
      144*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 30*Sqrt[5 - Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 310*Sqrt[5 + Sqrt[5]]*x^3*y - 
      146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 45*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      18*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 + 35*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      14*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 - 20*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      6*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 75*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 
      30*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 - 410*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      188*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 + 40*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 
      16*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 190*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      86*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 40*Sqrt[5 - Sqrt[5]] - 
      8*Sqrt[5*(5 - Sqrt[5])] + 60*Sqrt[5 + Sqrt[5]] - 
      12*Sqrt[5*(5 + Sqrt[5])] - 40*Sqrt[5 - Sqrt[5]]*x + 
      8*Sqrt[5*(5 - Sqrt[5])]*x - 80*Sqrt[5 + Sqrt[5]]*x + 
      16*Sqrt[5*(5 + Sqrt[5])]*x + 20*Sqrt[5 + Sqrt[5]]*x^2 - 
      4*Sqrt[5*(5 + Sqrt[5])]*x^2 + 60*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      24*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 180*Sqrt[5 - Sqrt[5]]*x*y - 
      72*Sqrt[5*(5 - Sqrt[5])]*x*y + 80*Sqrt[5 + Sqrt[5]]*x*y - 
      24*Sqrt[5*(5 + Sqrt[5])]*x*y - 40*Sqrt[5 + Sqrt[5]]*x^2*y + 
      12*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 25*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      9*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 12*Sqrt[5 - Sqrt[5]] + 
      4*Sqrt[5*(5 - Sqrt[5])] + 18*Sqrt[5 + Sqrt[5]] + 
      6*Sqrt[5*(5 + Sqrt[5])] - 12*Sqrt[5 - Sqrt[5]]*x - 
      4*Sqrt[5*(5 - Sqrt[5])]*x - 24*Sqrt[5 + Sqrt[5]]*x - 
      8*Sqrt[5*(5 + Sqrt[5])]*x + 6*Sqrt[5 + Sqrt[5]]*x^2 + 
      2*Sqrt[5*(5 + Sqrt[5])]*x^2 + 10*Sqrt[5 + Sqrt[5]]*x*y + 
      4*Sqrt[5*(5 + Sqrt[5])]*x*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      18*Sqrt[5 - Sqrt[5]]*x^2*y - 2*Sqrt[5 + Sqrt[5]]*x^2*y - 
      2*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 3*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      12*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 3*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 320*Sqrt[25 - 5*Sqrt[5]] - 
      128*Sqrt[5*(25 - 5*Sqrt[5])] + 720*Sqrt[5 - Sqrt[5]] - 
      288*Sqrt[5*(5 - Sqrt[5])] + 40*Sqrt[5 + Sqrt[5]] + 
      24*Sqrt[5*(5 + Sqrt[5])] + 680*Sqrt[5 - Sqrt[5]]*x - 
      272*Sqrt[5*(5 - Sqrt[5])]*x + 980*Sqrt[5 + Sqrt[5]]*x - 
      420*Sqrt[5*(5 + Sqrt[5])]*x - 180*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 220*Sqrt[5 - Sqrt[5]]*x^2 + 
      88*Sqrt[5*(5 - Sqrt[5])]*x^2 + 140*Sqrt[5 + Sqrt[5]]*x^2 - 
      84*Sqrt[5*(5 + Sqrt[5])]*x^2 + 20*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 + 20*Sqrt[5 - Sqrt[5]]*x^3 - 
      8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 80*Sqrt[5 + Sqrt[5]]*x^3 + 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3 - 130*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      52*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 890*Sqrt[5 - Sqrt[5]]*x*y + 
      356*Sqrt[5*(5 - Sqrt[5])]*x*y - 840*Sqrt[5 + Sqrt[5]]*x*y + 
      356*Sqrt[5*(5 + Sqrt[5])]*x*y + 410*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      164*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 510*Sqrt[5 - Sqrt[5]]*x^2*y - 
      204*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 310*Sqrt[5 + Sqrt[5]]*x^2*y + 
      162*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 30*Sqrt[5 - Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 310*Sqrt[5 + Sqrt[5]]*x^3*y - 
      146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 205*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      82*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 - 195*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      78*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 205*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      99*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 75*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 
      30*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 - 410*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      188*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 + 40*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 
      16*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 190*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      86*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 24*Sqrt[25 - 5*Sqrt[5]] + 
      216*Sqrt[5 - Sqrt[5]] + 224*Sqrt[5 + Sqrt[5]] - 
      16*Sqrt[5*(5 + Sqrt[5])] + 108*Sqrt[25 - 5*Sqrt[5]]*x + 
      60*Sqrt[5 - Sqrt[5]]*x + 24*Sqrt[5 + Sqrt[5]]*x + 
      144*Sqrt[5*(5 + Sqrt[5])]*x - 20*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      52*Sqrt[5 - Sqrt[5]]*x^2 + 52*Sqrt[5 + Sqrt[5]]*x^2 - 
      60*Sqrt[5*(5 + Sqrt[5])]*x^2 - 8*Sqrt[5 - Sqrt[5]]*x^3 - 
      20*Sqrt[5 + Sqrt[5]]*x^3 + 4*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      100*Sqrt[25 - 5*Sqrt[5]]*x*y + 80*Sqrt[5 - Sqrt[5]]*x*y + 
      154*Sqrt[5 + Sqrt[5]]*x*y - 146*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      52*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 128*Sqrt[5 - Sqrt[5]]*x^2*y - 
      190*Sqrt[5 + Sqrt[5]]*x^2*y + 126*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 18*Sqrt[5 - Sqrt[5]]*x^3*y + 
      64*Sqrt[5 + Sqrt[5]]*x^3*y - 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      38*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 90*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      148*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 80*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 20*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      77*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 29*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      5*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 9*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     60*Sqrt[25 - 5*Sqrt[5]] - 24*Sqrt[5*(25 - 5*Sqrt[5])] + 
      700*Sqrt[5 - Sqrt[5]] - 280*Sqrt[5*(5 - Sqrt[5])] + 
      880*Sqrt[5 + Sqrt[5]] - 360*Sqrt[5*(5 + Sqrt[5])] + 
      660*Sqrt[25 - 5*Sqrt[5]]*x - 264*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      1700*Sqrt[5 - Sqrt[5]]*x - 680*Sqrt[5*(5 - Sqrt[5])]*x + 
      240*Sqrt[5 + Sqrt[5]]*x - 200*Sqrt[5*(5 + Sqrt[5])]*x - 
      300*Sqrt[25 - 5*Sqrt[5]]*x^2 + 120*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      300*Sqrt[5 - Sqrt[5]]*x^2 + 120*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      1080*Sqrt[5 + Sqrt[5]]*x^2 - 400*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 - 
      100*Sqrt[5 - Sqrt[5]]*x^3 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      200*Sqrt[5 + Sqrt[5]]*x^3 + 80*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      660*Sqrt[25 - 5*Sqrt[5]]*x*y + 264*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 
      1100*Sqrt[5 - Sqrt[5]]*x*y + 440*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      240*(5 + Sqrt[5])^(3/2)*x*y - 96*Sqrt[5]*(5 + Sqrt[5])^(3/2)*x*y + 
      490*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 196*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      150*Sqrt[5 - Sqrt[5]]*x^2*y - 60*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      2650*Sqrt[5 + Sqrt[5]]*x^2*y + 1070*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 
      150*Sqrt[5 - Sqrt[5]]*x^3*y - 60*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      730*Sqrt[5 + Sqrt[5]]*x^3*y - 310*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      235*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 94*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 225*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 90*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 1770*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 760*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 75*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 30*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 125*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 50*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 940*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 410*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 430*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 190*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, 96*Sqrt[(25 - 5*Sqrt[5])/5] - 48*Sqrt[25 - 5*Sqrt[5]] - 
      280*Sqrt[5 - Sqrt[5]] + 112*Sqrt[5*(5 - Sqrt[5])] - 
      244*Sqrt[5 + Sqrt[5]] + 132*Sqrt[5*(5 + Sqrt[5])] - 
      224*Sqrt[(25 - 5*Sqrt[5])/5]*x + 112*Sqrt[25 - 5*Sqrt[5]]*x + 
      320*Sqrt[5 - Sqrt[5]]*x - 128*Sqrt[5*(5 - Sqrt[5])]*x + 
      48*Sqrt[5 + Sqrt[5]]*x - 32*Sqrt[5*(5 + Sqrt[5])]*x - 
      160*Sqrt[25 - 5*Sqrt[5]]*x^2 + 64*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      40*Sqrt[5 - Sqrt[5]]*x^2 - 16*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      476*Sqrt[5 + Sqrt[5]]*x^2 - 220*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 16*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      120*Sqrt[5 + Sqrt[5]]*x^3 + 56*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      104*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 52*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      20*Sqrt[5 - Sqrt[5]]*x*y + 8*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      184*Sqrt[5 + Sqrt[5]]*x*y - 80*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      516*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 258*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      310*Sqrt[5 - Sqrt[5]]*x^2*y + 124*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      1080*Sqrt[5 + Sqrt[5]]*x^2*y + 492*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 36*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      60*Sqrt[5 - Sqrt[5]]*x^3*y - 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      456*Sqrt[5 + Sqrt[5]]*x^3*y - 208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      284*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 142*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 260*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 104*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 719*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 323*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 598*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 270*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 18*Sqrt[25 - 5*Sqrt[5]]*
       x^3*y^3 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 276*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 124*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, 376*Sqrt[(25 - 5*Sqrt[5])/5] - 188*Sqrt[25 - 5*Sqrt[5]] - 
      380*Sqrt[5 - Sqrt[5]] + 152*Sqrt[5*(5 - Sqrt[5])] + 
      96*Sqrt[5 + Sqrt[5]] - 8*Sqrt[5*(5 + Sqrt[5])] - 
      904*Sqrt[(25 - 5*Sqrt[5])/5]*x + 452*Sqrt[25 - 5*Sqrt[5]]*x + 
      220*Sqrt[5 - Sqrt[5]]*x - 88*Sqrt[5*(5 - Sqrt[5])]*x - 
      1212*Sqrt[5 + Sqrt[5]]*x + 532*Sqrt[5*(5 + Sqrt[5])]*x - 
      200*Sqrt[25 - 5*Sqrt[5]]*x^2 + 80*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      796*Sqrt[5 + Sqrt[5]]*x^2 - 364*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 16*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      120*Sqrt[5 + Sqrt[5]]*x^3 + 56*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      684*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 342*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      10*Sqrt[5 - Sqrt[5]]*x*y - 4*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      1144*Sqrt[5 + Sqrt[5]]*x*y - 508*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      616*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 308*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      380*Sqrt[5 - Sqrt[5]]*x^2*y + 152*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      1880*Sqrt[5 + Sqrt[5]]*x^2*y + 848*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 36*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      60*Sqrt[5 - Sqrt[5]]*x^3*y - 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      456*Sqrt[5 + Sqrt[5]]*x^3*y - 208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      304*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 152*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 310*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 124*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 1109*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 497*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 598*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 270*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 18*Sqrt[25 - 5*Sqrt[5]]*
       x^3*y^3 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 276*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 124*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -304*Sqrt[(25 - 5*Sqrt[5])/5] + 152*Sqrt[25 - 5*Sqrt[5]] + 
      680*Sqrt[5 - Sqrt[5]] - 272*Sqrt[5*(5 - Sqrt[5])] + 
      496*Sqrt[5 + Sqrt[5]] - 240*Sqrt[5*(5 + Sqrt[5])] + 
      56*Sqrt[(25 - 5*Sqrt[5])/5]*x - 28*Sqrt[25 - 5*Sqrt[5]]*x + 
      420*Sqrt[5 - Sqrt[5]]*x - 168*Sqrt[5*(5 - Sqrt[5])]*x + 
      728*Sqrt[5 + Sqrt[5]]*x - 304*Sqrt[5*(5 + Sqrt[5])]*x - 
      40*Sqrt[25 - 5*Sqrt[5]]*x^2 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      40*Sqrt[5 - Sqrt[5]]*x^2 + 16*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      16*Sqrt[5 + Sqrt[5]]*x^2 + 8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 
      4*Sqrt[25 - 5*Sqrt[5]]*x^3 - 20*Sqrt[5 - Sqrt[5]]*x^3 + 
      8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 40*Sqrt[5 + Sqrt[5]]*x^3 + 
      16*Sqrt[5*(5 + Sqrt[5])]*x^3 - 136*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 
      68*Sqrt[25 - 5*Sqrt[5]]*x*y - 460*Sqrt[5 - Sqrt[5]]*x*y + 
      184*Sqrt[5*(5 - Sqrt[5])]*x*y - 896*Sqrt[5 + Sqrt[5]]*x*y + 
      384*Sqrt[5*(5 + Sqrt[5])]*x*y - 336*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 
      168*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 540*Sqrt[5 - Sqrt[5]]*x^2*y - 
      216*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 430*Sqrt[5 + Sqrt[5]]*x^2*y - 
      182*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 
      6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 30*Sqrt[5 - Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 146*Sqrt[5 + Sqrt[5]]*x^3*y - 
      62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 114*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 
      57*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 375*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      150*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 - 501*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      215*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 25*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 
      10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 - 188*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      82*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*
       y^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 10*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 
      4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 86*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 16*Sqrt[(25 - 5*Sqrt[5])/5] - 
      8*Sqrt[25 - 5*Sqrt[5]] - 440*Sqrt[5 - Sqrt[5]] + 
      176*Sqrt[5*(5 - Sqrt[5])] - 624*Sqrt[5 + Sqrt[5]] + 
      304*Sqrt[5*(5 + Sqrt[5])] - 104*Sqrt[(25 - 5*Sqrt[5])/5]*x + 
      52*Sqrt[25 - 5*Sqrt[5]]*x + 180*Sqrt[5 - Sqrt[5]]*x - 
      72*Sqrt[5*(5 - Sqrt[5])]*x + 88*Sqrt[5 + Sqrt[5]]*x - 
      32*Sqrt[5*(5 + Sqrt[5])]*x - 60*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      24*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 180*Sqrt[5 - Sqrt[5]]*x^2 + 
      72*Sqrt[5*(5 - Sqrt[5])]*x^2 - 84*Sqrt[5 + Sqrt[5]]*x^2 + 
      12*Sqrt[5*(5 + Sqrt[5])]*x^2 - 32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 
      16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 40*Sqrt[5 - Sqrt[5]]*x^3 - 
      16*Sqrt[5*(5 - Sqrt[5])]*x^3 + 20*Sqrt[5 + Sqrt[5]]*x^3 - 
      4*Sqrt[5*(5 + Sqrt[5])]*x^3 - 156*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 
      78*Sqrt[25 - 5*Sqrt[5]]*x*y - 30*Sqrt[5 - Sqrt[5]]*x*y + 
      12*Sqrt[5*(5 - Sqrt[5])]*x*y - 366*Sqrt[5 + Sqrt[5]]*x*y + 
      146*Sqrt[5*(5 + Sqrt[5])]*x*y - 476*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 
      238*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 690*Sqrt[5 - Sqrt[5]]*x^2*y - 
      276*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 230*Sqrt[5 + Sqrt[5]]*x^2*y - 
      66*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 
      6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 30*Sqrt[5 - Sqrt[5]]*x^3*y + 
      12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 64*Sqrt[5 + Sqrt[5]]*x^3*y + 
      20*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 224*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 
      112*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 380*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      152*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 - 156*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      60*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 77*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      29*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 14*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*
       y^3 + 7*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 5*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 
      2*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 34*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, -184*Sqrt[(25 - 5*Sqrt[5])/5] + 
      92*Sqrt[25 - 5*Sqrt[5]] - 180*Sqrt[5 - Sqrt[5]] + 
      72*Sqrt[5*(5 - Sqrt[5])] - 584*Sqrt[5 + Sqrt[5]] + 
      272*Sqrt[5*(5 + Sqrt[5])] + 136*Sqrt[(25 - 5*Sqrt[5])/5]*x - 
      68*Sqrt[25 - 5*Sqrt[5]]*x + 260*Sqrt[5 - Sqrt[5]]*x - 
      104*Sqrt[5*(5 - Sqrt[5])]*x + 588*Sqrt[5 + Sqrt[5]]*x - 
      260*Sqrt[5*(5 + Sqrt[5])]*x - 120*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      48*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 80*Sqrt[5 - Sqrt[5]]*x^2 - 
      32*Sqrt[5*(5 - Sqrt[5])]*x^2 + 396*Sqrt[5 + Sqrt[5]]*x^2 - 
      188*Sqrt[5*(5 + Sqrt[5])]*x^2 - 32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 
      16*Sqrt[25 - 5*Sqrt[5]]*x^3 - 120*Sqrt[5 + Sqrt[5]]*x^3 + 
      56*Sqrt[5*(5 + Sqrt[5])]*x^3 - 196*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 
      98*Sqrt[25 - 5*Sqrt[5]]*x*y - 190*Sqrt[5 - Sqrt[5]]*x*y + 
      76*Sqrt[5*(5 - Sqrt[5])]*x*y - 576*Sqrt[5 + Sqrt[5]]*x*y + 
      252*Sqrt[5*(5 + Sqrt[5])]*x*y - 536*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 
      268*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 180*Sqrt[5 - Sqrt[5]]*x^2*y + 
      72*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 880*Sqrt[5 + Sqrt[5]]*x^2*y + 
      408*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 
      36*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 60*Sqrt[5 - Sqrt[5]]*x^3*y - 
      24*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 456*Sqrt[5 + Sqrt[5]]*x^3*y - 
      208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 304*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*
       y^2 - 152*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 150*Sqrt[5 - Sqrt[5]]*x^2*
       y^2 - 60*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 549*Sqrt[5 + Sqrt[5]]*x^2*
       y^2 - 249*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 40*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^2 - 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 100*Sqrt[5 - Sqrt[5]]*x^3*
       y^2 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 - 598*Sqrt[5 + Sqrt[5]]*x^3*
       y^2 + 270*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 36*Sqrt[(25 - 5*Sqrt[5])/5]*
       x^3*y^3 - 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 50*Sqrt[5 - Sqrt[5]]*x^3*
       y^3 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 276*Sqrt[5 + Sqrt[5]]*x^3*
       y^3 - 124*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -64*Sqrt[(25 - 5*Sqrt[5])/5] + 32*Sqrt[25 - 5*Sqrt[5]] + 
      720*Sqrt[5 - Sqrt[5]] - 288*Sqrt[5*(5 - Sqrt[5])] + 
      976*Sqrt[5 + Sqrt[5]] - 448*Sqrt[5*(5 + Sqrt[5])] - 
      24*Sqrt[(25 - 5*Sqrt[5])/5]*x + 12*Sqrt[25 - 5*Sqrt[5]]*x - 
      740*Sqrt[5 - Sqrt[5]]*x + 296*Sqrt[5*(5 - Sqrt[5])]*x - 
      1152*Sqrt[5 + Sqrt[5]]*x + 536*Sqrt[5*(5 + Sqrt[5])]*x + 
      40*Sqrt[25 - 5*Sqrt[5]]*x^2 - 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      280*Sqrt[5 - Sqrt[5]]*x^2 - 112*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      376*Sqrt[5 + Sqrt[5]]*x^2 - 168*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 4*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      20*Sqrt[5 - Sqrt[5]]*x^3 + 8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      40*Sqrt[5 + Sqrt[5]]*x^3 + 16*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      304*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 152*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      640*Sqrt[5 - Sqrt[5]]*x*y - 256*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      1444*Sqrt[5 + Sqrt[5]]*x*y - 652*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 8*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      460*Sqrt[5 - Sqrt[5]]*x^2*y + 184*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      910*Sqrt[5 + Sqrt[5]]*x^2*y + 406*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      146*Sqrt[5 + Sqrt[5]]*x^3*y - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      74*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 37*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      225*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 90*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      569*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 255*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 - 
      188*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 82*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      10*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     416*Sqrt[(25 - 5*Sqrt[5])/5] - 208*Sqrt[25 - 5*Sqrt[5]] - 
      960*Sqrt[5 - Sqrt[5]] + 384*Sqrt[5*(5 - Sqrt[5])] - 
      704*Sqrt[5 + Sqrt[5]] + 368*Sqrt[5*(5 + Sqrt[5])] - 
      744*Sqrt[(25 - 5*Sqrt[5])/5]*x + 372*Sqrt[25 - 5*Sqrt[5]]*x + 
      980*Sqrt[5 - Sqrt[5]]*x - 392*Sqrt[5*(5 - Sqrt[5])]*x + 
      168*Sqrt[5 + Sqrt[5]]*x - 112*Sqrt[5*(5 + Sqrt[5])]*x - 
      180*Sqrt[25 - 5*Sqrt[5]]*x^2 + 72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      460*Sqrt[5 - Sqrt[5]]*x^2 + 184*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      28*(5 + Sqrt[5])^(3/2)*x^2 + (56*(5 + Sqrt[5])^(3/2)*x^2)/Sqrt[5] - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      40*Sqrt[5 - Sqrt[5]]*x^3 - 16*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      20*Sqrt[5 + Sqrt[5]]*x^3 - 4*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      364*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 182*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      730*Sqrt[5 - Sqrt[5]]*x*y + 292*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      426*Sqrt[5 + Sqrt[5]]*x*y + 214*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      236*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 118*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      450*Sqrt[5 - Sqrt[5]]*x^2*y - 180*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      250*Sqrt[5 + Sqrt[5]]*x^2*y - 102*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      64*Sqrt[5 + Sqrt[5]]*x^3*y + 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 + 8*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      120*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 48*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 - 
      186*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 82*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      77*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 29*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      14*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 7*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      5*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 2*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -140*Sqrt[25 - 5*Sqrt[5]] + 56*Sqrt[5*(25 - 5*Sqrt[5])] - 
      700*Sqrt[5 - Sqrt[5]] + 280*Sqrt[5*(5 - Sqrt[5])] - 
      520*Sqrt[5 + Sqrt[5]] + 320*Sqrt[5*(5 + Sqrt[5])] + 
      260*Sqrt[25 - 5*Sqrt[5]]*x - 104*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      300*Sqrt[5 - Sqrt[5]]*x + 120*Sqrt[5*(5 - Sqrt[5])]*x - 
      1360*Sqrt[5 + Sqrt[5]]*x + 760*Sqrt[5*(5 + Sqrt[5])]*x + 
      300*Sqrt[25 - 5*Sqrt[5]]*x^2 - 120*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      1500*Sqrt[5 - Sqrt[5]]*x^2 - 600*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      880*Sqrt[5 + Sqrt[5]]*x^2 - 440*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 - 
      100*Sqrt[5 - Sqrt[5]]*x^3 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      200*Sqrt[5 + Sqrt[5]]*x^3 + 80*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      40*Sqrt[25 - 5*Sqrt[5]]*x*y - 16*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 
      800*Sqrt[5 - Sqrt[5]]*x*y - 320*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      920*Sqrt[5 + Sqrt[5]]*x*y - 560*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      390*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 156*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      1150*Sqrt[5 - Sqrt[5]]*x^2*y + 460*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      2450*Sqrt[5 + Sqrt[5]]*x^2*y + 1150*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 
      150*Sqrt[5 - Sqrt[5]]*x^3*y - 60*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      730*Sqrt[5 + Sqrt[5]]*x^3*y - 310*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      435*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 174*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 225*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 90*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 1570*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 720*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 75*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 30*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 125*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 50*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 940*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 410*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 430*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 190*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -64*Sqrt[(25 - 5*Sqrt[5])/5] + 32*Sqrt[25 - 5*Sqrt[5]] + 
      280*Sqrt[5 - Sqrt[5]] - 112*Sqrt[5*(5 - Sqrt[5])] + 
      316*Sqrt[5 + Sqrt[5]] - 140*Sqrt[5*(5 + Sqrt[5])] - 
      384*Sqrt[(25 - 5*Sqrt[5])/5]*x + 192*Sqrt[25 - 5*Sqrt[5]]*x - 
      80*Sqrt[5 - Sqrt[5]]*x + 32*Sqrt[5*(5 - Sqrt[5])]*x - 
      752*Sqrt[5 + Sqrt[5]]*x + 352*Sqrt[5*(5 + Sqrt[5])]*x - 
      160*Sqrt[25 - 5*Sqrt[5]]*x^2 + 64*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      40*Sqrt[5 - Sqrt[5]]*x^2 - 16*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      716*Sqrt[5 + Sqrt[5]]*x^2 - 332*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 16*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      120*Sqrt[5 + Sqrt[5]]*x^3 + 56*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      264*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 132*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      20*Sqrt[5 - Sqrt[5]]*x*y + 8*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      384*Sqrt[5 + Sqrt[5]]*x*y - 184*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      1076*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 538*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      450*Sqrt[5 - Sqrt[5]]*x^2*y - 180*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      1400*Sqrt[5 + Sqrt[5]]*x^2*y + 652*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 36*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      60*Sqrt[5 - Sqrt[5]]*x^3*y - 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      456*Sqrt[5 + Sqrt[5]]*x^3*y - 208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      524*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 262*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 260*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 104*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 619*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 287*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 598*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 270*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 18*Sqrt[25 - 5*Sqrt[5]]*
       x^3*y^3 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 276*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 124*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -112*Sqrt[(25 - 5*Sqrt[5])/5] + 56*Sqrt[25 - 5*Sqrt[5]] - 
      40*Sqrt[5 - Sqrt[5]] + 16*Sqrt[5*(5 - Sqrt[5])] - 
      232*Sqrt[5 + Sqrt[5]] + 120*Sqrt[5*(5 + Sqrt[5])] + 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x - 4*Sqrt[25 - 5*Sqrt[5]]*x - 
      100*Sqrt[5 - Sqrt[5]]*x + 40*Sqrt[5*(5 - Sqrt[5])]*x - 
      136*Sqrt[5 + Sqrt[5]]*x + 48*Sqrt[5*(5 + Sqrt[5])]*x - 
      60*Sqrt[25 - 5*Sqrt[5]]*x^2 + 24*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      60*Sqrt[5 - Sqrt[5]]*x^2 - 24*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      308*Sqrt[5 + Sqrt[5]]*x^2 - 140*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      60*Sqrt[5 + Sqrt[5]]*x^3 + 28*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      88*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 44*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      220*Sqrt[5 - Sqrt[5]]*x*y - 88*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      162*Sqrt[5 + Sqrt[5]]*x*y - 66*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      288*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 144*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      140*Sqrt[5 - Sqrt[5]]*x^2*y + 56*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      730*Sqrt[5 + Sqrt[5]]*x^2*y + 330*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      228*Sqrt[5 + Sqrt[5]]*x^3*y - 104*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      172*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 86*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 110*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 44*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 467*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 209*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 299*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 135*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 18*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 9*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 + 25*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 138*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -304*Sqrt[(25 - 5*Sqrt[5])/5] + 152*Sqrt[25 - 5*Sqrt[5]] + 
      640*Sqrt[5 - Sqrt[5]] - 256*Sqrt[5*(5 - Sqrt[5])] + 
      476*Sqrt[5 + Sqrt[5]] - 204*Sqrt[5*(5 + Sqrt[5])] + 
      456*Sqrt[(25 - 5*Sqrt[5])/5]*x - 228*Sqrt[25 - 5*Sqrt[5]]*x - 
      980*Sqrt[5 - Sqrt[5]]*x + 392*Sqrt[5*(5 - Sqrt[5])]*x - 
      712*Sqrt[5 + Sqrt[5]]*x + 304*Sqrt[5*(5 + Sqrt[5])]*x + 
      80*Sqrt[25 - 5*Sqrt[5]]*x^2 - 32*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      360*Sqrt[5 - Sqrt[5]]*x^2 - 144*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      276*Sqrt[5 + Sqrt[5]]*x^2 - 116*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 4*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      20*Sqrt[5 - Sqrt[5]]*x^3 + 8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      40*Sqrt[5 + Sqrt[5]]*x^3 + 16*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 18*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      650*Sqrt[5 - Sqrt[5]]*x*y - 260*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      924*Sqrt[5 + Sqrt[5]]*x*y - 400*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      104*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y - 52*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      560*Sqrt[5 - Sqrt[5]]*x^2*y + 224*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      650*Sqrt[5 + Sqrt[5]]*x^2*y + 282*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      146*Sqrt[5 + Sqrt[5]]*x^3*y - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      34*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 17*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      255*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 102*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      414*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 184*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 - 
      188*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 82*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      10*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     176*Sqrt[(25 - 5*Sqrt[5])/5] - 88*Sqrt[25 - 5*Sqrt[5]] - 
      600*Sqrt[5 - Sqrt[5]] + 240*Sqrt[5*(5 - Sqrt[5])] - 
      544*Sqrt[5 + Sqrt[5]] + 304*Sqrt[5*(5 + Sqrt[5])] - 
      664*Sqrt[(25 - 5*Sqrt[5])/5]*x + 332*Sqrt[25 - 5*Sqrt[5]]*x + 
      860*Sqrt[5 - Sqrt[5]]*x - 344*Sqrt[5*(5 - Sqrt[5])]*x + 
      168*Sqrt[5 + Sqrt[5]]*x - 112*Sqrt[5*(5 + Sqrt[5])]*x - 
      180*Sqrt[25 - 5*Sqrt[5]]*x^2 + 72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      460*Sqrt[5 - Sqrt[5]]*x^2 + 184*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      84*Sqrt[5 + Sqrt[5]]*x^2 + 28*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      40*Sqrt[5 - Sqrt[5]]*x^3 - 16*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      20*Sqrt[5 + Sqrt[5]]*x^3 - 4*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      364*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 182*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      670*Sqrt[5 - Sqrt[5]]*x*y + 268*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      436*Sqrt[5 + Sqrt[5]]*x*y + 208*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      236*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 118*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      430*Sqrt[5 - Sqrt[5]]*x^2*y - 172*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      220*Sqrt[5 + Sqrt[5]]*x^2*y - 88*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      64*Sqrt[5 + Sqrt[5]]*x^3*y + 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      4*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 2*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      130*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 52*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 - 
      156*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 68*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      77*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 29*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      14*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 7*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      5*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 2*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     160*Sqrt[25 - 5*Sqrt[5]] - 64*Sqrt[5*(25 - 5*Sqrt[5])] + 
      1200*Sqrt[5 - Sqrt[5]] - 480*Sqrt[5*(5 - Sqrt[5])] + 
      1480*Sqrt[5 + Sqrt[5]] - 520*Sqrt[5*(5 + Sqrt[5])] + 
      1360*Sqrt[25 - 5*Sqrt[5]]*x - 544*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      600*Sqrt[5 - Sqrt[5]]*x - 240*Sqrt[5*(5 - Sqrt[5])]*x - 
      3260*Sqrt[5 + Sqrt[5]]*x + 1740*Sqrt[5*(5 + Sqrt[5])]*x + 
      100*Sqrt[25 - 5*Sqrt[5]]*x^2 - 40*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      1100*Sqrt[5 - Sqrt[5]]*x^2 - 440*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      1380*Sqrt[5 + Sqrt[5]]*x^2 - 700*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 - 
      100*Sqrt[5 - Sqrt[5]]*x^3 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      200*Sqrt[5 + Sqrt[5]]*x^3 + 80*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      960*Sqrt[25 - 5*Sqrt[5]]*x*y + 384*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 
      600*Sqrt[5 - Sqrt[5]]*x*y - 240*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      3720*Sqrt[5 + Sqrt[5]]*x*y - 1880*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      540*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 216*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      1000*Sqrt[5 - Sqrt[5]]*x^2*y + 400*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      3750*Sqrt[5 + Sqrt[5]]*x^2*y + 1790*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 
      150*Sqrt[5 - Sqrt[5]]*x^3*y - 60*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      730*Sqrt[5 + Sqrt[5]]*x^3*y - 310*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      485*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 194*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 325*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 130*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 2445*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 1135*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 75*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 30*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 125*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 50*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 940*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 410*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 430*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 190*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -192*Sqrt[(25 - 5*Sqrt[5])/5] + 96*Sqrt[25 - 5*Sqrt[5]] + 
      240*Sqrt[5 - Sqrt[5]] - 96*Sqrt[5*(5 - Sqrt[5])] + 
      16*(5 + Sqrt[5])^(3/2) - (32*(5 + Sqrt[5])^(3/2))/Sqrt[5] - 
      112*Sqrt[(25 - 5*Sqrt[5])/5]*x + 56*Sqrt[25 - 5*Sqrt[5]]*x + 
      160*Sqrt[5 - Sqrt[5]]*x - 64*Sqrt[5*(5 - Sqrt[5])]*x + 
      84*Sqrt[5 + Sqrt[5]]*x - 20*Sqrt[5*(5 + Sqrt[5])]*x - 
      80*Sqrt[25 - 5*Sqrt[5]]*x^2 + 32*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      248*Sqrt[5 + Sqrt[5]]*x^2 - 120*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      60*Sqrt[5 + Sqrt[5]]*x^3 + 28*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      68*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 34*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      110*Sqrt[5 - Sqrt[5]]*x*y + 44*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      308*Sqrt[5 + Sqrt[5]]*x*y + 128*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      508*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 254*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      270*Sqrt[5 - Sqrt[5]]*x^2*y - 108*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      400*Sqrt[5 + Sqrt[5]]*x^2*y + 196*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      228*Sqrt[5 + Sqrt[5]]*x^3*y - 104*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      232*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 116*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 160*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 64*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 112*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 56*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 299*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 135*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 18*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 9*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 + 25*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 138*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -224*Sqrt[(25 - 5*Sqrt[5])/5] + 112*Sqrt[25 - 5*Sqrt[5]] - 
      80*Sqrt[5 - Sqrt[5]] + 32*Sqrt[5*(5 - Sqrt[5])] - 
      464*Sqrt[5 + Sqrt[5]] + 240*Sqrt[5*(5 + Sqrt[5])] - 
      24*Sqrt[(25 - 5*Sqrt[5])/5]*x + 12*Sqrt[25 - 5*Sqrt[5]]*x + 
      60*Sqrt[5 - Sqrt[5]]*x - 24*Sqrt[5*(5 - Sqrt[5])]*x + 
      88*Sqrt[5 + Sqrt[5]]*x - 32*Sqrt[5*(5 + Sqrt[5])]*x - 
      60*Sqrt[25 - 5*Sqrt[5]]*x^2 + 24*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      180*Sqrt[5 - Sqrt[5]]*x^2 + 72*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      84*Sqrt[5 + Sqrt[5]]*x^2 + 12*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      40*Sqrt[5 - Sqrt[5]]*x^3 - 16*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      20*Sqrt[5 + Sqrt[5]]*x^3 - 4*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      236*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 118*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      110*Sqrt[5 - Sqrt[5]]*x*y - 44*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      276*Sqrt[5 + Sqrt[5]]*x*y + 120*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      476*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 238*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      710*Sqrt[5 - Sqrt[5]]*x^2*y - 284*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      260*Sqrt[5 + Sqrt[5]]*x^2*y - 80*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      64*Sqrt[5 + Sqrt[5]]*x^3*y + 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      204*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 102*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 370*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 148*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 186*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 74*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 77*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 29*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 14*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 7*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 + 5*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 2*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -384*Sqrt[(25 - 5*Sqrt[5])/5] + 192*Sqrt[25 - 5*Sqrt[5]] + 
      480*Sqrt[5 - Sqrt[5]] - 192*Sqrt[5*(5 - Sqrt[5])] + 
      32*(5 + Sqrt[5])^(3/2) - (64*(5 + Sqrt[5])^(3/2))/Sqrt[5] + 
      336*Sqrt[(25 - 5*Sqrt[5])/5]*x - 168*Sqrt[25 - 5*Sqrt[5]]*x - 
      80*Sqrt[5 - Sqrt[5]]*x + 32*Sqrt[5*(5 - Sqrt[5])]*x + 
      428*Sqrt[5 + Sqrt[5]]*x - 236*Sqrt[5*(5 + Sqrt[5])]*x - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^2 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      20*Sqrt[5 - Sqrt[5]]*x^2 - 8*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      116*Sqrt[5 + Sqrt[5]]*x^2 - 28*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 4*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      20*Sqrt[5 - Sqrt[5]]*x^3 + 8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      40*Sqrt[5 + Sqrt[5]]*x^3 + 16*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      216*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 108*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      20*Sqrt[5 - Sqrt[5]]*x*y - 8*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      336*Sqrt[5 + Sqrt[5]]*x*y + 184*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      136*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 68*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      270*Sqrt[5 + Sqrt[5]]*x^2*y + 86*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      146*Sqrt[5 + Sqrt[5]]*x^3*y - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      74*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 37*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      25*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 10*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      179*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 69*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 - 
      188*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 82*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      10*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     16*Sqrt[25 - 5*Sqrt[5]] + 120*Sqrt[5 - Sqrt[5]] + 
      220*Sqrt[5 + Sqrt[5]] + 36*Sqrt[5*(5 + Sqrt[5])] + 
      56*Sqrt[25 - 5*Sqrt[5]]*x - 160*Sqrt[5 - Sqrt[5]]*x - 
      380*Sqrt[5 + Sqrt[5]]*x + 28*Sqrt[5*(5 + Sqrt[5])]*x - 
      80*Sqrt[25 - 5*Sqrt[5]]*x^2 + 40*Sqrt[5 - Sqrt[5]]*x^2 + 
      180*Sqrt[5 + Sqrt[5]]*x^2 - 84*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      8*Sqrt[25 - 5*Sqrt[5]]*x^3 - 20*Sqrt[5 + Sqrt[5]]*x^3 + 
      20*Sqrt[5*(5 + Sqrt[5])]*x^3 - 106*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      190*Sqrt[5 - Sqrt[5]]*x*y + 400*Sqrt[5 + Sqrt[5]]*x*y - 
      116*Sqrt[5*(5 + Sqrt[5])]*x*y + 144*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      200*Sqrt[5 - Sqrt[5]]*x^2*y - 440*Sqrt[5 + Sqrt[5]]*x^2*y + 
      200*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 100*Sqrt[5 + Sqrt[5]]*x^3*y - 
      64*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 86*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      160*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 295*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      131*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      50*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 145*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      77*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 9*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 70*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      34*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 88*Sqrt[(25 - 5*Sqrt[5])/5] - 
      44*Sqrt[25 - 5*Sqrt[5]] - 300*Sqrt[5 - Sqrt[5]] + 
      120*Sqrt[5*(5 - Sqrt[5])] - 272*Sqrt[5 + Sqrt[5]] + 
      152*Sqrt[5*(5 + Sqrt[5])] - 432*Sqrt[(25 - 5*Sqrt[5])/5]*x + 
      216*Sqrt[25 - 5*Sqrt[5]]*x + 400*Sqrt[5 - Sqrt[5]]*x - 
      160*Sqrt[5*(5 - Sqrt[5])]*x - 116*Sqrt[5 + Sqrt[5]]*x + 
      52*Sqrt[5*(5 + Sqrt[5])]*x - 100*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      40*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 20*Sqrt[5 - Sqrt[5]]*x^2 + 
      8*Sqrt[5*(5 - Sqrt[5])]*x^2 + 288*Sqrt[5 + Sqrt[5]]*x^2 - 
      136*Sqrt[5*(5 + Sqrt[5])]*x^2 - 16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 
      8*Sqrt[25 - 5*Sqrt[5]]*x^3 - 60*Sqrt[5 + Sqrt[5]]*x^3 + 
      28*Sqrt[5*(5 + Sqrt[5])]*x^3 + 292*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 
      146*Sqrt[25 - 5*Sqrt[5]]*x*y - 330*Sqrt[5 - Sqrt[5]]*x*y + 
      132*Sqrt[5*(5 - Sqrt[5])]*x*y - 6*(5 + Sqrt[5])^(3/2)*x*y + 
      (12*(5 + Sqrt[5])^(3/2)*x*y)/Sqrt[5] - 288*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*
       y + 144*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 140*Sqrt[5 - Sqrt[5]]*x^2*y + 
      56*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 650*Sqrt[5 + Sqrt[5]]*x^2*y + 
      298*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 
      18*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 30*Sqrt[5 - Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 228*Sqrt[5 + Sqrt[5]]*x^3*y - 
      104*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 132*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*
       y^2 - 66*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 120*Sqrt[5 - Sqrt[5]]*x^2*
       y^2 - 48*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 362*Sqrt[5 + Sqrt[5]]*x^2*
       y^2 - 164*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 20*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^2 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 50*Sqrt[5 - Sqrt[5]]*x^3*
       y^2 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 - 299*Sqrt[5 + Sqrt[5]]*x^3*
       y^2 + 135*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 18*Sqrt[(25 - 5*Sqrt[5])/5]*
       x^3*y^3 - 9*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 25*Sqrt[5 - Sqrt[5]]*x^3*
       y^3 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 138*Sqrt[5 + Sqrt[5]]*x^3*
       y^3 - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -304*Sqrt[(25 - 5*Sqrt[5])/5] + 152*Sqrt[25 - 5*Sqrt[5]] + 
      640*Sqrt[5 - Sqrt[5]] - 256*Sqrt[5*(5 - Sqrt[5])] + 
      476*Sqrt[5 + Sqrt[5]] - 204*Sqrt[5*(5 + Sqrt[5])] - 
      504*Sqrt[(25 - 5*Sqrt[5])/5]*x + 252*Sqrt[25 - 5*Sqrt[5]]*x + 
      780*Sqrt[5 - Sqrt[5]]*x - 312*Sqrt[5*(5 - Sqrt[5])]*x + 
      408*Sqrt[5 + Sqrt[5]]*x - 144*Sqrt[5*(5 + Sqrt[5])]*x - 
      80*Sqrt[25 - 5*Sqrt[5]]*x^2 + 32*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      120*Sqrt[5 - Sqrt[5]]*x^2 + 48*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      116*Sqrt[5 + Sqrt[5]]*x^2 - 52*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 4*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      20*Sqrt[5 - Sqrt[5]]*x^3 + 8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      40*Sqrt[5 + Sqrt[5]]*x^3 + 16*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      124*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 62*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      510*Sqrt[5 - Sqrt[5]]*x*y + 204*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      656*Sqrt[5 + Sqrt[5]]*x*y + 268*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      456*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y + 228*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      640*Sqrt[5 - Sqrt[5]]*x^2*y - 256*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      170*Sqrt[5 + Sqrt[5]]*x^2*y - 58*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      146*Sqrt[5 + Sqrt[5]]*x^3*y - 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      154*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 77*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 405*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 162*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 346*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 144*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 25*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 188*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 82*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 + 10*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -80*Sqrt[25 - 5*Sqrt[5]] + 32*Sqrt[5*(25 - 5*Sqrt[5])] - 
      240*Sqrt[5 - Sqrt[5]] + 96*Sqrt[5*(5 - Sqrt[5])] - 
      80*Sqrt[5 + Sqrt[5]] + 80*Sqrt[5*(5 + Sqrt[5])] + 
      80*Sqrt[25 - 5*Sqrt[5]]*x - 32*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      200*Sqrt[5 - Sqrt[5]]*x + 80*Sqrt[5*(5 - Sqrt[5])]*x - 
      740*Sqrt[5 + Sqrt[5]]*x + 324*Sqrt[5*(5 + Sqrt[5])]*x - 
      100*Sqrt[25 - 5*Sqrt[5]]*x^2 + 40*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      100*Sqrt[5 - Sqrt[5]]*x^2 - 40*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      460*Sqrt[5 + Sqrt[5]]*x^2 - 228*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 + 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      80*Sqrt[5 + Sqrt[5]]*x^3 + 40*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      560*Sqrt[5 - Sqrt[5]]*x*y - 224*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      900*Sqrt[5 + Sqrt[5]]*x*y - 404*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      380*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 152*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      80*Sqrt[5 - Sqrt[5]]*x^2*y - 32*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      1270*Sqrt[5 + Sqrt[5]]*x^2*y + 590*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      310*Sqrt[5 + Sqrt[5]]*x^3*y - 146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      225*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 90*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 5*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 2*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      905*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 407*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      75*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 30*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 - 
      410*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 188*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      40*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 16*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      190*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 86*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -80*Sqrt[25 - 5*Sqrt[5]] + 32*Sqrt[5*(25 - 5*Sqrt[5])] - 
      240*Sqrt[5 - Sqrt[5]] + 96*Sqrt[5*(5 - Sqrt[5])] - 
      80*Sqrt[5 + Sqrt[5]] + 80*Sqrt[5*(5 + Sqrt[5])] + 
      40*Sqrt[25 - 5*Sqrt[5]]*x - 16*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      160*Sqrt[5 - Sqrt[5]]*x + 64*Sqrt[5*(5 - Sqrt[5])]*x - 
      580*Sqrt[5 + Sqrt[5]]*x + 212*Sqrt[5*(5 + Sqrt[5])]*x - 
      40*Sqrt[25 - 5*Sqrt[5]]*x^2 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      360*Sqrt[5 - Sqrt[5]]*x^2 - 144*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      720*Sqrt[5 + Sqrt[5]]*x^2 - 304*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      40*Sqrt[5 - Sqrt[5]]*x^3 + 16*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      140*Sqrt[5 + Sqrt[5]]*x^3 + 60*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      90*Sqrt[25 - 5*Sqrt[5]]*x*y + 36*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 
      230*Sqrt[5 - Sqrt[5]]*x*y - 92*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      920*Sqrt[5 + Sqrt[5]]*x*y - 380*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      150*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 60*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      770*Sqrt[5 - Sqrt[5]]*x^2*y + 308*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      1620*Sqrt[5 + Sqrt[5]]*x^2*y + 704*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 
      90*Sqrt[5 - Sqrt[5]]*x^3*y - 36*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      520*Sqrt[5 + Sqrt[5]]*x^3*y - 228*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      130*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 52*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 470*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 188*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 1020*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 452*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 50*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 20*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 675*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 299*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 10*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 45*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 18*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 310*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 138*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -80*Sqrt[25 - 5*Sqrt[5]] + 32*Sqrt[5*(25 - 5*Sqrt[5])] - 
      240*Sqrt[5 - Sqrt[5]] + 96*Sqrt[5*(5 - Sqrt[5])] - 
      80*Sqrt[5 + Sqrt[5]] + 80*Sqrt[5*(5 + Sqrt[5])] + 
      180*Sqrt[25 - 5*Sqrt[5]]*x - 72*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      500*Sqrt[5 - Sqrt[5]]*x - 200*Sqrt[5*(5 - Sqrt[5])]*x - 
      40*Sqrt[5 + Sqrt[5]]*x - 16*Sqrt[5*(5 + Sqrt[5])]*x - 
      200*Sqrt[25 - 5*Sqrt[5]]*x^2 + 80*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      200*Sqrt[5 - Sqrt[5]]*x^2 + 80*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      360*Sqrt[5 + Sqrt[5]]*x^2 - 168*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 + 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      80*Sqrt[5 + Sqrt[5]]*x^3 + 40*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      160*Sqrt[25 - 5*Sqrt[5]]*x*y + 64*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 
      260*Sqrt[5 - Sqrt[5]]*x*y + 104*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      250*Sqrt[5 + Sqrt[5]]*x*y - 98*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      240*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 96*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      840*Sqrt[5 + Sqrt[5]]*x^2*y + 384*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      310*Sqrt[5 + Sqrt[5]]*x^3*y - 146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      105*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 42*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 125*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 50*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 585*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 263*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 10*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 75*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 30*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 410*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 188*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^3 + 40*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 16*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 190*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 86*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -200*Sqrt[25 - 5*Sqrt[5]] + 80*Sqrt[5*(25 - 5*Sqrt[5])] + 
      240*Sqrt[5 - Sqrt[5]] - 96*Sqrt[5*(5 - Sqrt[5])] + 
      1060*Sqrt[5 + Sqrt[5]] - 436*Sqrt[5*(5 + Sqrt[5])] + 
      400*Sqrt[25 - 5*Sqrt[5]]*x - 160*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      240*Sqrt[5 - Sqrt[5]]*x - 96*Sqrt[5*(5 - Sqrt[5])]*x - 
      1120*Sqrt[5 + Sqrt[5]]*x + 528*Sqrt[5*(5 + Sqrt[5])]*x - 
      40*Sqrt[25 - 5*Sqrt[5]]*x^2 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      140*Sqrt[5 + Sqrt[5]]*x^2 - 76*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      400*Sqrt[25 - 5*Sqrt[5]]*x*y + 160*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 
      1480*Sqrt[5 + Sqrt[5]]*x*y - 680*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      70*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 28*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      50*Sqrt[5 - Sqrt[5]]*x^2*y + 20*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      340*Sqrt[5 + Sqrt[5]]*x^2*y + 168*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      40*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      50*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 20*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      235*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 111*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 
     20*Sqrt[25 - 5*Sqrt[5]] + 84*Sqrt[5 - Sqrt[5]] + 24*Sqrt[5 + Sqrt[5]] - 
      16*Sqrt[5*(5 + Sqrt[5])] + 64*Sqrt[5 - Sqrt[5]]*x + 
      88*Sqrt[5 + Sqrt[5]]*x - 4*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      20*Sqrt[5 - Sqrt[5]]*x^2 - 16*Sqrt[5 + Sqrt[5]]*x^2 + 
      6*Sqrt[25 - 5*Sqrt[5]]*x*y - 46*Sqrt[5 - Sqrt[5]]*x*y - 
      62*Sqrt[5 + Sqrt[5]]*x*y + 6*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      24*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 96*Sqrt[5 - Sqrt[5]]*x^2*y + 
      60*Sqrt[5 + Sqrt[5]]*x^2*y - 4*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      10*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 54*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      39*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 7*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 
     320*Sqrt[25 - 5*Sqrt[5]] - 128*Sqrt[5*(25 - 5*Sqrt[5])] + 
      720*Sqrt[5 - Sqrt[5]] - 288*Sqrt[5*(5 - Sqrt[5])] + 
      40*Sqrt[5 + Sqrt[5]] + 24*Sqrt[5*(5 + Sqrt[5])] + 
      680*Sqrt[5 - Sqrt[5]]*x - 272*Sqrt[5*(5 - Sqrt[5])]*x + 
      980*Sqrt[5 + Sqrt[5]]*x - 420*Sqrt[5*(5 + Sqrt[5])]*x - 
      180*Sqrt[25 - 5*Sqrt[5]]*x^2 + 72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      220*Sqrt[5 - Sqrt[5]]*x^2 + 88*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      140*Sqrt[5 + Sqrt[5]]*x^2 - 84*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 + 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      80*Sqrt[5 + Sqrt[5]]*x^3 + 40*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      320*Sqrt[25 - 5*Sqrt[5]]*x*y - 128*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 
      200*Sqrt[5 - Sqrt[5]]*x*y + 80*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      1320*Sqrt[5 + Sqrt[5]]*x*y + 584*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      380*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 152*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      720*Sqrt[5 - Sqrt[5]]*x^2*y - 288*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      110*Sqrt[5 + Sqrt[5]]*x^2*y - 6*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      310*Sqrt[5 + Sqrt[5]]*x^3*y - 146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      135*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 54*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 385*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 154*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 305*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 123*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 10*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 75*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 30*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 410*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 188*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^3 + 40*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 16*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 190*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 86*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, 40*Sqrt[5 - Sqrt[5]] - 8*Sqrt[5*(5 - Sqrt[5])] + 
      60*Sqrt[5 + Sqrt[5]] - 12*Sqrt[5*(5 + Sqrt[5])] - 
      40*Sqrt[5 - Sqrt[5]]*x + 8*Sqrt[5*(5 - Sqrt[5])]*x - 
      80*Sqrt[5 + Sqrt[5]]*x + 16*Sqrt[5*(5 + Sqrt[5])]*x + 
      20*Sqrt[5 + Sqrt[5]]*x^2 - 4*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      60*Sqrt[25 - 5*Sqrt[5]]*x*y - 24*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 
      180*Sqrt[5 - Sqrt[5]]*x*y - 72*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      80*Sqrt[5 + Sqrt[5]]*x*y - 24*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      40*Sqrt[5 + Sqrt[5]]*x^2*y + 12*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      25*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 9*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 
     -96*Sqrt[(5 - Sqrt[5])/5] + 16*Sqrt[5 - Sqrt[5]] + 
      16*Sqrt[5*(5 - Sqrt[5])] - 144*Sqrt[(5 + Sqrt[5])/5] + 
      24*Sqrt[5 + Sqrt[5]] + 24*Sqrt[5*(5 + Sqrt[5])] + 
      96*Sqrt[(5 - Sqrt[5])/5]*x - 16*Sqrt[5 - Sqrt[5]]*x - 
      16*Sqrt[5*(5 - Sqrt[5])]*x + 192*Sqrt[(5 + Sqrt[5])/5]*x - 
      32*Sqrt[5 + Sqrt[5]]*x - 32*Sqrt[5*(5 + Sqrt[5])]*x - 
      48*Sqrt[(5 + Sqrt[5])/5]*x^2 + 8*Sqrt[5 + Sqrt[5]]*x^2 + 
      8*Sqrt[5*(5 + Sqrt[5])]*x^2 - 24*Sqrt[(5 - Sqrt[5])/5]*x*y + 
      12*Sqrt[5 - Sqrt[5]]*x*y - 128*Sqrt[(5 + Sqrt[5])/5]*x*y + 
      32*Sqrt[5 + Sqrt[5]]*x*y + 16*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      64*Sqrt[(5 + Sqrt[5])/5]*x^2*y - 16*Sqrt[5 + Sqrt[5]]*x^2*y - 
      8*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 18*Sqrt[(5 + Sqrt[5])/5]*x^2*y^2 + 
      7*Sqrt[5 + Sqrt[5]]*x^2*y^2 + Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 
     -40*Sqrt[25 - 5*Sqrt[5]] + 16*Sqrt[5*(25 - 5*Sqrt[5])] - 
      480*Sqrt[5 - Sqrt[5]] + 192*Sqrt[5*(5 - Sqrt[5])] - 
      500*Sqrt[5 + Sqrt[5]] + 324*Sqrt[5*(5 + Sqrt[5])] + 
      420*Sqrt[25 - 5*Sqrt[5]]*x - 168*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      1220*Sqrt[5 - Sqrt[5]]*x - 488*Sqrt[5*(5 - Sqrt[5])]*x + 
      320*Sqrt[5 + Sqrt[5]]*x - 168*Sqrt[5*(5 + Sqrt[5])]*x - 
      240*Sqrt[25 - 5*Sqrt[5]]*x^2 + 96*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      280*Sqrt[5 - Sqrt[5]]*x^2 + 112*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      260*Sqrt[5 + Sqrt[5]]*x^2 - 132*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 + 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      80*Sqrt[5 + Sqrt[5]]*x^3 + 40*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      190*Sqrt[25 - 5*Sqrt[5]]*x*y + 76*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 
      710*Sqrt[5 - Sqrt[5]]*x*y + 284*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      420*Sqrt[5 + Sqrt[5]]*x*y + 176*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      260*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 104*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      670*Sqrt[5 + Sqrt[5]]*x^2*y + 318*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      310*Sqrt[5 + Sqrt[5]]*x^3*y - 146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      115*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 46*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 105*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 42*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 460*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 210*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 10*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 75*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 30*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 410*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 188*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^3 + 40*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 16*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 190*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 86*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, 120*Sqrt[25 - 5*Sqrt[5]] - 48*Sqrt[5*(25 - 5*Sqrt[5])] + 
      1080*Sqrt[5 - Sqrt[5]] - 432*Sqrt[5*(5 - Sqrt[5])] + 
      1280*Sqrt[5 + Sqrt[5]] - 528*Sqrt[5*(5 + Sqrt[5])] + 
      540*Sqrt[25 - 5*Sqrt[5]]*x - 216*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      300*Sqrt[5 - Sqrt[5]]*x - 120*Sqrt[5*(5 - Sqrt[5])]*x - 
      1320*Sqrt[5 + Sqrt[5]]*x + 672*Sqrt[5*(5 + Sqrt[5])]*x - 
      100*Sqrt[25 - 5*Sqrt[5]]*x^2 + 40*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      260*Sqrt[5 - Sqrt[5]]*x^2 - 104*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      860*Sqrt[5 + Sqrt[5]]*x^2 - 404*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      40*Sqrt[5 - Sqrt[5]]*x^3 + 16*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      140*Sqrt[5 + Sqrt[5]]*x^3 + 60*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      350*Sqrt[25 - 5*Sqrt[5]]*x*y + 140*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 
      10*Sqrt[5 - Sqrt[5]]*x*y - 4*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      1180*Sqrt[5 + Sqrt[5]]*x*y - 576*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      350*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 140*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      250*Sqrt[5 - Sqrt[5]]*x^2*y + 100*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      1820*Sqrt[5 + Sqrt[5]]*x^2*y + 848*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y + 
      90*Sqrt[5 - Sqrt[5]]*x^3*y - 36*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      520*Sqrt[5 + Sqrt[5]]*x^3*y - 228*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      190*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 76*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 90*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 36*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 880*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 408*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 50*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 20*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 - 675*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 299*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 10*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 45*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 18*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 + 310*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 138*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3}
 
F834 = {4568*Sqrt[25 - 5*Sqrt[5]] + 10200*Sqrt[5 - Sqrt[5]] - 
      3120*Sqrt[5 + Sqrt[5]] - 1408*Sqrt[5*(5 + Sqrt[5])] + 
      8336*Sqrt[25 - 5*Sqrt[5]]*x + 18800*Sqrt[5 - Sqrt[5]]*x - 
      2320*Sqrt[5 + Sqrt[5]]*x - 1104*Sqrt[5*(5 + Sqrt[5])]*x + 
      320*Sqrt[25 - 5*Sqrt[5]]*x^2 + 720*Sqrt[5 - Sqrt[5]]*x^2 - 
      760*Sqrt[5 + Sqrt[5]]*x^2 - 328*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      104*Sqrt[25 - 5*Sqrt[5]]*x^3 - 280*Sqrt[5 - Sqrt[5]]*x^3 + 
      280*Sqrt[5 + Sqrt[5]]*x^3 + 120*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      5196*Sqrt[25 - 5*Sqrt[5]]*x*y - 11660*Sqrt[5 - Sqrt[5]]*x*y + 
      440*Sqrt[5 + Sqrt[5]]*x*y + 224*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      40*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 120*Sqrt[5 - Sqrt[5]]*x^2*y + 
      1560*Sqrt[5 + Sqrt[5]]*x^2*y + 696*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      312*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 720*Sqrt[5 - Sqrt[5]]*x^3*y - 
      500*Sqrt[5 + Sqrt[5]]*x^3*y - 220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      510*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 1150*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      1180*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 528*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 660*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 
      360*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 245*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 
      90*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -114080*Sqrt[2*(25 - 5*Sqrt[5])] + 45632*Sqrt[10*(25 - 5*Sqrt[5])] - 
      255200*Sqrt[2*(5 - Sqrt[5])] + 102080*Sqrt[10*(5 - Sqrt[5])] + 
      24800*Sqrt[2*(5 + Sqrt[5])] + 11232*Sqrt[10*(5 + Sqrt[5])] + 
      87200*Sqrt[2*(25 - 5*Sqrt[5])]*x - 34880*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      195360*Sqrt[2*(5 - Sqrt[5])]*x - 78144*Sqrt[10*(5 - Sqrt[5])]*x + 
      6400*Sqrt[2*(5 + Sqrt[5])]*x + 2496*Sqrt[10*(5 + Sqrt[5])]*x - 
      69280*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 27712*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 155360*Sqrt[2*(5 - Sqrt[5])]*x^2 + 62144*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 7200*Sqrt[2*(5 + Sqrt[5])]*x^2 - 2848*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 256*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3 - 1280*Sqrt[2*(5 - Sqrt[5])]*x^3 + 512*Sqrt[10*(5 - Sqrt[5])]*
       x^3 + 960*Sqrt[2*(5 + Sqrt[5])]*x^3 + 320*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      61920*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 24768*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 138560*Sqrt[2*(5 - Sqrt[5])]*x*y + 55424*Sqrt[10*(5 - Sqrt[5])]*x*
       y - 880*Sqrt[2*(5 + Sqrt[5])]*x*y - 336*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      151920*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 60768*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 339920*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      135968*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 5040*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y + 2096*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 7840*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y - 3136*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 
      17440*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 
      1600*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      51040*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      20416*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 114160*Sqrt[2*(5 - Sqrt[5])]*
       x^2*y^2 + 45664*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 
      1000*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 472*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y^2 - 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 + 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 - 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -65040*Sqrt[2*(25 - 5*Sqrt[5])] + 26016*Sqrt[10*(25 - 5*Sqrt[5])] - 
      145520*Sqrt[2*(5 - Sqrt[5])] + 58208*Sqrt[10*(5 - Sqrt[5])] + 
      13840*Sqrt[2*(5 + Sqrt[5])] + 6224*Sqrt[10*(5 + Sqrt[5])] + 
      5840*Sqrt[2*(25 - 5*Sqrt[5])]*x - 2336*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      13360*Sqrt[2*(5 - Sqrt[5])]*x - 5344*Sqrt[10*(5 - Sqrt[5])]*x + 
      2800*Sqrt[2*(5 + Sqrt[5])]*x + 1200*Sqrt[10*(5 + Sqrt[5])]*x - 
      13600*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 5440*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 30720*Sqrt[2*(5 - Sqrt[5])]*x^2 + 12288*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 3280*Sqrt[2*(5 + Sqrt[5])]*x^2 - 1520*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3 + 1920*Sqrt[2*(5 - Sqrt[5])]*x^3 - 768*Sqrt[10*(5 - Sqrt[5])]*
       x^3 - 240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      20800*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 8320*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 46560*Sqrt[2*(5 - Sqrt[5])]*x*y + 18624*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 880*Sqrt[2*(5 + Sqrt[5])]*x*y + 400*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      25840*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 10336*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 57840*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      23136*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 960*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      480*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 5160*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y + 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 400*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      12040*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 4816*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 26920*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      10768*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 2160*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 960*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 848*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 31540*Sqrt[2*(25 - 5*Sqrt[5])] - 
      12616*Sqrt[10*(25 - 5*Sqrt[5])] + 70500*Sqrt[2*(5 - Sqrt[5])] - 
      28200*Sqrt[10*(5 - Sqrt[5])] - 3520*Sqrt[2*(5 + Sqrt[5])] - 
      1560*Sqrt[10*(5 + Sqrt[5])] + 6000*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      2400*Sqrt[10*(25 - 5*Sqrt[5])]*x + 13480*Sqrt[2*(5 - Sqrt[5])]*x - 
      5392*Sqrt[10*(5 - Sqrt[5])]*x - 700*Sqrt[2*(5 + Sqrt[5])]*x - 
      324*Sqrt[10*(5 + Sqrt[5])]*x + 8700*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      3480*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 19380*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      7752*Sqrt[10*(5 - Sqrt[5])]*x^2 - 20*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      12*Sqrt[10*(5 + Sqrt[5])]*x^2 - 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 + 240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 + 9760*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      3904*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 21820*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      8728*Sqrt[10*(5 - Sqrt[5])]*x*y - 670*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      306*Sqrt[10*(5 + Sqrt[5])]*x*y - 1820*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y + 
      728*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y - 4060*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y + 1624*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 1080*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y + 496*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 1960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y - 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 
      4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      155*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 62*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 345*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 138*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 - 1375*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 
      623*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 960*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      5360*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 2144*Sqrt[10*(5 - Sqrt[5])]*x^3*
       y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*
       x^3*y^2 + 1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      460*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^3 - 1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^3 - 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     6720*Sqrt[2*(25 - 5*Sqrt[5])] - 2688*Sqrt[10*(25 - 5*Sqrt[5])] + 
      15040*Sqrt[2*(5 - Sqrt[5])] - 6016*Sqrt[10*(5 - Sqrt[5])] + 
      2880*Sqrt[2*(5 + Sqrt[5])] + 1344*Sqrt[10*(5 + Sqrt[5])] - 
      59600*Sqrt[2*(25 - 5*Sqrt[5])]*x + 23840*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      133360*Sqrt[2*(5 - Sqrt[5])]*x + 53344*Sqrt[10*(5 - Sqrt[5])]*x + 
      5360*Sqrt[2*(5 + Sqrt[5])]*x + 2288*Sqrt[10*(5 + Sqrt[5])]*x - 
      23200*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 9280*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 51840*Sqrt[2*(5 - Sqrt[5])]*x^2 + 20736*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 2480*Sqrt[2*(5 + Sqrt[5])]*x^2 + 1296*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 + 160*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      52920*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 21168*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 118360*Sqrt[2*(5 - Sqrt[5])]*x*y - 47344*Sqrt[10*(5 - Sqrt[5])]*x*
       y - 2560*Sqrt[2*(5 + Sqrt[5])]*x*y - 1168*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      44400*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 17760*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 99280*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      39712*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 2640*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      1232*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 20100*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 8040*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      44940*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 17976*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 700*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 316*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 + 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, -27420*Sqrt[2*(25 - 5*Sqrt[5])] + 
      10968*Sqrt[10*(25 - 5*Sqrt[5])] - 61340*Sqrt[2*(5 - Sqrt[5])] + 
      24536*Sqrt[10*(5 - Sqrt[5])] + 6040*Sqrt[2*(5 + Sqrt[5])] + 
      2736*Sqrt[10*(5 + Sqrt[5])] + 10040*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      4016*Sqrt[10*(25 - 5*Sqrt[5])]*x + 22560*Sqrt[2*(5 - Sqrt[5])]*x - 
      9024*Sqrt[10*(5 - Sqrt[5])]*x + 4700*Sqrt[2*(5 + Sqrt[5])]*x + 
      1972*Sqrt[10*(5 + Sqrt[5])]*x - 19740*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      7896*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 44260*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      17704*Sqrt[10*(5 - Sqrt[5])]*x^2 + 540*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      364*Sqrt[10*(5 + Sqrt[5])]*x^2 - 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 + 240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 12140*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      4856*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 27160*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      10864*Sqrt[10*(5 - Sqrt[5])]*x*y - 2050*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      902*Sqrt[10*(5 + Sqrt[5])]*x*y + 36660*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      14664*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 82020*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 32808*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 800*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y - 408*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 1960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y - 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 
      4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      12445*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 4978*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 27835*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      11134*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 445*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 209*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 960*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 5360*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 
      2144*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 460*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 - 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -121920*Sqrt[2*(25 - 5*Sqrt[5])] + 48768*Sqrt[10*(25 - 5*Sqrt[5])] - 
      272640*Sqrt[2*(5 - Sqrt[5])] + 109056*Sqrt[10*(5 - Sqrt[5])] + 
      24160*Sqrt[2*(5 + Sqrt[5])] + 10784*Sqrt[10*(5 + Sqrt[5])] + 
      28560*Sqrt[2*(25 - 5*Sqrt[5])]*x - 11424*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      63920*Sqrt[2*(5 - Sqrt[5])]*x - 25568*Sqrt[10*(5 - Sqrt[5])]*x + 
      4880*Sqrt[2*(5 + Sqrt[5])]*x + 2192*Sqrt[10*(5 + Sqrt[5])]*x - 
      39680*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 15872*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 88800*Sqrt[2*(5 - Sqrt[5])]*x^2 + 35520*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 10000*Sqrt[2*(5 + Sqrt[5])]*x^2 - 4336*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 + 160*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      35480*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 14192*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 79320*Sqrt[2*(5 - Sqrt[5])]*x*y + 31728*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 1040*Sqrt[2*(5 + Sqrt[5])]*x*y + 448*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      91760*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 36704*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 205200*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      82080*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 6480*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      2832*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 32780*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 13112*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      73300*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 29320*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 2060*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 924*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 + 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 3656*Sqrt[25 - 5*Sqrt[5]] + 
      8200*Sqrt[5 - Sqrt[5]] - 3120*Sqrt[5 + Sqrt[5]] - 
      1376*Sqrt[5*(5 + Sqrt[5])] + 1168*Sqrt[25 - 5*Sqrt[5]]*x + 
      2480*Sqrt[5 - Sqrt[5]]*x - 240*Sqrt[5 + Sqrt[5]]*x - 
      112*Sqrt[5*(5 + Sqrt[5])]*x - 208*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      320*Sqrt[5 - Sqrt[5]]*x^2 + 2280*Sqrt[5 + Sqrt[5]]*x^2 + 
      1016*Sqrt[5*(5 + Sqrt[5])]*x^2 - 104*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      280*Sqrt[5 - Sqrt[5]]*x^3 + 280*Sqrt[5 + Sqrt[5]]*x^3 + 
      120*Sqrt[5*(5 + Sqrt[5])]*x^3 + 532*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      1140*Sqrt[5 - Sqrt[5]]*x*y - 1240*Sqrt[5 + Sqrt[5]]*x*y - 
      528*Sqrt[5*(5 + Sqrt[5])]*x*y - 24*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      40*Sqrt[5 - Sqrt[5]]*x^2*y - 840*Sqrt[5 + Sqrt[5]]*x^2*y - 
      392*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 312*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      720*Sqrt[5 - Sqrt[5]]*x^3*y - 500*Sqrt[5 + Sqrt[5]]*x^3*y - 
      220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 362*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      810*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 1220*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      544*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      660*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 360*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      245*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 90*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 108320*Sqrt[2*(25 - 5*Sqrt[5])] - 
      43328*Sqrt[10*(25 - 5*Sqrt[5])] + 242080*Sqrt[2*(5 - Sqrt[5])] - 
      96832*Sqrt[10*(5 - Sqrt[5])] - 11520*Sqrt[2*(5 + Sqrt[5])] - 
      5056*Sqrt[10*(5 + Sqrt[5])] - 18720*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      7488*Sqrt[10*(25 - 5*Sqrt[5])]*x - 41440*Sqrt[2*(5 - Sqrt[5])]*x + 
      16576*Sqrt[10*(5 - Sqrt[5])]*x - 480*Sqrt[2*(5 + Sqrt[5])]*x - 
      480*Sqrt[10*(5 + Sqrt[5])]*x - 13920*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      5568*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 31520*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      12608*Sqrt[10*(5 - Sqrt[5])]*x^2 + 2720*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      1440*Sqrt[10*(5 + Sqrt[5])]*x^2 - 640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      256*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 1280*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      512*Sqrt[10*(5 - Sqrt[5])]*x^3 + 960*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 + 68640*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      27456*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 153440*Sqrt[2*(5 - Sqrt[5])]*x*
       y - 61376*Sqrt[10*(5 - Sqrt[5])]*x*y - 2880*Sqrt[2*(5 + Sqrt[5])]*x*
       y - 1280*Sqrt[10*(5 + Sqrt[5])]*x*y + 51600*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y - 20640*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      115440*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 46176*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 560*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 240*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y + 7840*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y - 
      3136*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 17440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 1600*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 17680*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 7072*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      39520*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 15808*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 3640*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 1640*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 + 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 - 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     58960*Sqrt[2*(25 - 5*Sqrt[5])] - 23584*Sqrt[10*(25 - 5*Sqrt[5])] + 
      131760*Sqrt[2*(5 - Sqrt[5])] - 52704*Sqrt[10*(5 - Sqrt[5])] - 
      4240*Sqrt[2*(5 + Sqrt[5])] - 1872*Sqrt[10*(5 + Sqrt[5])] + 
      35600*Sqrt[2*(25 - 5*Sqrt[5])]*x - 14240*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      79920*Sqrt[2*(5 - Sqrt[5])]*x - 31968*Sqrt[10*(5 - Sqrt[5])]*x + 
      400*Sqrt[2*(5 + Sqrt[5])]*x + 144*Sqrt[10*(5 + Sqrt[5])]*x + 
      3520*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 1408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 + 7520*Sqrt[2*(5 - Sqrt[5])]*x^2 - 3008*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 560*Sqrt[2*(5 + Sqrt[5])]*x^2 + 208*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 
      1920*Sqrt[2*(5 - Sqrt[5])]*x^3 - 768*Sqrt[10*(5 - Sqrt[5])]*x^3 - 
      240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      29440*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 11776*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 65920*Sqrt[2*(5 - Sqrt[5])]*x*y + 26368*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 160*Sqrt[2*(5 + Sqrt[5])]*x*y + 96*Sqrt[10*(5 + Sqrt[5])]*x*y - 
      8400*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y + 3360*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y - 18640*Sqrt[2*(5 - Sqrt[5])]*x^2*y + 
      7456*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 960*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      416*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 5160*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y + 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 400*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y + 
      2480*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 992*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 5520*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 
      2208*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 640*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 288*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 848*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, -9780*Sqrt[2*(25 - 5*Sqrt[5])] + 
      3912*Sqrt[10*(25 - 5*Sqrt[5])] - 21900*Sqrt[2*(5 - Sqrt[5])] + 
      8760*Sqrt[10*(5 - Sqrt[5])] + 7140*Sqrt[2*(5 + Sqrt[5])] + 
      3220*Sqrt[10*(5 + Sqrt[5])] + 23400*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      9360*Sqrt[10*(25 - 5*Sqrt[5])]*x + 52440*Sqrt[2*(5 - Sqrt[5])]*x - 
      20976*Sqrt[10*(5 - Sqrt[5])]*x + 6760*Sqrt[2*(5 + Sqrt[5])]*x + 
      2920*Sqrt[10*(5 + Sqrt[5])]*x - 20060*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      8024*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 44980*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      17992*Sqrt[10*(5 - Sqrt[5])]*x^2 + 1060*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      580*Sqrt[10*(5 + Sqrt[5])]*x^2 - 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 + 240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 15260*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      6104*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 34140*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      13656*Sqrt[10*(5 - Sqrt[5])]*x*y - 3080*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      1360*Sqrt[10*(5 + Sqrt[5])]*x*y + 39180*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y - 15672*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      87660*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 35064*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y - 1320*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 640*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y + 1960*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y - 
      784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 4360*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 400*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 12945*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 5178*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      28955*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 11582*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 595*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 275*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      960*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 5360*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 + 2144*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 460*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 - 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -70800*Sqrt[2*(25 - 5*Sqrt[5])] + 28320*Sqrt[10*(25 - 5*Sqrt[5])] - 
      158320*Sqrt[2*(5 - Sqrt[5])] + 63328*Sqrt[10*(5 - Sqrt[5])] + 
      28880*Sqrt[2*(5 + Sqrt[5])] + 12944*Sqrt[10*(5 + Sqrt[5])] + 
      25920*Sqrt[2*(25 - 5*Sqrt[5])]*x - 10368*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      57920*Sqrt[2*(5 - Sqrt[5])]*x - 23168*Sqrt[10*(5 - Sqrt[5])]*x + 
      3840*Sqrt[2*(5 + Sqrt[5])]*x + 1664*Sqrt[10*(5 + Sqrt[5])]*x - 
      42080*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 16832*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 94080*Sqrt[2*(5 - Sqrt[5])]*x^2 + 37632*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 9520*Sqrt[2*(5 + Sqrt[5])]*x^2 - 4112*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 + 160*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      16480*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 6592*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 36880*Sqrt[2*(5 - Sqrt[5])]*x*y - 14752*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 1960*Sqrt[2*(5 + Sqrt[5])]*x*y + 856*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      108480*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 43392*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 242560*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      97024*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 5600*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      2464*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 42300*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 16920*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      94580*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 37832*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 2660*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 1188*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 + 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 6192*Sqrt[25 - 5*Sqrt[5]] + 
      13840*Sqrt[5 - Sqrt[5]] - 4400*Sqrt[5 + Sqrt[5]] - 
      1968*Sqrt[5*(5 + Sqrt[5])] - 2728*Sqrt[25 - 5*Sqrt[5]]*x - 
      6120*Sqrt[5 - Sqrt[5]]*x - 1680*Sqrt[5 + Sqrt[5]]*x - 
      736*Sqrt[5*(5 + Sqrt[5])]*x - 352*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      720*Sqrt[5 - Sqrt[5]]*x^2 + 1640*Sqrt[5 + Sqrt[5]]*x^2 + 
      728*Sqrt[5*(5 + Sqrt[5])]*x^2 - 104*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      280*Sqrt[5 - Sqrt[5]]*x^3 + 280*Sqrt[5 + Sqrt[5]]*x^3 + 
      120*Sqrt[5*(5 + Sqrt[5])]*x^3 + 4008*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      8920*Sqrt[5 - Sqrt[5]]*x*y - 1000*Sqrt[5 + Sqrt[5]]*x*y - 
      424*Sqrt[5*(5 + Sqrt[5])]*x*y - 256*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      560*Sqrt[5 - Sqrt[5]]*x^2*y + 280*Sqrt[5 + Sqrt[5]]*x^2*y + 
      104*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 312*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      720*Sqrt[5 - Sqrt[5]]*x^3*y - 500*Sqrt[5 + Sqrt[5]]*x^3*y - 
      220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 638*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      1430*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 2000*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      892*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      660*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 360*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      245*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 90*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 77760*Sqrt[2*(25 - 5*Sqrt[5])] - 
      31104*Sqrt[10*(25 - 5*Sqrt[5])] + 173760*Sqrt[2*(5 - Sqrt[5])] - 
      69504*Sqrt[10*(5 - Sqrt[5])] - 5120*Sqrt[2*(5 + Sqrt[5])] - 
      2176*Sqrt[10*(5 + Sqrt[5])] - 31840*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      12736*Sqrt[10*(25 - 5*Sqrt[5])]*x - 70880*Sqrt[2*(5 - Sqrt[5])]*x + 
      28352*Sqrt[10*(5 - Sqrt[5])]*x - 1920*Sqrt[2*(5 + Sqrt[5])]*x - 
      1088*Sqrt[10*(5 + Sqrt[5])]*x - 5920*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      2368*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 13600*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      5440*Sqrt[10*(5 - Sqrt[5])]*x^2 + 320*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      384*Sqrt[10*(5 + Sqrt[5])]*x^2 - 640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      256*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 1280*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      512*Sqrt[10*(5 - Sqrt[5])]*x^3 + 960*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 + 41200*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      16480*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 92080*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      36832*Sqrt[10*(5 - Sqrt[5])]*x*y - 2240*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      992*Sqrt[10*(5 + Sqrt[5])]*x*y + 30720*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      12288*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 68800*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 27520*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 3040*Sqrt[2*(5 + Sqrt[5])]*
       x^2*y + 1312*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 
      7840*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y - 3136*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y + 17440*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 
      6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 1600*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 
      640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 11000*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 4400*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      24600*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 9840*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 4320*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 1936*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 + 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 - 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     53280*Sqrt[2*(25 - 5*Sqrt[5])] - 21312*Sqrt[10*(25 - 5*Sqrt[5])] + 
      119040*Sqrt[2*(5 - Sqrt[5])] - 47616*Sqrt[10*(5 - Sqrt[5])] + 
      4880*Sqrt[2*(5 + Sqrt[5])] + 2224*Sqrt[10*(5 + Sqrt[5])] + 
      97920*Sqrt[2*(25 - 5*Sqrt[5])]*x - 39168*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      219360*Sqrt[2*(5 - Sqrt[5])]*x - 87744*Sqrt[10*(5 - Sqrt[5])]*x + 
      6480*Sqrt[2*(5 + Sqrt[5])]*x + 2736*Sqrt[10*(5 + Sqrt[5])]*x + 
      2240*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 896*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 
      4640*Sqrt[2*(5 - Sqrt[5])]*x^2 - 1856*Sqrt[10*(5 - Sqrt[5])]*x^2 + 
      1680*Sqrt[2*(5 + Sqrt[5])]*x^2 + 752*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 
      1920*Sqrt[2*(5 - Sqrt[5])]*x^3 - 768*Sqrt[10*(5 - Sqrt[5])]*x^3 - 
      240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      103880*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 41552*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 232360*Sqrt[2*(5 - Sqrt[5])]*x*y + 92944*Sqrt[10*(5 - Sqrt[5])]*x*
       y - 2240*Sqrt[2*(5 + Sqrt[5])]*x*y - 976*Sqrt[10*(5 + Sqrt[5])]*x*y - 
      9920*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y + 3968*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y - 22080*Sqrt[2*(5 - Sqrt[5])]*x^2*y + 
      8832*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 2720*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      1184*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 5160*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y + 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 400*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y + 
      2080*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 832*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 4640*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 
      1856*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 1680*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 752*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 848*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, -81440*Sqrt[2*(25 - 5*Sqrt[5])] + 
      32576*Sqrt[10*(25 - 5*Sqrt[5])] - 182240*Sqrt[2*(5 - Sqrt[5])] + 
      72896*Sqrt[10*(5 - Sqrt[5])] + 34720*Sqrt[2*(5 + Sqrt[5])] + 
      15648*Sqrt[10*(5 + Sqrt[5])] + 67200*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      26880*Sqrt[10*(25 - 5*Sqrt[5])]*x + 150720*Sqrt[2*(5 - Sqrt[5])]*x - 
      60288*Sqrt[10*(5 - Sqrt[5])]*x + 17760*Sqrt[2*(5 + Sqrt[5])]*x + 
      7584*Sqrt[10*(5 + Sqrt[5])]*x - 77280*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      30912*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 173280*Sqrt[2*(5 - Sqrt[5])]*
       x^2 + 69312*Sqrt[10*(5 - Sqrt[5])]*x^2 - 4800*Sqrt[2*(5 + Sqrt[5])]*
       x^2 - 1792*Sqrt[10*(5 + Sqrt[5])]*x^2 - 640*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3 + 256*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 1280*Sqrt[2*(5 - Sqrt[5])]*
       x^3 + 512*Sqrt[10*(5 - Sqrt[5])]*x^3 + 960*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 - 11200*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      4480*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 25120*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      10048*Sqrt[10*(5 - Sqrt[5])]*x*y - 6480*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      2864*Sqrt[10*(5 + Sqrt[5])]*x*y + 172800*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y - 69120*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      386560*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 154624*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 2560*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 1024*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y + 7840*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y - 
      3136*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 17440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 1600*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 57720*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 23088*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      129080*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 51632*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 1680*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 768*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 + 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 - 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     28160*Sqrt[2*(25 - 5*Sqrt[5])] - 11264*Sqrt[10*(25 - 5*Sqrt[5])] + 
      62880*Sqrt[2*(5 - Sqrt[5])] - 25152*Sqrt[10*(5 - Sqrt[5])] + 
      8560*Sqrt[2*(5 + Sqrt[5])] + 3856*Sqrt[10*(5 + Sqrt[5])] - 
      16640*Sqrt[2*(25 - 5*Sqrt[5])]*x + 6656*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      36960*Sqrt[2*(5 - Sqrt[5])]*x + 14784*Sqrt[10*(5 - Sqrt[5])]*x - 
      3920*Sqrt[2*(5 + Sqrt[5])]*x - 1712*Sqrt[10*(5 + Sqrt[5])]*x - 
      12320*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 4928*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 27840*Sqrt[2*(5 - Sqrt[5])]*x^2 + 11136*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 4400*Sqrt[2*(5 + Sqrt[5])]*x^2 - 2064*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3 + 1920*Sqrt[2*(5 - Sqrt[5])]*x^3 - 768*Sqrt[10*(5 - Sqrt[5])]*
       x^3 - 240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 80*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      40440*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 16176*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 90360*Sqrt[2*(5 - Sqrt[5])]*x*y - 36144*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 3600*Sqrt[2*(5 + Sqrt[5])]*x*y + 1632*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      27360*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 10944*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 61280*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      24512*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 2720*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      1248*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 5160*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y + 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 400*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      11640*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 4656*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 26040*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      10416*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 1120*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 496*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 848*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 35780*Sqrt[2*(25 - 5*Sqrt[5])] - 
      14312*Sqrt[10*(25 - 5*Sqrt[5])] + 79980*Sqrt[2*(5 - Sqrt[5])] - 
      31992*Sqrt[10*(5 - Sqrt[5])] - 3660*Sqrt[2*(5 + Sqrt[5])] - 
      1612*Sqrt[10*(5 + Sqrt[5])] + 2600*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      1040*Sqrt[10*(25 - 5*Sqrt[5])]*x + 5880*Sqrt[2*(5 - Sqrt[5])]*x - 
      2352*Sqrt[10*(5 - Sqrt[5])]*x - 2920*Sqrt[2*(5 + Sqrt[5])]*x - 
      1352*Sqrt[10*(5 + Sqrt[5])]*x + 9020*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      3608*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 20100*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      8040*Sqrt[10*(5 - Sqrt[5])]*x^2 - 540*Sqrt[2*(5 + Sqrt[5])]*x^2 - 
      204*Sqrt[10*(5 + Sqrt[5])]*x^2 - 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 + 240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 + 9580*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      3832*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 21420*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      8568*Sqrt[10*(5 - Sqrt[5])]*x*y + 440*Sqrt[2*(5 + Sqrt[5])]*x*y + 
      192*Sqrt[10*(5 + Sqrt[5])]*x*y - 4340*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y + 
      1736*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y - 9700*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y + 3880*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 1600*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y + 728*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 1960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y - 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 
      4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y + 
      345*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 138*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 775*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 
      310*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 1525*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 689*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 960*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 5360*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 
      2144*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 460*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 - 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     43120*Sqrt[2*(25 - 5*Sqrt[5])] - 17248*Sqrt[10*(25 - 5*Sqrt[5])] + 
      96400*Sqrt[2*(5 - Sqrt[5])] - 38560*Sqrt[10*(5 - Sqrt[5])] + 
      2000*Sqrt[2*(5 + Sqrt[5])] + 912*Sqrt[10*(5 + Sqrt[5])] - 
      17120*Sqrt[2*(25 - 5*Sqrt[5])]*x + 6848*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      38240*Sqrt[2*(5 - Sqrt[5])]*x + 15296*Sqrt[10*(5 - Sqrt[5])]*x + 
      5760*Sqrt[2*(5 + Sqrt[5])]*x + 2496*Sqrt[10*(5 + Sqrt[5])]*x - 
      20800*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 8320*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 46560*Sqrt[2*(5 - Sqrt[5])]*x^2 + 18624*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 2000*Sqrt[2*(5 + Sqrt[5])]*x^2 + 1072*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 + 160*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      12240*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 4896*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 27360*Sqrt[2*(5 - Sqrt[5])]*x*y + 10944*Sqrt[10*(5 - Sqrt[5])]*x*
       y - 3160*Sqrt[2*(5 + Sqrt[5])]*x*y - 1416*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      27680*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 11072*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 61920*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      24768*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 1760*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      864*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y - 
      80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 440*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 
      176*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 200*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 
      40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 10580*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 4232*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      23660*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 9464*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 100*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 52*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 + 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 2144*Sqrt[25 - 5*Sqrt[5]] + 
      4800*Sqrt[5 - Sqrt[5]] + 6320*Sqrt[5 + Sqrt[5]] + 
      2832*Sqrt[5*(5 + Sqrt[5])] + 10488*Sqrt[25 - 5*Sqrt[5]]*x + 
      23480*Sqrt[5 - Sqrt[5]]*x + 4080*Sqrt[5 + Sqrt[5]]*x + 
      1760*Sqrt[5*(5 + Sqrt[5])]*x + 464*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      1120*Sqrt[5 - Sqrt[5]]*x^2 - 120*Sqrt[5 + Sqrt[5]]*x^2 - 
      40*Sqrt[5*(5 + Sqrt[5])]*x^2 - 104*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      280*Sqrt[5 - Sqrt[5]]*x^3 + 280*Sqrt[5 + Sqrt[5]]*x^3 + 
      120*Sqrt[5*(5 + Sqrt[5])]*x^3 - 7448*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      16680*Sqrt[5 - Sqrt[5]]*x*y - 2280*Sqrt[5 + Sqrt[5]]*x*y - 
      1000*Sqrt[5*(5 + Sqrt[5])]*x*y + 192*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      400*Sqrt[5 - Sqrt[5]]*x^2*y + 440*Sqrt[5 + Sqrt[5]]*x^2*y + 
      200*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 312*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      720*Sqrt[5 - Sqrt[5]]*x^3*y - 500*Sqrt[5 + Sqrt[5]]*x^3*y - 
      220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 234*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      530*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 400*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      180*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      660*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 360*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      245*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 90*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, -48640*Sqrt[2*(25 - 5*Sqrt[5])] + 
      19456*Sqrt[10*(25 - 5*Sqrt[5])] - 108800*Sqrt[2*(5 - Sqrt[5])] + 
      43520*Sqrt[10*(5 - Sqrt[5])] + 27520*Sqrt[2*(5 + Sqrt[5])] + 
      12416*Sqrt[10*(5 + Sqrt[5])] + 96560*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      38624*Sqrt[10*(25 - 5*Sqrt[5])]*x + 216080*Sqrt[2*(5 - Sqrt[5])]*x - 
      86432*Sqrt[10*(5 - Sqrt[5])]*x + 19120*Sqrt[2*(5 + Sqrt[5])]*x + 
      8240*Sqrt[10*(5 + Sqrt[5])]*x - 81680*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      32672*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 182800*Sqrt[2*(5 - Sqrt[5])]*
       x^2 + 73120*Sqrt[10*(5 - Sqrt[5])]*x^2 - 800*Sqrt[2*(5 + Sqrt[5])]*
       x^2 - 1440*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      576*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 3200*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      1280*Sqrt[10*(5 - Sqrt[5])]*x^3 + 1200*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      400*Sqrt[10*(5 + Sqrt[5])]*x^3 - 43280*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      17312*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 96880*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      38752*Sqrt[10*(5 - Sqrt[5])]*x*y - 8560*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      3760*Sqrt[10*(5 + Sqrt[5])]*x*y + 167920*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y - 67168*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      375600*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 150240*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y - 160*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 10120*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y - 4048*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 
      22600*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 9040*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 
      2000*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 800*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      51740*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      20696*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 115700*Sqrt[2*(5 - Sqrt[5])]*
       x^2*y^2 + 46280*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 
      900*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 420*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y^2 - 11720*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      4688*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 26200*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 10480*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      1400*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 600*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 + 5390*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      2156*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 12050*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 - 4820*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 
      350*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 150*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -792*Sqrt[25 - 5*Sqrt[5]] - 1776*Sqrt[5 - Sqrt[5]] + 
      2596*Sqrt[5 + Sqrt[5]] + 1164*Sqrt[5*(5 + Sqrt[5])] + 
      236*Sqrt[25 - 5*Sqrt[5]]*x + 532*Sqrt[5 - Sqrt[5]]*x - 
      260*Sqrt[5 + Sqrt[5]]*x - 116*Sqrt[5*(5 + Sqrt[5])]*x - 
      292*Sqrt[25 - 5*Sqrt[5]]*x^2 - 660*Sqrt[5 - Sqrt[5]]*x^2 - 
      880*Sqrt[5 + Sqrt[5]]*x^2 - 392*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      134*Sqrt[25 - 5*Sqrt[5]]*x*y + 298*Sqrt[5 - Sqrt[5]]*x*y + 
      470*Sqrt[5 + Sqrt[5]]*x*y + 206*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      712*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 1600*Sqrt[5 - Sqrt[5]]*x^2*y + 
      540*Sqrt[5 + Sqrt[5]]*x^2*y + 244*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      275*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 615*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      220*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 98*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 
     74640*Sqrt[2*(25 - 5*Sqrt[5])] - 29856*Sqrt[10*(25 - 5*Sqrt[5])] + 
      166800*Sqrt[2*(5 - Sqrt[5])] - 66720*Sqrt[10*(5 - Sqrt[5])] - 
      4640*Sqrt[2*(5 + Sqrt[5])] - 1984*Sqrt[10*(5 + Sqrt[5])] - 
      103360*Sqrt[2*(25 - 5*Sqrt[5])]*x + 41344*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      230720*Sqrt[2*(5 - Sqrt[5])]*x + 92288*Sqrt[10*(5 - Sqrt[5])]*x + 
      6720*Sqrt[2*(5 + Sqrt[5])]*x + 2880*Sqrt[10*(5 + Sqrt[5])]*x + 
      19520*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 7808*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 + 43200*Sqrt[2*(5 - Sqrt[5])]*x^2 - 17280*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 1280*Sqrt[2*(5 + Sqrt[5])]*x^2 + 640*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 1680*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      672*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 3600*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      1440*Sqrt[10*(5 - Sqrt[5])]*x^3 + 800*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 + 103600*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      41440*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 231520*Sqrt[2*(5 - Sqrt[5])]*x*
       y - 92608*Sqrt[10*(5 - Sqrt[5])]*x*y - 8280*Sqrt[2*(5 + Sqrt[5])]*x*
       y - 3720*Sqrt[10*(5 + Sqrt[5])]*x*y - 21360*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y + 8544*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y - 
      47600*Sqrt[2*(5 - Sqrt[5])]*x^2*y + 19040*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 3840*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 1760*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y + 7640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y - 
      3056*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 17000*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 6800*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 1400*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 600*Sqrt[10*(5 + Sqrt[5])]*x^3*y + 15340*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 6136*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      34300*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 13720*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 6320*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 2840*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 8240*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      3296*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 18400*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 7360*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      1000*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 440*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 + 3580*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      1432*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 8000*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^3 - 3200*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 250*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^3 - 110*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -1480*Sqrt[25 - 5*Sqrt[5]] - 3400*Sqrt[5 - Sqrt[5]] + 
      5200*Sqrt[5 + Sqrt[5]] + 2368*Sqrt[5*(5 + Sqrt[5])] - 
      4656*Sqrt[25 - 5*Sqrt[5]]*x - 10160*Sqrt[5 - Sqrt[5]]*x + 
      4800*Sqrt[5 + Sqrt[5]]*x + 2080*Sqrt[5*(5 + Sqrt[5])]*x - 
      1440*Sqrt[25 - 5*Sqrt[5]]*x^2 - 3600*Sqrt[5 - Sqrt[5]]*x^2 + 
      1480*Sqrt[5 + Sqrt[5]]*x^2 + 760*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      40*Sqrt[25 - 5*Sqrt[5]]*x^3 + 280*Sqrt[5 - Sqrt[5]]*x^3 + 
      40*(5 + Sqrt[5])^(3/2)*x^3 + 2396*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      5340*Sqrt[5 - Sqrt[5]]*x*y - 2520*Sqrt[5 + Sqrt[5]]*x*y - 
      1120*Sqrt[5*(5 + Sqrt[5])]*x*y + 3160*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      7160*Sqrt[5 - Sqrt[5]]*x^2*y - 1360*Sqrt[5 + Sqrt[5]]*x^2*y - 
      640*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 120*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      160*Sqrt[5 - Sqrt[5]]*x^3*y - 300*Sqrt[5 + Sqrt[5]]*x^3*y - 
      100*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 1610*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      3610*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 180*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      80*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 220*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      460*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 200*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      80*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 135*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      295*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 50*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      20*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 572*Sqrt[2*(25 - 5*Sqrt[5])] + 
      1260*Sqrt[2*(5 - Sqrt[5])] + 8*Sqrt[10*(5 + Sqrt[5])] + 
      1076*Sqrt[2*(25 - 5*Sqrt[5])]*x + 1940*Sqrt[2*(5 - Sqrt[5])]*x - 
      120*Sqrt[2*(5 + Sqrt[5])]*x + 240*Sqrt[10*(5 + Sqrt[5])]*x + 
      240*Sqrt[2*(5 - Sqrt[5])]*x^2 + 200*Sqrt[2*(5 + Sqrt[5])]*x^2 - 
      40*Sqrt[10*(5 + Sqrt[5])]*x^2 - 806*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      1710*Sqrt[2*(5 - Sqrt[5])]*x*y - 40*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      60*Sqrt[10*(5 + Sqrt[5])]*x*y - 60*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      180*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 20*Sqrt[2]*(5 + Sqrt[5])^(3/2)*x^2*
       y + 30*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 90*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 + 10*Sqrt[2]*(5 + Sqrt[5])^(3/2)*x^2*y^2, 
     -3456*Sqrt[25 - 5*Sqrt[5]] - 7840*Sqrt[5 - Sqrt[5]] + 
      25520*Sqrt[5 + Sqrt[5]] + 11472*Sqrt[5*(5 + Sqrt[5])] + 
      760*Sqrt[25 - 5*Sqrt[5]]*x + 2040*Sqrt[5 - Sqrt[5]]*x + 
      10320*Sqrt[5 + Sqrt[5]]*x + 4480*Sqrt[5*(5 + Sqrt[5])]*x - 
      3360*Sqrt[25 - 5*Sqrt[5]]*x^2 - 7920*Sqrt[5 - Sqrt[5]]*x^2 - 
      3400*Sqrt[5 + Sqrt[5]]*x^2 - 1400*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      40*Sqrt[25 - 5*Sqrt[5]]*x^3 + 280*Sqrt[5 - Sqrt[5]]*x^3 + 
      40*(5 + Sqrt[5])^(3/2)*x^3 + 3440*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      7680*Sqrt[5 - Sqrt[5]]*x*y - 2760*Sqrt[5 + Sqrt[5]]*x*y - 
      1240*Sqrt[5*(5 + Sqrt[5])]*x*y + 9200*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      20640*Sqrt[5 - Sqrt[5]]*x^2*y + 1000*Sqrt[5 + Sqrt[5]]*x^2*y + 
      440*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 120*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      160*Sqrt[5 - Sqrt[5]]*x^3*y - 300*Sqrt[5 + Sqrt[5]]*x^3*y - 
      100*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 3790*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      8470*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 2200*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      980*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 220*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      460*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 200*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      80*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 135*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      295*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 50*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      20*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, -3312*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 
      1656*Sqrt[2*(25 - 5*Sqrt[5])] - 7408*Sqrt[(2*(5 - Sqrt[5]))/5] + 
      3704*Sqrt[2*(5 - Sqrt[5])] - 544*Sqrt[(2*(5 + Sqrt[5]))/5] + 
      16*Sqrt[2*(5 + Sqrt[5])] + 128*Sqrt[10*(5 + Sqrt[5])] - 
      1160*Sqrt[2*(25 - 5*Sqrt[5])]*x + 464*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      2600*Sqrt[2*(5 - Sqrt[5])]*x + 1040*Sqrt[10*(5 - Sqrt[5])]*x - 
      32*Sqrt[2*(5 + Sqrt[5])]*x - 48*Sqrt[10*(5 + Sqrt[5])]*x - 
      352*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 + 176*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2 + 400*Sqrt[2*(5 - Sqrt[5])]*x^2 - 160*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      80*Sqrt[2*(5 + Sqrt[5])]*x^2 - 16*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      3128*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x*y + 1564*Sqrt[2*(25 - 5*Sqrt[5])]*x*
       y + 3500*Sqrt[2*(5 - Sqrt[5])]*x*y - 1400*Sqrt[10*(5 - Sqrt[5])]*x*y + 
      16*Sqrt[2*(5 + Sqrt[5])]*x*y + 8*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      464*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2*y - 232*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y - 520*Sqrt[2*(5 - Sqrt[5])]*x^2*y + 208*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y + 80*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 32*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y - 232*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2*y^2 + 
      116*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 260*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 - 104*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 40*Sqrt[2*(5 + Sqrt[5])]*
       x^2*y^2 - 16*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2, 
     96960*Sqrt[2*(25 - 5*Sqrt[5])] - 38784*Sqrt[10*(25 - 5*Sqrt[5])] + 
      216800*Sqrt[2*(5 - Sqrt[5])] - 86720*Sqrt[10*(5 - Sqrt[5])] - 
      80*Sqrt[2*(5 + Sqrt[5])] + 80*Sqrt[10*(5 + Sqrt[5])] - 
      39680*Sqrt[2*(25 - 5*Sqrt[5])]*x + 15872*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      88800*Sqrt[2*(5 - Sqrt[5])]*x + 35520*Sqrt[10*(5 - Sqrt[5])]*x - 
      8720*Sqrt[2*(5 + Sqrt[5])]*x - 4080*Sqrt[10*(5 + Sqrt[5])]*x + 
      22880*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 9152*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 + 51200*Sqrt[2*(5 - Sqrt[5])]*x^2 - 20480*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 3920*Sqrt[2*(5 + Sqrt[5])]*x^2 - 1520*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 1440*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      576*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 3200*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      1280*Sqrt[10*(5 - Sqrt[5])]*x^3 + 1200*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      400*Sqrt[10*(5 + Sqrt[5])]*x^3 + 40520*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      16208*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 90600*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      36240*Sqrt[10*(5 - Sqrt[5])]*x*y - 160*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      80*Sqrt[10*(5 + Sqrt[5])]*x*y - 2880*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      1280*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 8640*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      3840*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 10120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 4048*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 22600*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y - 9040*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 2000*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y - 800*Sqrt[10*(5 + Sqrt[5])]*x^3*y + 
      3480*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 1392*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 7800*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 
      3120*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 7120*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 3200*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      11720*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 4688*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 26200*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 
      10480*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 1400*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 600*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      5390*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 2156*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 12050*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      4820*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 350*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 - 150*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, -44*Sqrt[25 - 5*Sqrt[5]] + 
      124*Sqrt[5 - Sqrt[5]] - 84*Sqrt[5 + Sqrt[5]] + 
      44*Sqrt[5*(5 + Sqrt[5])] + 384*Sqrt[25 - 5*Sqrt[5]]*x - 
      816*Sqrt[5 - Sqrt[5]]*x - 584*Sqrt[5 + Sqrt[5]]*x + 
      264*Sqrt[5*(5 + Sqrt[5])]*x - 140*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      316*Sqrt[5 - Sqrt[5]]*x^2 + 44*Sqrt[5 + Sqrt[5]]*x^2 - 
      20*Sqrt[5*(5 + Sqrt[5])]*x^2 - 64*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      96*Sqrt[5 - Sqrt[5]]*x*y + 176*Sqrt[5 + Sqrt[5]]*x*y - 
      80*Sqrt[5*(5 + Sqrt[5])]*x*y - 52*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      108*Sqrt[5 - Sqrt[5]]*x^2*y + 72*Sqrt[5 + Sqrt[5]]*x^2*y - 
      32*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 19*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      39*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 11*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      5*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 11280*Sqrt[2*(25 - 5*Sqrt[5])] - 
      4512*Sqrt[10*(25 - 5*Sqrt[5])] + 25200*Sqrt[2*(5 - Sqrt[5])] - 
      10080*Sqrt[10*(5 - Sqrt[5])] + 6640*Sqrt[2*(5 + Sqrt[5])] + 
      2992*Sqrt[10*(5 + Sqrt[5])] - 75328*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x + 
      37664*Sqrt[2*(25 - 5*Sqrt[5])]*x + 84320*Sqrt[2*(5 - Sqrt[5])]*x - 
      33728*Sqrt[10*(5 - Sqrt[5])]*x + 6816*Sqrt[2*(5 + Sqrt[5])]*x + 
      2976*Sqrt[10*(5 + Sqrt[5])]*x + 18944*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*
       x^2 - 9472*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 21280*Sqrt[2*(5 - Sqrt[5])]*
       x^2 + 8512*Sqrt[10*(5 - Sqrt[5])]*x^2 + 1296*Sqrt[2*(5 + Sqrt[5])]*
       x^2 + 624*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      672*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 - 336*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3 - 720*Sqrt[2*(5 - Sqrt[5])]*x^3 + 288*Sqrt[10*(5 - Sqrt[5])]*x^3 + 
      160*Sqrt[2*(5 + Sqrt[5])]*x^3 + 64*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      49056*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x*y - 24528*Sqrt[2*(25 - 5*Sqrt[5])]*
       x*y - 54880*Sqrt[2*(5 - Sqrt[5])]*x*y + 21952*Sqrt[10*(5 - Sqrt[5])]*x*
       y - 3352*Sqrt[2*(5 + Sqrt[5])]*x*y - 1480*Sqrt[10*(5 + Sqrt[5])]*x*y - 
      39168*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2*y + 
      19584*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y + 43840*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 17536*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 1312*Sqrt[2*(5 + Sqrt[5])]*
       x^2*y - 608*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 
      3056*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3*y + 1528*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y + 3400*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 1360*Sqrt[10*(5 - Sqrt[5])]*
       x^3*y - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 120*Sqrt[10*(5 + Sqrt[5])]*
       x^3*y + 10744*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2*y^2 - 
      5372*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 12020*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 + 4808*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 356*Sqrt[2*(5 + Sqrt[5])]*
       x^2*y^2 + 164*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      3296*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3*y^2 - 
      1648*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 3680*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 + 1472*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 200*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 + 88*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1432*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3*y^3 + 
      716*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 1600*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^3 - 640*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 50*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^3 - 22*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -248*Sqrt[25 - 5*Sqrt[5]] - 520*Sqrt[5 - Sqrt[5]] + 
      2280*Sqrt[5 + Sqrt[5]] + 1032*Sqrt[5*(5 + Sqrt[5])] + 
      4888*Sqrt[25 - 5*Sqrt[5]]*x + 10840*Sqrt[5 - Sqrt[5]]*x - 
      2480*Sqrt[5 + Sqrt[5]]*x - 1152*Sqrt[5*(5 + Sqrt[5])]*x + 
      1032*Sqrt[25 - 5*Sqrt[5]]*x^2 + 2440*Sqrt[5 - Sqrt[5]]*x^2 - 
      2320*Sqrt[5 + Sqrt[5]]*x^2 - 1024*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      104*Sqrt[25 - 5*Sqrt[5]]*x^3 - 280*Sqrt[5 - Sqrt[5]]*x^3 + 
      280*Sqrt[5 + Sqrt[5]]*x^3 + 120*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      2928*Sqrt[25 - 5*Sqrt[5]]*x*y - 6560*Sqrt[5 - Sqrt[5]]*x*y + 
      680*Sqrt[5 + Sqrt[5]]*x*y + 312*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      704*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 1600*Sqrt[5 - Sqrt[5]]*x^2*y + 
      2960*Sqrt[5 + Sqrt[5]]*x^2*y + 1328*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      312*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 720*Sqrt[5 - Sqrt[5]]*x^3*y - 
      500*Sqrt[5 + Sqrt[5]]*x^3*y - 220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      472*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 1060*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      1370*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 614*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 660*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 
      360*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 245*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 
      90*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -88160*Sqrt[2*(25 - 5*Sqrt[5])] + 35264*Sqrt[10*(25 - 5*Sqrt[5])] - 
      197280*Sqrt[2*(5 - Sqrt[5])] + 78912*Sqrt[10*(5 - Sqrt[5])] + 
      17120*Sqrt[2*(5 + Sqrt[5])] + 7776*Sqrt[10*(5 + Sqrt[5])] + 
      97120*Sqrt[2*(25 - 5*Sqrt[5])]*x - 38848*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      217760*Sqrt[2*(5 - Sqrt[5])]*x - 87104*Sqrt[10*(5 - Sqrt[5])]*x + 
      1440*Sqrt[2*(5 + Sqrt[5])]*x + 160*Sqrt[10*(5 + Sqrt[5])]*x - 
      73600*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 29440*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 165120*Sqrt[2*(5 - Sqrt[5])]*x^2 + 66048*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 7360*Sqrt[2*(5 + Sqrt[5])]*x^2 - 2880*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 256*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3 - 1280*Sqrt[2*(5 - Sqrt[5])]*x^3 + 512*Sqrt[10*(5 - Sqrt[5])]*
       x^3 + 960*Sqrt[2*(5 + Sqrt[5])]*x^3 + 320*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      87680*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 35072*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 196160*Sqrt[2*(5 - Sqrt[5])]*x*y + 78464*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 1280*Sqrt[2*(5 + Sqrt[5])]*x*y + 640*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      146000*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 58400*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 326640*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      130656*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 5520*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y + 2320*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 7840*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y - 3136*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 
      17440*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 
      1600*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      46200*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      18480*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 103320*Sqrt[2*(5 - Sqrt[5])]*
       x^2*y^2 + 41328*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 
      480*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 240*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y^2 - 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 + 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 - 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -98320*Sqrt[2*(25 - 5*Sqrt[5])] + 39328*Sqrt[10*(25 - 5*Sqrt[5])] - 
      219920*Sqrt[2*(5 - Sqrt[5])] + 87968*Sqrt[10*(5 - Sqrt[5])] + 
      18720*Sqrt[2*(5 + Sqrt[5])] + 8384*Sqrt[10*(5 + Sqrt[5])] + 
      18480*Sqrt[2*(25 - 5*Sqrt[5])]*x - 7392*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      41520*Sqrt[2*(5 - Sqrt[5])]*x - 16608*Sqrt[10*(5 - Sqrt[5])]*x + 
      8480*Sqrt[2*(5 + Sqrt[5])]*x + 3904*Sqrt[10*(5 + Sqrt[5])]*x - 
      6880*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 2752*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 15680*Sqrt[2*(5 - Sqrt[5])]*x^2 + 6272*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 3600*Sqrt[2*(5 + Sqrt[5])]*x^2 - 1712*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3 + 1920*Sqrt[2*(5 - Sqrt[5])]*x^3 - 768*Sqrt[10*(5 - Sqrt[5])]*
       x^3 - 240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      53600*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 21440*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 119920*Sqrt[2*(5 - Sqrt[5])]*x*y + 47968*Sqrt[10*(5 - Sqrt[5])]*x*
       y - 2040*Sqrt[2*(5 + Sqrt[5])]*x*y - 904*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      15040*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 6016*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 33760*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      13504*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 1360*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      624*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 5160*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y + 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 400*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      7360*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 2944*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 16480*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      6592*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 2080*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 928*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 848*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 37720*Sqrt[2*(25 - 5*Sqrt[5])] - 
      15088*Sqrt[10*(25 - 5*Sqrt[5])] + 84320*Sqrt[2*(5 - Sqrt[5])] - 
      33728*Sqrt[10*(5 - Sqrt[5])] - 3460*Sqrt[2*(5 + Sqrt[5])] - 
      1516*Sqrt[10*(5 + Sqrt[5])] + 22760*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      9104*Sqrt[10*(25 - 5*Sqrt[5])]*x + 50960*Sqrt[2*(5 - Sqrt[5])]*x - 
      20384*Sqrt[10*(5 - Sqrt[5])]*x - 980*Sqrt[2*(5 + Sqrt[5])]*x - 
      508*Sqrt[10*(5 + Sqrt[5])]*x + 5680*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      2272*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 12640*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      5056*Sqrt[10*(5 - Sqrt[5])]*x^2 + 680*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      344*Sqrt[10*(5 + Sqrt[5])]*x^2 - 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 + 240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 + 1540*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      616*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 3440*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      1376*Sqrt[10*(5 - Sqrt[5])]*x*y - 270*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      122*Sqrt[10*(5 + Sqrt[5])]*x*y + 4080*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      1632*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 9120*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 3648*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 120*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y + 72*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 1960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y - 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 
      4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      3160*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 1264*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 7060*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      2824*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 890*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 406*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 960*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 5360*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 
      2144*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 460*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 - 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     80400*Sqrt[2*(25 - 5*Sqrt[5])] - 32160*Sqrt[10*(25 - 5*Sqrt[5])] + 
      179760*Sqrt[2*(5 - Sqrt[5])] - 71904*Sqrt[10*(5 - Sqrt[5])] - 
      5360*Sqrt[2*(5 + Sqrt[5])] - 2416*Sqrt[10*(5 + Sqrt[5])] - 
      82880*Sqrt[2*(25 - 5*Sqrt[5])]*x + 33152*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      185280*Sqrt[2*(5 - Sqrt[5])]*x + 74112*Sqrt[10*(5 - Sqrt[5])]*x + 
      6080*Sqrt[2*(5 + Sqrt[5])]*x + 2752*Sqrt[10*(5 + Sqrt[5])]*x - 
      27520*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 11008*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 61600*Sqrt[2*(5 - Sqrt[5])]*x^2 + 24640*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 3280*Sqrt[2*(5 + Sqrt[5])]*x^2 + 1584*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 + 160*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      101280*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 40512*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 226480*Sqrt[2*(5 - Sqrt[5])]*x*y - 90592*Sqrt[10*(5 - Sqrt[5])]*x*
       y - 3880*Sqrt[2*(5 + Sqrt[5])]*x*y - 1752*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      50080*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 20032*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 112000*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      44800*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 2480*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      1168*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 16860*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 6744*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      37700*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 15080*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 260*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 116*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 + 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 35280*Sqrt[2*(25 - 5*Sqrt[5])] - 
      14112*Sqrt[10*(25 - 5*Sqrt[5])] + 78800*Sqrt[2*(5 - Sqrt[5])] - 
      31520*Sqrt[10*(5 - Sqrt[5])] - 800*Sqrt[2*(5 + Sqrt[5])] - 
      320*Sqrt[10*(5 + Sqrt[5])] - 25680*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      10272*Sqrt[10*(25 - 5*Sqrt[5])]*x - 57040*Sqrt[2*(5 - Sqrt[5])]*x + 
      22816*Sqrt[10*(5 - Sqrt[5])]*x + 1760*Sqrt[2*(5 + Sqrt[5])]*x + 
      640*Sqrt[10*(5 + Sqrt[5])]*x - 3200*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      1280*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 7520*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      3008*Sqrt[10*(5 - Sqrt[5])]*x^2 + 880*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      400*Sqrt[10*(5 + Sqrt[5])]*x^2 + 800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      320*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 1920*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      768*Sqrt[10*(5 - Sqrt[5])]*x^3 - 240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 + 27680*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      11072*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 61840*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      24736*Sqrt[10*(5 - Sqrt[5])]*x*y - 440*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      200*Sqrt[10*(5 + Sqrt[5])]*x*y + 2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      960*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 5440*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 2176*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 1360*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y - 560*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 2280*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y + 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 
      5160*Sqrt[2*(5 - Sqrt[5])]*x^3*y + 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      2200*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 880*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 4920*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      1968*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 720*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 320*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 848*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 2000*Sqrt[2*(25 - 5*Sqrt[5])] - 
      800*Sqrt[10*(25 - 5*Sqrt[5])] + 4440*Sqrt[2*(5 - Sqrt[5])] - 
      1776*Sqrt[10*(5 - Sqrt[5])] + 780*Sqrt[2*(5 + Sqrt[5])] + 
      372*Sqrt[10*(5 + Sqrt[5])] + 23680*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      9472*Sqrt[10*(25 - 5*Sqrt[5])]*x + 53080*Sqrt[2*(5 - Sqrt[5])]*x - 
      21232*Sqrt[10*(5 - Sqrt[5])]*x + 580*Sqrt[2*(5 + Sqrt[5])]*x + 
      156*Sqrt[10*(5 + Sqrt[5])]*x - 16720*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      6688*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 37520*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      15008*Sqrt[10*(5 - Sqrt[5])]*x^2 - 160*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      32*Sqrt[10*(5 + Sqrt[5])]*x^2 - 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 + 240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 19120*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      7648*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 42780*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      17112*Sqrt[10*(5 - Sqrt[5])]*x*y - 250*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      86*Sqrt[10*(5 + Sqrt[5])]*x*y + 30760*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      12304*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 68840*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 27536*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 160*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y + 16*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 1960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y - 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 
      4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      9440*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 3776*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 21120*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      8448*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 40*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 8*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 2400*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 960*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      5360*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 2144*Sqrt[10*(5 - Sqrt[5])]*x^3*
       y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*
       x^3*y^2 + 1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      460*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^3 - 1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^3 - 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -195600*Sqrt[2*(25 - 5*Sqrt[5])] + 78240*Sqrt[10*(25 - 5*Sqrt[5])] - 
      437360*Sqrt[2*(5 - Sqrt[5])] + 174944*Sqrt[10*(5 - Sqrt[5])] + 
      32400*Sqrt[2*(5 + Sqrt[5])] + 14544*Sqrt[10*(5 + Sqrt[5])] + 
      51840*Sqrt[2*(25 - 5*Sqrt[5])]*x - 20736*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      115840*Sqrt[2*(5 - Sqrt[5])]*x - 46336*Sqrt[10*(5 - Sqrt[5])]*x + 
      4160*Sqrt[2*(5 + Sqrt[5])]*x + 1728*Sqrt[10*(5 + Sqrt[5])]*x - 
      35360*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 14144*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 79040*Sqrt[2*(5 - Sqrt[5])]*x^2 + 31616*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 10800*Sqrt[2*(5 + Sqrt[5])]*x^2 - 4624*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 + 160*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      83840*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 33536*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 187440*Sqrt[2*(5 - Sqrt[5])]*x*y + 74976*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 2360*Sqrt[2*(5 + Sqrt[5])]*x*y + 1032*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      86080*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 34432*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 192480*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      76992*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 6320*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      2768*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 36020*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 14408*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      80540*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 32216*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 3020*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 1356*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 + 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 952*Sqrt[25 - 5*Sqrt[5]] + 
      2120*Sqrt[5 - Sqrt[5]] + 1880*Sqrt[5 + Sqrt[5]] + 
      824*Sqrt[5*(5 + Sqrt[5])] - 1784*Sqrt[25 - 5*Sqrt[5]]*x - 
      3960*Sqrt[5 - Sqrt[5]]*x + 8720*Sqrt[5 + Sqrt[5]]*x + 
      3936*Sqrt[5*(5 + Sqrt[5])]*x - 920*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      2040*Sqrt[5 - Sqrt[5]]*x^2 + 3840*Sqrt[5 + Sqrt[5]]*x^2 + 
      1712*Sqrt[5*(5 + Sqrt[5])]*x^2 - 104*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      280*Sqrt[5 - Sqrt[5]]*x^3 + 280*Sqrt[5 + Sqrt[5]]*x^3 + 
      120*Sqrt[5*(5 + Sqrt[5])]*x^3 + 1464*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      3240*Sqrt[5 - Sqrt[5]]*x*y - 5880*Sqrt[5 + Sqrt[5]]*x*y - 
      2616*Sqrt[5*(5 + Sqrt[5])]*x*y + 640*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      1440*Sqrt[5 - Sqrt[5]]*x^2*y - 2240*Sqrt[5 + Sqrt[5]]*x^2*y - 
      1024*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 312*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      720*Sqrt[5 - Sqrt[5]]*x^3*y - 500*Sqrt[5 + Sqrt[5]]*x^3*y - 
      220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 400*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      900*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 1030*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      458*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      660*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 360*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      245*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 90*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 139360*Sqrt[2*(25 - 5*Sqrt[5])] - 
      55744*Sqrt[10*(25 - 5*Sqrt[5])] + 311520*Sqrt[2*(5 - Sqrt[5])] - 
      124608*Sqrt[10*(5 - Sqrt[5])] - 12160*Sqrt[2*(5 + Sqrt[5])] - 
      5312*Sqrt[10*(5 + Sqrt[5])] + 20000*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      8000*Sqrt[10*(25 - 5*Sqrt[5])]*x + 44960*Sqrt[2*(5 - Sqrt[5])]*x - 
      17984*Sqrt[10*(5 - Sqrt[5])]*x - 2560*Sqrt[2*(5 + Sqrt[5])]*x - 
      1344*Sqrt[10*(5 + Sqrt[5])]*x - 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 21760*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      8704*Sqrt[10*(5 - Sqrt[5])]*x^2 + 2880*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      1472*Sqrt[10*(5 + Sqrt[5])]*x^2 - 640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      256*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 1280*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      512*Sqrt[10*(5 - Sqrt[5])]*x^3 + 960*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 + 70080*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      28032*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 156640*Sqrt[2*(5 - Sqrt[5])]*x*
       y - 62656*Sqrt[10*(5 - Sqrt[5])]*x*y - 1520*Sqrt[2*(5 + Sqrt[5])]*x*
       y - 656*Sqrt[10*(5 + Sqrt[5])]*x*y + 57520*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y - 23008*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      128720*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 51488*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 80*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 16*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 
      7840*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y - 3136*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y + 17440*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 
      6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 1600*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 
      640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 22520*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 9008*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      50360*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 20144*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 3120*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 1408*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 + 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 - 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     85760*Sqrt[2*(25 - 5*Sqrt[5])] - 34304*Sqrt[10*(25 - 5*Sqrt[5])] + 
      191680*Sqrt[2*(5 - Sqrt[5])] - 76672*Sqrt[10*(5 - Sqrt[5])] + 
      160*Sqrt[2*(5 + Sqrt[5])] + 96*Sqrt[10*(5 + Sqrt[5])] - 
      84640*Sqrt[2*(25 - 5*Sqrt[5])]*x + 33856*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      188960*Sqrt[2*(5 - Sqrt[5])]*x + 75584*Sqrt[10*(5 - Sqrt[5])]*x + 
      320*Sqrt[2*(5 + Sqrt[5])]*x + 128*Sqrt[10*(5 + Sqrt[5])]*x - 
      1920*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 768*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 
      4640*Sqrt[2*(5 - Sqrt[5])]*x^2 + 1856*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      240*Sqrt[2*(5 + Sqrt[5])]*x^2 - 144*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 
      1920*Sqrt[2*(5 - Sqrt[5])]*x^3 - 768*Sqrt[10*(5 - Sqrt[5])]*x^3 - 
      240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 80*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      107160*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 42864*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 239560*Sqrt[2*(5 - Sqrt[5])]*x*y - 95824*Sqrt[10*(5 - Sqrt[5])]*x*
       y - 360*Sqrt[2*(5 + Sqrt[5])]*x*y - 168*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      3920*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 1568*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 8880*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 3552*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y + 400*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 208*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y - 2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 
      912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 5160*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 400*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 1800*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 720*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      4040*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 1616*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 320*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 144*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      848*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, -4440*Sqrt[2*(25 - 5*Sqrt[5])] + 
      1776*Sqrt[10*(25 - 5*Sqrt[5])] - 9960*Sqrt[2*(5 - Sqrt[5])] + 
      3984*Sqrt[10*(5 - Sqrt[5])] + 2200*Sqrt[2*(5 + Sqrt[5])] + 
      1016*Sqrt[10*(5 + Sqrt[5])] + 11160*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      4464*Sqrt[10*(25 - 5*Sqrt[5])]*x + 25080*Sqrt[2*(5 - Sqrt[5])]*x - 
      10032*Sqrt[10*(5 - Sqrt[5])]*x - 320*Sqrt[2*(5 + Sqrt[5])]*x - 
      272*Sqrt[10*(5 + Sqrt[5])]*x - 16400*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      6560*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 36800*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      14720*Sqrt[10*(5 - Sqrt[5])]*x^2 - 680*Sqrt[2*(5 + Sqrt[5])]*x^2 - 
      184*Sqrt[10*(5 + Sqrt[5])]*x^2 - 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 + 240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 14740*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      5896*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 32980*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      13192*Sqrt[10*(5 - Sqrt[5])]*x*y + 200*Sqrt[2*(5 + Sqrt[5])]*x*y + 
      112*Sqrt[10*(5 + Sqrt[5])]*x*y + 28240*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      11296*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 63200*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 25280*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 680*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y + 248*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 1960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y - 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 
      4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      8940*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 3576*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 20000*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      8000*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 190*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 74*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 960*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 5360*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 
      2144*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 460*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 - 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -159200*Sqrt[2*(25 - 5*Sqrt[5])] + 63680*Sqrt[10*(25 - 5*Sqrt[5])] - 
      356000*Sqrt[2*(5 - Sqrt[5])] + 142400*Sqrt[10*(5 - Sqrt[5])] + 
      31520*Sqrt[2*(5 + Sqrt[5])] + 14112*Sqrt[10*(5 + Sqrt[5])] + 
      94320*Sqrt[2*(25 - 5*Sqrt[5])]*x - 37728*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      210960*Sqrt[2*(5 - Sqrt[5])]*x - 84384*Sqrt[10*(5 - Sqrt[5])]*x + 
      4560*Sqrt[2*(5 + Sqrt[5])]*x + 1936*Sqrt[10*(5 + Sqrt[5])]*x - 
      32960*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 13184*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 73760*Sqrt[2*(5 - Sqrt[5])]*x^2 + 29504*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 11280*Sqrt[2*(5 + Sqrt[5])]*x^2 - 4848*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 + 160*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      149000*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 59600*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 333160*Sqrt[2*(5 - Sqrt[5])]*x*y + 133264*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 1760*Sqrt[2*(5 + Sqrt[5])]*x*y + 784*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      69360*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 27744*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 155120*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      62048*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 7200*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      3136*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 26500*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 10600*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      59260*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 23704*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 2420*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 1092*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 + 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 784*Sqrt[25 - 5*Sqrt[5]] + 
      1760*Sqrt[5 - Sqrt[5]] + 8200*Sqrt[5 + Sqrt[5]] + 
      3672*Sqrt[5*(5 + Sqrt[5])] + 2288*Sqrt[25 - 5*Sqrt[5]]*x + 
      5040*Sqrt[5 - Sqrt[5]]*x + 12480*Sqrt[5 + Sqrt[5]]*x + 
      5600*Sqrt[5*(5 + Sqrt[5])]*x - 776*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      1640*Sqrt[5 - Sqrt[5]]*x^2 + 4480*Sqrt[5 + Sqrt[5]]*x^2 + 
      2000*Sqrt[5*(5 + Sqrt[5])]*x^2 - 104*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      280*Sqrt[5 - Sqrt[5]]*x^3 + 280*Sqrt[5 + Sqrt[5]]*x^3 + 
      120*Sqrt[5*(5 + Sqrt[5])]*x^3 - 1748*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      3940*Sqrt[5 - Sqrt[5]]*x*y - 7280*Sqrt[5 + Sqrt[5]]*x*y - 
      3240*Sqrt[5*(5 + Sqrt[5])]*x*y + 872*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      1960*Sqrt[5 - Sqrt[5]]*x^2*y - 3360*Sqrt[5 + Sqrt[5]]*x^2*y - 
      1520*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 312*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      720*Sqrt[5 - Sqrt[5]]*x^3*y - 500*Sqrt[5 + Sqrt[5]]*x^3*y - 
      220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 124*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      280*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 250*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      110*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      660*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 360*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      245*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 90*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 214720*Sqrt[2*(25 - 5*Sqrt[5])] - 
      85888*Sqrt[10*(25 - 5*Sqrt[5])] + 480000*Sqrt[2*(5 - Sqrt[5])] - 
      192000*Sqrt[10*(5 - Sqrt[5])] - 8480*Sqrt[2*(5 + Sqrt[5])] - 
      3680*Sqrt[10*(5 + Sqrt[5])] + 36480*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      14592*Sqrt[10*(25 - 5*Sqrt[5])]*x + 81920*Sqrt[2*(5 - Sqrt[5])]*x - 
      32768*Sqrt[10*(5 - Sqrt[5])]*x + 3520*Sqrt[2*(5 + Sqrt[5])]*x + 
      1344*Sqrt[10*(5 + Sqrt[5])]*x - 17600*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      7040*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 39680*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      15872*Sqrt[10*(5 - Sqrt[5])]*x^2 + 5280*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      2528*Sqrt[10*(5 + Sqrt[5])]*x^2 - 640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      256*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 1280*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      512*Sqrt[10*(5 - Sqrt[5])]*x^3 + 960*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 + 102560*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      41024*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 229280*Sqrt[2*(5 - Sqrt[5])]*x*
       y - 91712*Sqrt[10*(5 - Sqrt[5])]*x*y - 4480*Sqrt[2*(5 + Sqrt[5])]*x*
       y - 1984*Sqrt[10*(5 + Sqrt[5])]*x*y + 78400*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y - 31360*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      175360*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 70144*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y - 2400*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 1056*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y + 7840*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y - 
      3136*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 17440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 1600*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 29200*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 11680*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      65280*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 26112*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 2440*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 1112*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 + 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 - 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     131520*Sqrt[2*(25 - 5*Sqrt[5])] - 52608*Sqrt[10*(25 - 5*Sqrt[5])] + 
      294080*Sqrt[2*(5 - Sqrt[5])] - 117632*Sqrt[10*(5 - Sqrt[5])] - 
      640*Sqrt[2*(5 + Sqrt[5])] - 256*Sqrt[10*(5 + Sqrt[5])] - 
      85520*Sqrt[2*(25 - 5*Sqrt[5])]*x + 34208*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      191280*Sqrt[2*(5 - Sqrt[5])]*x + 76512*Sqrt[10*(5 - Sqrt[5])]*x + 
      5040*Sqrt[2*(5 + Sqrt[5])]*x + 2224*Sqrt[10*(5 + Sqrt[5])]*x - 
      29920*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 11968*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 66880*Sqrt[2*(5 - Sqrt[5])]*x^2 + 26752*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 3760*Sqrt[2*(5 + Sqrt[5])]*x^2 + 1808*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 + 160*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      153240*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 61296*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 342680*Sqrt[2*(5 - Sqrt[5])]*x*y - 137072*Sqrt[10*(5 - Sqrt[5])]*x*
       y - 2960*Sqrt[2*(5 + Sqrt[5])]*x*y - 1344*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      66800*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 26720*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 149360*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      59744*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 3360*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      1536*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 26380*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 10552*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      58980*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 23592*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 340*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 148*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 + 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 4544*Sqrt[25 - 5*Sqrt[5]] + 
      10160*Sqrt[5 - Sqrt[5]] - 2120*Sqrt[5 + Sqrt[5]] - 
      952*Sqrt[5*(5 + Sqrt[5])] + 2912*Sqrt[25 - 5*Sqrt[5]]*x + 
      6560*Sqrt[5 - Sqrt[5]]*x - 6560*Sqrt[5 + Sqrt[5]]*x - 
      2976*Sqrt[5*(5 + Sqrt[5])]*x + 888*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      2040*Sqrt[5 - Sqrt[5]]*x^2 - 2960*Sqrt[5 + Sqrt[5]]*x^2 - 
      1312*Sqrt[5*(5 + Sqrt[5])]*x^2 - 104*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      280*Sqrt[5 - Sqrt[5]]*x^3 + 280*Sqrt[5 + Sqrt[5]]*x^3 + 
      120*Sqrt[5*(5 + Sqrt[5])]*x^3 - 412*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      940*Sqrt[5 - Sqrt[5]]*x*y + 2240*Sqrt[5 + Sqrt[5]]*x*y + 
      1016*Sqrt[5*(5 + Sqrt[5])]*x*y - 936*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      2120*Sqrt[5 - Sqrt[5]]*x^2*y + 4080*Sqrt[5 + Sqrt[5]]*x^2*y + 
      1824*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 312*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      720*Sqrt[5 - Sqrt[5]]*x^3*y - 500*Sqrt[5 + Sqrt[5]]*x^3*y - 
      220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 748*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      1680*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 2150*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      962*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      660*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 360*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      245*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 90*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, -76000*Sqrt[2*(25 - 5*Sqrt[5])] + 
      30400*Sqrt[10*(25 - 5*Sqrt[5])] - 170080*Sqrt[2*(5 - Sqrt[5])] + 
      68032*Sqrt[10*(5 - Sqrt[5])] + 17280*Sqrt[2*(5 + Sqrt[5])] + 
      7872*Sqrt[10*(5 + Sqrt[5])] + 120480*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      48192*Sqrt[10*(25 - 5*Sqrt[5])]*x + 269920*Sqrt[2*(5 - Sqrt[5])]*x - 
      107968*Sqrt[10*(5 - Sqrt[5])]*x - 5280*Sqrt[2*(5 + Sqrt[5])]*x - 
      2848*Sqrt[10*(5 + Sqrt[5])]*x - 65600*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      26240*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 147200*Sqrt[2*(5 - Sqrt[5])]*
       x^2 + 58880*Sqrt[10*(5 - Sqrt[5])]*x^2 - 9760*Sqrt[2*(5 + Sqrt[5])]*
       x^2 - 3936*Sqrt[10*(5 + Sqrt[5])]*x^2 - 640*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3 + 256*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 1280*Sqrt[2*(5 - Sqrt[5])]*
       x^3 + 512*Sqrt[10*(5 - Sqrt[5])]*x^3 + 960*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 - 133360*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      53344*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 298320*Sqrt[2*(5 - Sqrt[5])]*x*
       y + 119328*Sqrt[10*(5 - Sqrt[5])]*x*y + 4560*Sqrt[2*(5 + Sqrt[5])]*x*
       y + 2128*Sqrt[10*(5 + Sqrt[5])]*x*y + 125120*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y - 50048*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      280000*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 112000*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 8000*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 3392*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y + 7840*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y - 
      3136*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 17440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 1600*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 39520*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 15808*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      88400*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 35360*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 200*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 56*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 + 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 - 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -146720*Sqrt[2*(25 - 5*Sqrt[5])] + 58688*Sqrt[10*(25 - 5*Sqrt[5])] - 
      328160*Sqrt[2*(5 - Sqrt[5])] + 131264*Sqrt[10*(5 - Sqrt[5])] + 
      34080*Sqrt[2*(5 + Sqrt[5])] + 15264*Sqrt[10*(5 + Sqrt[5])] + 
      44320*Sqrt[2*(25 - 5*Sqrt[5])]*x - 17728*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      99360*Sqrt[2*(5 - Sqrt[5])]*x - 39744*Sqrt[10*(5 - Sqrt[5])]*x + 
      19840*Sqrt[2*(5 + Sqrt[5])]*x + 8896*Sqrt[10*(5 + Sqrt[5])]*x - 
      8160*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 3264*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 18560*Sqrt[2*(5 - Sqrt[5])]*x^2 + 7424*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 2480*Sqrt[2*(5 + Sqrt[5])]*x^2 - 1168*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3 + 1920*Sqrt[2*(5 - Sqrt[5])]*x^3 - 768*Sqrt[10*(5 - Sqrt[5])]*
       x^3 - 240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      109800*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 43920*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 245560*Sqrt[2*(5 - Sqrt[5])]*x*y + 98224*Sqrt[10*(5 - Sqrt[5])]*x*
       y - 7080*Sqrt[2*(5 + Sqrt[5])]*x*y - 3176*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      13520*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 5408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 30320*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      12128*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 400*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      144*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 5160*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y + 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 400*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      7760*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 3104*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 17360*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      6944*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 3120*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 1392*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 848*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 44680*Sqrt[2*(25 - 5*Sqrt[5])] - 
      17872*Sqrt[10*(25 - 5*Sqrt[5])] + 99880*Sqrt[2*(5 - Sqrt[5])] - 
      39952*Sqrt[10*(5 - Sqrt[5])] - 800*Sqrt[2*(5 + Sqrt[5])] - 
      336*Sqrt[10*(5 + Sqrt[5])] + 27000*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      10800*Sqrt[10*(25 - 5*Sqrt[5])]*x + 60440*Sqrt[2*(5 - Sqrt[5])]*x - 
      24176*Sqrt[10*(5 - Sqrt[5])]*x + 2400*Sqrt[2*(5 + Sqrt[5])]*x + 
      1040*Sqrt[10*(5 + Sqrt[5])]*x + 5360*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      2144*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 11920*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      4768*Sqrt[10*(5 - Sqrt[5])]*x^2 + 1200*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      560*Sqrt[10*(5 + Sqrt[5])]*x^2 - 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 + 240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 + 2980*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      1192*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 6660*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      2664*Sqrt[10*(5 - Sqrt[5])]*x*y - 1960*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      880*Sqrt[10*(5 + Sqrt[5])]*x*y + 6600*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      2640*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 14760*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 5904*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 400*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y - 160*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 1960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y - 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 
      4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      3660*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 1464*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 8180*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      3272*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 740*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 340*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 960*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 5360*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 
      2144*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 460*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 - 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 1208*Sqrt[25 - 5*Sqrt[5]] + 
      2704*Sqrt[5 - Sqrt[5]] - 164*Sqrt[5 + Sqrt[5]] - 
      76*Sqrt[5*(5 + Sqrt[5])] - 1584*Sqrt[25 - 5*Sqrt[5]]*x - 
      3568*Sqrt[5 - Sqrt[5]]*x + 1040*Sqrt[5 + Sqrt[5]]*x + 
      464*Sqrt[5*(5 + Sqrt[5])]*x - 352*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      760*Sqrt[5 - Sqrt[5]]*x^2 + 420*Sqrt[5 + Sqrt[5]]*x^2 + 
      188*Sqrt[5*(5 + Sqrt[5])]*x^2 + 1844*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      4148*Sqrt[5 - Sqrt[5]]*x*y - 680*Sqrt[5 + Sqrt[5]]*x*y - 
      304*Sqrt[5*(5 + Sqrt[5])]*x*y + 412*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      900*Sqrt[5 - Sqrt[5]]*x^2*y - 260*Sqrt[5 + Sqrt[5]]*x^2*y - 
      116*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 40*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      90*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 105*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      47*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, -116960*Sqrt[2*(25 - 5*Sqrt[5])] + 
      46784*Sqrt[10*(25 - 5*Sqrt[5])] - 261600*Sqrt[2*(5 - Sqrt[5])] + 
      104640*Sqrt[10*(5 - Sqrt[5])] + 23360*Sqrt[2*(5 + Sqrt[5])] + 
      10496*Sqrt[10*(5 + Sqrt[5])] - 16560*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      6624*Sqrt[10*(25 - 5*Sqrt[5])]*x - 36720*Sqrt[2*(5 - Sqrt[5])]*x + 
      14688*Sqrt[10*(5 - Sqrt[5])]*x + 5120*Sqrt[2*(5 + Sqrt[5])]*x + 
      2080*Sqrt[10*(5 + Sqrt[5])]*x - 18080*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      7232*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 40800*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      16320*Sqrt[10*(5 - Sqrt[5])]*x^2 - 4320*Sqrt[2*(5 + Sqrt[5])]*x^2 - 
      1760*Sqrt[10*(5 + Sqrt[5])]*x^2 - 1680*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      672*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 3600*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      1440*Sqrt[10*(5 - Sqrt[5])]*x^3 + 800*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 - 7800*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      3120*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 17480*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      6992*Sqrt[10*(5 - Sqrt[5])]*x*y - 3080*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      1320*Sqrt[10*(5 + Sqrt[5])]*x*y + 46640*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y - 18656*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      104400*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 41760*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 5040*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 2160*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y + 7640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y - 
      3056*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 17000*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 6800*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 1400*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 600*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 15060*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 6024*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      33700*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 13480*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 1920*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 840*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 8240*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      3296*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 18400*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 7360*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      1000*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 440*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 + 3580*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      1432*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 8000*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^3 - 3200*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 250*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^3 - 110*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -5400*Sqrt[25 - 5*Sqrt[5]] - 12200*Sqrt[5 - Sqrt[5]] + 
      10600*Sqrt[5 + Sqrt[5]] + 4808*Sqrt[5*(5 + Sqrt[5])] + 
      4744*Sqrt[25 - 5*Sqrt[5]]*x + 11240*Sqrt[5 - Sqrt[5]]*x + 
      800*Sqrt[5 + Sqrt[5]]*x + 80*Sqrt[5*(5 + Sqrt[5])]*x - 
      2840*Sqrt[25 - 5*Sqrt[5]]*x^2 - 7000*Sqrt[5 - Sqrt[5]]*x^2 - 
      5520*Sqrt[5 + Sqrt[5]]*x^2 - 2240*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      40*Sqrt[25 - 5*Sqrt[5]]*x^3 + 280*Sqrt[5 - Sqrt[5]]*x^3 + 
      40*(5 + Sqrt[5])^(3/2)*x^3 - 6904*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      15560*Sqrt[5 - Sqrt[5]]*x*y + 1480*Sqrt[5 + Sqrt[5]]*x*y + 
      680*Sqrt[5*(5 + Sqrt[5])]*x*y + 5960*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      13560*Sqrt[5 - Sqrt[5]]*x^2*y + 3640*Sqrt[5 + Sqrt[5]]*x^2*y + 
      1560*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 120*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      160*Sqrt[5 - Sqrt[5]]*x^3*y - 300*Sqrt[5 + Sqrt[5]]*x^3*y - 
      100*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 2160*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      4860*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 930*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      430*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 220*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      460*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 200*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      80*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 135*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      295*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 50*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      20*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, -448*Sqrt[2*(25 - 5*Sqrt[5])] - 
      1040*Sqrt[2*(5 - Sqrt[5])] + 1400*Sqrt[2*(5 + Sqrt[5])] + 
      648*Sqrt[10*(5 + Sqrt[5])] + 176*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      640*Sqrt[2*(5 - Sqrt[5])]*x + 1480*Sqrt[2*(5 + Sqrt[5])]*x + 
      440*Sqrt[10*(5 + Sqrt[5])]*x - 160*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      160*Sqrt[10*(5 + Sqrt[5])]*x^2 - 456*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      960*Sqrt[2*(5 - Sqrt[5])]*x*y - 540*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      260*Sqrt[10*(5 + Sqrt[5])]*x*y + 40*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y + 
      120*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 200*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      120*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 20*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 60*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 100*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 60*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2, 
     212160*Sqrt[2*(25 - 5*Sqrt[5])] - 84864*Sqrt[10*(25 - 5*Sqrt[5])] + 
      474400*Sqrt[2*(5 - Sqrt[5])] - 189760*Sqrt[10*(5 - Sqrt[5])] - 
      10480*Sqrt[2*(5 + Sqrt[5])] - 4624*Sqrt[10*(5 + Sqrt[5])] + 
      103760*Sqrt[2*(25 - 5*Sqrt[5])]*x - 41504*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      232080*Sqrt[2*(5 - Sqrt[5])]*x - 92832*Sqrt[10*(5 - Sqrt[5])]*x + 
      320*Sqrt[2*(5 + Sqrt[5])]*x - 160*Sqrt[10*(5 + Sqrt[5])]*x + 
      2320*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 928*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 
      5200*Sqrt[2*(5 - Sqrt[5])]*x^2 - 2080*Sqrt[10*(5 - Sqrt[5])]*x^2 + 
      4800*Sqrt[2*(5 + Sqrt[5])]*x^2 + 2400*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      1440*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 576*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 
      3200*Sqrt[2*(5 - Sqrt[5])]*x^3 + 1280*Sqrt[10*(5 - Sqrt[5])]*x^3 + 
      1200*Sqrt[2*(5 + Sqrt[5])]*x^3 + 400*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      44320*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 17728*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 99120*Sqrt[2*(5 - Sqrt[5])]*x*y - 39648*Sqrt[10*(5 - Sqrt[5])]*x*
       y - 3560*Sqrt[2*(5 + Sqrt[5])]*x*y - 1560*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      53520*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 21408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 119600*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      47840*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 1200*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      560*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 10120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 4048*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 22600*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y - 9040*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 2000*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y - 800*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      21340*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 8536*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 47700*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      19080*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 3500*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 1580*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      11720*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 4688*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 26200*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 
      10480*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 1400*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 600*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      5390*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 2156*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 12050*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      4820*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 350*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 - 150*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 14688*Sqrt[25 - 5*Sqrt[5]] + 
      32720*Sqrt[5 - Sqrt[5]] + 440*Sqrt[5 + Sqrt[5]] + 
      264*Sqrt[5*(5 + Sqrt[5])] - 80*Sqrt[25 - 5*Sqrt[5]]*x + 
      240*Sqrt[5 - Sqrt[5]]*x + 2880*Sqrt[5 + Sqrt[5]]*x + 
      1120*Sqrt[5*(5 + Sqrt[5])]*x - 840*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      2280*Sqrt[5 - Sqrt[5]]*x^2 + 1760*Sqrt[5 + Sqrt[5]]*x^2 + 
      880*Sqrt[5*(5 + Sqrt[5])]*x^2 + 40*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      280*Sqrt[5 - Sqrt[5]]*x^3 + 40*(5 + Sqrt[5])^(3/2)*x^3 + 
      8900*Sqrt[25 - 5*Sqrt[5]]*x*y + 19860*Sqrt[5 - Sqrt[5]]*x*y - 
      1680*Sqrt[5 + Sqrt[5]]*x*y - 760*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      4760*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 10680*Sqrt[5 - Sqrt[5]]*x^2*y - 
      1520*Sqrt[5 + Sqrt[5]]*x^2*y - 640*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      120*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 160*Sqrt[5 - Sqrt[5]]*x^3*y - 
      300*Sqrt[5 + Sqrt[5]]*x^3*y - 100*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      2200*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 4900*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      10*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 10*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      220*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 460*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 
      200*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 80*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      135*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 295*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 
      50*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     8280*Sqrt[2*(25 - 5*Sqrt[5])] - 3312*Sqrt[10*(25 - 5*Sqrt[5])] + 
      18520*Sqrt[2*(5 - Sqrt[5])] - 7408*Sqrt[10*(5 - Sqrt[5])] + 
      80*Sqrt[2*(5 + Sqrt[5])] + 96*Sqrt[10*(5 + Sqrt[5])] - 
      5800*Sqrt[2*(25 - 5*Sqrt[5])]*x + 2320*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      13000*Sqrt[2*(5 - Sqrt[5])]*x + 5200*Sqrt[10*(5 - Sqrt[5])]*x - 
      160*Sqrt[2*(5 + Sqrt[5])]*x - 240*Sqrt[10*(5 + Sqrt[5])]*x + 
      880*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 352*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 
      2000*Sqrt[2*(5 - Sqrt[5])]*x^2 - 800*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      400*Sqrt[2*(5 + Sqrt[5])]*x^2 - 80*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      7820*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 3128*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 17500*Sqrt[2*(5 - Sqrt[5])]*x*y - 7000*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 80*Sqrt[2*(5 + Sqrt[5])]*x*y + 40*Sqrt[10*(5 + Sqrt[5])]*x*y - 
      1160*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y + 464*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y - 2600*Sqrt[2*(5 - Sqrt[5])]*x^2*y + 1040*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 400*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y + 580*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      232*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 + 1300*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 - 520*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 200*Sqrt[2*(5 + Sqrt[5])]*
       x^2*y^2 - 80*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2, 
     -75840*Sqrt[2*(25 - 5*Sqrt[5])] + 30336*Sqrt[10*(25 - 5*Sqrt[5])] - 
      169600*Sqrt[2*(5 - Sqrt[5])] + 67840*Sqrt[10*(5 - Sqrt[5])] + 
      25120*Sqrt[2*(5 + Sqrt[5])] + 11360*Sqrt[10*(5 + Sqrt[5])] + 
      79360*Sqrt[2*(25 - 5*Sqrt[5])]*x - 31744*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      177600*Sqrt[2*(5 - Sqrt[5])]*x - 71040*Sqrt[10*(5 - Sqrt[5])]*x - 
      8480*Sqrt[2*(5 + Sqrt[5])]*x - 4320*Sqrt[10*(5 + Sqrt[5])]*x - 
      41440*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 16576*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 92800*Sqrt[2*(5 - Sqrt[5])]*x^2 + 37120*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 12080*Sqrt[2*(5 + Sqrt[5])]*x^2 - 4880*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 1440*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      576*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 3200*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      1280*Sqrt[10*(5 - Sqrt[5])]*x^3 + 1200*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      400*Sqrt[10*(5 + Sqrt[5])]*x^3 - 111880*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      44752*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 250200*Sqrt[2*(5 - Sqrt[5])]*x*
       y + 100080*Sqrt[10*(5 - Sqrt[5])]*x*y + 4760*Sqrt[2*(5 + Sqrt[5])]*x*
       y + 2200*Sqrt[10*(5 + Sqrt[5])]*x*y + 86000*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y - 34400*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      192400*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 76960*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 11760*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 5040*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y + 10120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y - 
      4048*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 22600*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 9040*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 2000*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 800*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 27360*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 10944*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      61200*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 24480*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 2680*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 1160*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 - 11720*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      4688*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 26200*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 10480*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      1400*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 600*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 + 5390*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      2156*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 12050*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 - 4820*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 
      350*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 150*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -864*Sqrt[25 - 5*Sqrt[5]] - 1928*Sqrt[5 - Sqrt[5]] + 
      2476*Sqrt[5 + Sqrt[5]] + 1108*Sqrt[5*(5 + Sqrt[5])] + 
      600*Sqrt[25 - 5*Sqrt[5]]*x + 1320*Sqrt[5 - Sqrt[5]]*x + 
      1160*Sqrt[5 + Sqrt[5]]*x + 520*Sqrt[5*(5 + Sqrt[5])]*x - 
      96*Sqrt[25 - 5*Sqrt[5]]*x^2 - 200*Sqrt[5 - Sqrt[5]]*x^2 - 
      420*Sqrt[5 + Sqrt[5]]*x^2 - 188*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      1112*Sqrt[25 - 5*Sqrt[5]]*x*y - 2480*Sqrt[5 - Sqrt[5]]*x*y - 
      420*Sqrt[5 + Sqrt[5]]*x*y - 188*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      100*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 220*Sqrt[5 - Sqrt[5]]*x^2*y + 
      260*Sqrt[5 + Sqrt[5]]*x^2*y + 116*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      4*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 10*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      105*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 47*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 
     114240*Sqrt[2*(25 - 5*Sqrt[5])] - 45696*Sqrt[10*(25 - 5*Sqrt[5])] + 
      255360*Sqrt[2*(5 - Sqrt[5])] - 102144*Sqrt[10*(5 - Sqrt[5])] + 
      24800*Sqrt[2*(5 + Sqrt[5])] + 11168*Sqrt[10*(5 + Sqrt[5])] + 
      121360*Sqrt[2*(25 - 5*Sqrt[5])]*x - 48544*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      271600*Sqrt[2*(5 - Sqrt[5])]*x - 108640*Sqrt[10*(5 - Sqrt[5])]*x + 
      32880*Sqrt[2*(5 + Sqrt[5])]*x + 14640*Sqrt[10*(5 + Sqrt[5])]*x - 
      5600*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 2240*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 12800*Sqrt[2*(5 - Sqrt[5])]*x^2 + 5120*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 11280*Sqrt[2*(5 + Sqrt[5])]*x^2 + 5040*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 1680*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      672*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 3600*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      1440*Sqrt[10*(5 - Sqrt[5])]*x^3 + 800*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 - 37080*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      14832*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 83000*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      33200*Sqrt[10*(5 - Sqrt[5])]*x*y - 18560*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      8240*Sqrt[10*(5 + Sqrt[5])]*x*y + 40560*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y - 16224*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      90800*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 36320*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y - 8960*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 4000*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y + 7640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y - 
      3056*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 17000*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y - 6800*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 1400*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y - 600*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 14260*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 5704*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      31900*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 12760*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 20*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 20*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y^2 - 8240*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      3296*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 18400*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 7360*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 
      1000*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 440*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 + 3580*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      1432*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 + 8000*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^3 - 3200*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 250*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^3 - 110*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3}
 
F836 = {1160*Sqrt[25 - 5*Sqrt[5]] - 464*Sqrt[5*(25 - 5*Sqrt[5])] + 
      3800*Sqrt[5 - Sqrt[5]] - 1520*Sqrt[5*(5 - Sqrt[5])] + 
      1840*Sqrt[5 + Sqrt[5]] - 960*Sqrt[5*(5 + Sqrt[5])] + 
      1100*Sqrt[25 - 5*Sqrt[5]]*x - 440*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      4500*Sqrt[5 - Sqrt[5]]*x - 1800*Sqrt[5*(5 - Sqrt[5])]*x + 
      3620*Sqrt[5 + Sqrt[5]]*x - 1660*Sqrt[5*(5 + Sqrt[5])]*x + 
      320*Sqrt[25 - 5*Sqrt[5]]*x^2 - 128*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      1400*Sqrt[5 - Sqrt[5]]*x^2 - 560*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      1540*Sqrt[5 + Sqrt[5]]*x^2 - 660*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 + 
      100*Sqrt[5 - Sqrt[5]]*x^3 - 40*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      200*Sqrt[5 + Sqrt[5]]*x^3 - 80*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      380*Sqrt[25 - 5*Sqrt[5]]*x*y + 152*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 
      3800*Sqrt[5 - Sqrt[5]]*x*y + 1520*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      5410*Sqrt[5 + Sqrt[5]]*x*y + 2410*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      300*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 120*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      1100*Sqrt[5 - Sqrt[5]]*x^2*y + 440*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      4060*Sqrt[5 + Sqrt[5]]*x^2*y + 1780*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 
      150*Sqrt[5 - Sqrt[5]]*x^3*y + 60*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      730*Sqrt[5 + Sqrt[5]]*x^3*y + 310*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      370*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 148*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 300*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 120*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 2625*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 1165*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 75*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 30*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 125*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 50*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 940*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 410*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 - 430*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 190*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, 536*Sqrt[(25 - 5*Sqrt[5])/5] - 268*Sqrt[25 - 5*Sqrt[5]] - 
      580*Sqrt[5 - Sqrt[5]] + 232*Sqrt[5*(5 - Sqrt[5])] + 
      108*Sqrt[5 + Sqrt[5]] - 4*Sqrt[5*(5 + Sqrt[5])] + 
      160*Sqrt[25 - 5*Sqrt[5]]*x - 64*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      160*Sqrt[5 - Sqrt[5]]*x + 64*Sqrt[5*(5 - Sqrt[5])]*x - 
      936*Sqrt[5 + Sqrt[5]]*x + 440*Sqrt[5*(5 + Sqrt[5])]*x + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 16*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      120*Sqrt[5 - Sqrt[5]]*x^2 - 48*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      188*Sqrt[5 + Sqrt[5]]*x^2 - 92*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      120*Sqrt[5 + Sqrt[5]]*x^3 - 56*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      352*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 176*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      220*Sqrt[5 - Sqrt[5]]*x*y - 88*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      1138*Sqrt[5 + Sqrt[5]]*x*y - 530*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      330*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 132*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      570*Sqrt[5 - Sqrt[5]]*x^2*y - 228*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      172*Sqrt[5 + Sqrt[5]]*x^2*y + 96*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 36*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      60*Sqrt[5 - Sqrt[5]]*x^3*y + 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      456*Sqrt[5 + Sqrt[5]]*x^3*y + 208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      348*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 174*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 420*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 168*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 65*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 21*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 598*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 270*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 18*Sqrt[25 - 5*Sqrt[5]]*
       x^3*y^3 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 - 276*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 124*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, 216*Sqrt[(25 - 5*Sqrt[5])/5] - 108*Sqrt[25 - 5*Sqrt[5]] - 
      380*Sqrt[5 - Sqrt[5]] + 152*Sqrt[5*(5 - Sqrt[5])] - 
      152*Sqrt[5 + Sqrt[5]] + 96*Sqrt[5*(5 + Sqrt[5])] + 
      20*Sqrt[25 - 5*Sqrt[5]]*x - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      20*Sqrt[5 - Sqrt[5]]*x + 8*Sqrt[5*(5 - Sqrt[5])]*x + 
      28*(5 + Sqrt[5])^(3/2)*x - (56*(5 + Sqrt[5])^(3/2)*x)/Sqrt[5] + 
      112*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 56*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      80*Sqrt[5 - Sqrt[5]]*x^2 - 32*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      508*Sqrt[5 + Sqrt[5]]*x^2 - 236*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      120*Sqrt[5 + Sqrt[5]]*x^3 - 56*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      92*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 46*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      150*Sqrt[5 - Sqrt[5]]*x*y + 60*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      292*Sqrt[5 + Sqrt[5]]*x*y + 128*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      180*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      140*Sqrt[5 - Sqrt[5]]*x^2*y + 56*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      1312*Sqrt[5 + Sqrt[5]]*x^2*y + 600*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 36*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      60*Sqrt[5 - Sqrt[5]]*x^3*y + 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      456*Sqrt[5 + Sqrt[5]]*x^3*y + 208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      248*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 124*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 130*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 52*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 925*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 417*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 598*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 270*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 18*Sqrt[25 - 5*Sqrt[5]]*
       x^3*y^3 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 - 276*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 124*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -24*Sqrt[(25 - 5*Sqrt[5])/5] + 12*Sqrt[25 - 5*Sqrt[5]] + 
      100*Sqrt[5 - Sqrt[5]] - 40*Sqrt[5*(5 - Sqrt[5])] + 
      148*Sqrt[5 + Sqrt[5]] - 60*Sqrt[5*(5 + Sqrt[5])] + 
      180*Sqrt[25 - 5*Sqrt[5]]*x - 72*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      500*Sqrt[5 - Sqrt[5]]*x - 200*Sqrt[5*(5 - Sqrt[5])]*x + 
      24*Sqrt[5 + Sqrt[5]]*x - 32*Sqrt[5*(5 + Sqrt[5])]*x - 
      168*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 + 84*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      300*Sqrt[5 - Sqrt[5]]*x^2 - 120*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      108*Sqrt[5 + Sqrt[5]]*x^2 - 52*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 4*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      40*Sqrt[5 + Sqrt[5]]*x^3 - 16*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 36*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      280*Sqrt[5 - Sqrt[5]]*x*y + 112*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      202*Sqrt[5 + Sqrt[5]]*x*y + 98*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      80*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 32*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      460*Sqrt[5 - Sqrt[5]]*x^2*y + 184*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      282*Sqrt[5 + Sqrt[5]]*x^2*y + 130*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      146*Sqrt[5 + Sqrt[5]]*x^3*y + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 + 6*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      210*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 84*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      200*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 92*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      188*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 82*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      10*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     176*Sqrt[(25 - 5*Sqrt[5])/5] - 88*Sqrt[25 - 5*Sqrt[5]] - 
      520*Sqrt[5 - Sqrt[5]] + 208*Sqrt[5*(5 - Sqrt[5])] - 
      432*Sqrt[5 + Sqrt[5]] + 224*Sqrt[5*(5 + Sqrt[5])] - 
      100*Sqrt[25 - 5*Sqrt[5]]*x + 40*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      300*Sqrt[5 - Sqrt[5]]*x + 120*Sqrt[5*(5 - Sqrt[5])]*x - 
      76*Sqrt[5 + Sqrt[5]]*x + 68*Sqrt[5*(5 + Sqrt[5])]*x + 
      192*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 96*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      240*Sqrt[5 - Sqrt[5]]*x^2 + 96*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      24*(5 + Sqrt[5])^(3/2)*x^2 + (48*(5 + Sqrt[5])^(3/2)*x^2)/Sqrt[5] + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 16*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      40*Sqrt[5 - Sqrt[5]]*x^3 + 16*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      20*Sqrt[5 + Sqrt[5]]*x^3 + 4*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      112*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 56*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      40*Sqrt[5 - Sqrt[5]]*x*y - 16*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      268*Sqrt[5 + Sqrt[5]]*x*y - 132*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      40*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      180*Sqrt[5 - Sqrt[5]]*x^2*y - 72*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      198*Sqrt[5 + Sqrt[5]]*x^2*y - 78*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      64*Sqrt[5 + Sqrt[5]]*x^3*y - 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 + 16*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      40*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 16*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 - 
      130*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 58*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      77*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 29*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      14*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 7*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      5*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 2*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     136*Sqrt[(25 - 5*Sqrt[5])/5] - 68*Sqrt[25 - 5*Sqrt[5]] - 
      220*Sqrt[5 - Sqrt[5]] + 88*Sqrt[5*(5 - Sqrt[5])] - 
      52*Sqrt[5 + Sqrt[5]] + 44*Sqrt[5*(5 + Sqrt[5])] - 
      100*Sqrt[25 - 5*Sqrt[5]]*x + 40*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      420*Sqrt[5 - Sqrt[5]]*x + 168*Sqrt[5*(5 - Sqrt[5])]*x - 
      136*Sqrt[5 + Sqrt[5]]*x + 112*Sqrt[5*(5 + Sqrt[5])]*x + 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 36*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      60*Sqrt[5 - Sqrt[5]]*x^2 + 24*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      148*Sqrt[5 + Sqrt[5]]*x^2 - 44*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 4*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      40*Sqrt[5 + Sqrt[5]]*x^3 - 16*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 36*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      80*Sqrt[5 - Sqrt[5]]*x*y - 32*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      98*Sqrt[5 + Sqrt[5]]*x*y - 74*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      180*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      560*Sqrt[5 - Sqrt[5]]*x^2*y - 224*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      18*Sqrt[5 + Sqrt[5]]*x^2*y - 18*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      146*Sqrt[5 + Sqrt[5]]*x^3*y + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      148*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 74*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 390*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 156*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 220*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 96*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 25*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 188*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 82*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 - 10*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     736*Sqrt[(25 - 5*Sqrt[5])/5] - 368*Sqrt[25 - 5*Sqrt[5]] - 
      1200*Sqrt[5 - Sqrt[5]] + 480*Sqrt[5*(5 - Sqrt[5])] - 
      472*Sqrt[5 + Sqrt[5]] + 280*Sqrt[5*(5 + Sqrt[5])] + 
      60*Sqrt[25 - 5*Sqrt[5]]*x - 24*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      100*Sqrt[5 - Sqrt[5]]*x - 40*Sqrt[5*(5 - Sqrt[5])]*x - 
      36*Sqrt[5 + Sqrt[5]]*x + 28*Sqrt[5*(5 + Sqrt[5])]*x - 
      48*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 + 24*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      40*Sqrt[5 - Sqrt[5]]*x^2 - 16*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      72*Sqrt[5 + Sqrt[5]]*x^2 + 8*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 16*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      40*Sqrt[5 - Sqrt[5]]*x^3 + 16*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      20*Sqrt[5 + Sqrt[5]]*x^3 + 4*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      112*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 56*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      128*Sqrt[5 + Sqrt[5]]*x*y - 72*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      180*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      480*Sqrt[5 - Sqrt[5]]*x^2*y - 192*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      198*Sqrt[5 + Sqrt[5]]*x^2*y - 54*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      64*Sqrt[5 + Sqrt[5]]*x^3*y - 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      208*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 104*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 300*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 120*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 140*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 52*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 77*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 29*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 14*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 7*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 - 5*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 2*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -224*Sqrt[(25 - 5*Sqrt[5])/5] + 112*Sqrt[25 - 5*Sqrt[5]] + 
      720*Sqrt[5 - Sqrt[5]] - 288*Sqrt[5*(5 - Sqrt[5])] + 
      728*Sqrt[5 + Sqrt[5]] - 344*Sqrt[5*(5 + Sqrt[5])] + 
      60*Sqrt[25 - 5*Sqrt[5]]*x - 24*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      220*Sqrt[5 - Sqrt[5]]*x + 88*Sqrt[5*(5 - Sqrt[5])]*x - 
      636*Sqrt[5 + Sqrt[5]]*x + 292*Sqrt[5*(5 + Sqrt[5])]*x + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 16*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      40*Sqrt[5 - Sqrt[5]]*x^2 + 16*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      52*Sqrt[5 + Sqrt[5]]*x^2 + 36*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 4*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      40*Sqrt[5 + Sqrt[5]]*x^3 - 16*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 16*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      300*Sqrt[5 - Sqrt[5]]*x*y - 120*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      658*Sqrt[5 + Sqrt[5]]*x*y - 306*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      40*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      120*Sqrt[5 - Sqrt[5]]*x^2*y - 48*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      128*Sqrt[5 + Sqrt[5]]*x^2*y - 80*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      146*Sqrt[5 + Sqrt[5]]*x^3*y + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      28*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 14*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      60*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 24*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 - 
      65*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 37*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      188*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 82*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      10*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -104*Sqrt[(25 - 5*Sqrt[5])/5] + 52*Sqrt[25 - 5*Sqrt[5]] - 
      180*Sqrt[5 - Sqrt[5]] + 72*Sqrt[5*(5 - Sqrt[5])] - 
      412*Sqrt[5 + Sqrt[5]] + 196*Sqrt[5*(5 + Sqrt[5])] - 
      40*Sqrt[25 - 5*Sqrt[5]]*x + 16*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      40*Sqrt[5 - Sqrt[5]]*x - 16*Sqrt[5*(5 - Sqrt[5])]*x + 
      384*Sqrt[5 + Sqrt[5]]*x - 160*Sqrt[5*(5 + Sqrt[5])]*x + 
      192*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 96*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      40*Sqrt[5 - Sqrt[5]]*x^2 - 16*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      588*Sqrt[5 + Sqrt[5]]*x^2 - 268*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      120*Sqrt[5 + Sqrt[5]]*x^3 - 56*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      48*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 24*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      140*Sqrt[5 - Sqrt[5]]*x*y + 56*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      542*Sqrt[5 + Sqrt[5]]*x*y + 238*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      170*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 68*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      230*Sqrt[5 - Sqrt[5]]*x^2*y + 92*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      1452*Sqrt[5 + Sqrt[5]]*x^2*y + 656*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 36*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      60*Sqrt[5 - Sqrt[5]]*x^3*y + 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      456*Sqrt[5 + Sqrt[5]]*x^3*y + 208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      188*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 94*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 180*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 72*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 935*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 419*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 598*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 270*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 18*Sqrt[25 - 5*Sqrt[5]]*
       x^3*y^3 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 - 276*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 124*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -104*Sqrt[(25 - 5*Sqrt[5])/5] + 52*Sqrt[25 - 5*Sqrt[5]] + 
      260*Sqrt[5 - Sqrt[5]] - 104*Sqrt[5*(5 - Sqrt[5])] + 
      248*Sqrt[5 + Sqrt[5]] - 112*Sqrt[5*(5 + Sqrt[5])] + 
      180*Sqrt[25 - 5*Sqrt[5]]*x - 72*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      140*Sqrt[5 - Sqrt[5]]*x - 56*Sqrt[5*(5 - Sqrt[5])]*x - 
      556*Sqrt[5 + Sqrt[5]]*x + 260*Sqrt[5*(5 + Sqrt[5])]*x + 
      112*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 56*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      80*Sqrt[5 - Sqrt[5]]*x^2 - 32*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      268*Sqrt[5 + Sqrt[5]]*x^2 - 124*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      120*Sqrt[5 + Sqrt[5]]*x^3 - 56*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      332*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 166*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      50*Sqrt[5 - Sqrt[5]]*x*y - 20*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      828*Sqrt[5 + Sqrt[5]]*x*y - 384*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      60*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 24*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      260*Sqrt[5 - Sqrt[5]]*x^2*y + 104*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      512*Sqrt[5 + Sqrt[5]]*x^2*y + 232*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 36*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      60*Sqrt[5 - Sqrt[5]]*x^3*y + 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      456*Sqrt[5 + Sqrt[5]]*x^3*y + 208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 4*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      130*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 52*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      165*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 73*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      100*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 40*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      598*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 270*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      50*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      276*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 124*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     16*Sqrt[(25 - 5*Sqrt[5])/5] - 8*Sqrt[25 - 5*Sqrt[5]] + 
      120*Sqrt[5 - Sqrt[5]] - 48*Sqrt[5*(5 - Sqrt[5])] + 
      208*Sqrt[5 + Sqrt[5]] - 64*Sqrt[5*(5 + Sqrt[5])] + 
      100*Sqrt[25 - 5*Sqrt[5]]*x - 40*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      60*Sqrt[5 - Sqrt[5]]*x + 24*Sqrt[5*(5 - Sqrt[5])]*x - 
      416*Sqrt[5 + Sqrt[5]]*x + 264*Sqrt[5*(5 + Sqrt[5])]*x - 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 + 4*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      20*Sqrt[5 - Sqrt[5]]*x^2 - 8*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      48*Sqrt[5 + Sqrt[5]]*x^2 + 8*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 4*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      40*Sqrt[5 + Sqrt[5]]*x^3 - 16*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      292*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 146*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      110*Sqrt[5 - Sqrt[5]]*x*y + 44*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      338*Sqrt[5 + Sqrt[5]]*x*y - 198*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      120*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 48*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      460*Sqrt[5 - Sqrt[5]]*x^2*y - 184*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      278*Sqrt[5 + Sqrt[5]]*x^2*y - 142*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      146*Sqrt[5 + Sqrt[5]]*x^3*y + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      108*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 54*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 360*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 144*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 375*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 167*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 25*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 188*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 82*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 - 10*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     496*Sqrt[(25 - 5*Sqrt[5])/5] - 248*Sqrt[25 - 5*Sqrt[5]] - 
      840*Sqrt[5 - Sqrt[5]] + 336*Sqrt[5*(5 - Sqrt[5])] - 
      392*Sqrt[5 + Sqrt[5]] + 248*Sqrt[5*(5 + Sqrt[5])] + 
      100*Sqrt[25 - 5*Sqrt[5]]*x - 40*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      220*Sqrt[5 - Sqrt[5]]*x - 88*Sqrt[5*(5 - Sqrt[5])]*x - 
      36*Sqrt[5 + Sqrt[5]]*x + 28*Sqrt[5*(5 + Sqrt[5])]*x - 
      48*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 + 24*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      40*Sqrt[5 - Sqrt[5]]*x^2 - 16*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      72*Sqrt[5 + Sqrt[5]]*x^2 + 8*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 16*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      40*Sqrt[5 - Sqrt[5]]*x^3 + 16*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      20*Sqrt[5 + Sqrt[5]]*x^3 + 4*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      132*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 66*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      50*Sqrt[5 - Sqrt[5]]*x*y + 20*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      188*Sqrt[5 + Sqrt[5]]*x*y - 88*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      180*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      460*Sqrt[5 - Sqrt[5]]*x^2*y - 184*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      168*Sqrt[5 + Sqrt[5]]*x^2*y - 40*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      64*Sqrt[5 + Sqrt[5]]*x^3*y - 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      228*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 114*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 310*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 124*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 110*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 38*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 77*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 29*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 14*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 7*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 - 5*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 2*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     860*Sqrt[25 - 5*Sqrt[5]] - 344*Sqrt[5*(25 - 5*Sqrt[5])] + 
      3100*Sqrt[5 - Sqrt[5]] - 1240*Sqrt[5*(5 - Sqrt[5])] + 
      1640*Sqrt[5 + Sqrt[5]] - 720*Sqrt[5*(5 + Sqrt[5])] - 
      600*Sqrt[25 - 5*Sqrt[5]]*x + 240*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      2600*Sqrt[5 - Sqrt[5]]*x + 1040*Sqrt[5*(5 - Sqrt[5])]*x - 
      2080*Sqrt[5 + Sqrt[5]]*x + 880*Sqrt[5*(5 + Sqrt[5])]*x - 
      280*Sqrt[25 - 5*Sqrt[5]]*x^2 + 112*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      600*Sqrt[5 - Sqrt[5]]*x^2 + 240*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      240*Sqrt[5 + Sqrt[5]]*x^2 - 80*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 + 
      100*Sqrt[5 - Sqrt[5]]*x^3 - 40*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      200*Sqrt[5 + Sqrt[5]]*x^3 - 80*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      520*Sqrt[25 - 5*Sqrt[5]]*x*y - 208*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 
      2400*Sqrt[5 - Sqrt[5]]*x*y - 960*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      1940*Sqrt[5 + Sqrt[5]]*x*y - 860*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      350*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 140*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      750*Sqrt[5 - Sqrt[5]]*x^2*y - 300*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      660*Sqrt[5 + Sqrt[5]]*x^2*y + 240*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 
      150*Sqrt[5 - Sqrt[5]]*x^3*y + 60*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      730*Sqrt[5 + Sqrt[5]]*x^3*y + 310*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      120*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 48*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 200*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 80*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 550*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 230*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 75*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 30*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 125*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 50*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 940*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 410*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 - 430*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 190*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -32*Sqrt[(25 - 5*Sqrt[5])/5] + 16*Sqrt[25 - 5*Sqrt[5]] - 
      80*Sqrt[5 - Sqrt[5]] + 32*Sqrt[5*(5 - Sqrt[5])] - 
      176*Sqrt[5 + Sqrt[5]] + 96*Sqrt[5*(5 + Sqrt[5])] - 
      20*Sqrt[25 - 5*Sqrt[5]]*x + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      140*Sqrt[5 - Sqrt[5]]*x + 56*Sqrt[5*(5 - Sqrt[5])]*x - 
      188*Sqrt[5 + Sqrt[5]]*x + 84*Sqrt[5*(5 + Sqrt[5])]*x + 
      96*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 48*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      184*Sqrt[5 + Sqrt[5]]*x^2 - 88*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      60*Sqrt[5 + Sqrt[5]]*x^3 - 28*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      116*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 58*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      30*Sqrt[5 - Sqrt[5]]*x*y + 12*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      194*Sqrt[5 + Sqrt[5]]*x*y - 86*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      70*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 28*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      70*Sqrt[5 - Sqrt[5]]*x^2*y + 28*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      426*Sqrt[5 + Sqrt[5]]*x^2*y + 198*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      228*Sqrt[5 + Sqrt[5]]*x^3*y + 104*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      64*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 32*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      60*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 24*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      270*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 122*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      50*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      299*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 135*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      18*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 9*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      138*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -192*Sqrt[(25 - 5*Sqrt[5])/5] + 96*Sqrt[25 - 5*Sqrt[5]] + 
      240*Sqrt[5 - Sqrt[5]] - 96*Sqrt[5*(5 - Sqrt[5])] + 
      8*(5 + Sqrt[5])^(3/2) - (16*(5 + Sqrt[5])^(3/2))/Sqrt[5] + 
      100*Sqrt[25 - 5*Sqrt[5]]*x - 40*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      260*Sqrt[5 - Sqrt[5]]*x - 104*Sqrt[5*(5 - Sqrt[5])]*x + 
      72*Sqrt[5 + Sqrt[5]]*x - 16*Sqrt[5*(5 + Sqrt[5])]*x + 
      56*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 28*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      60*Sqrt[5 - Sqrt[5]]*x^2 - 24*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      244*Sqrt[5 + Sqrt[5]]*x^2 - 108*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      60*Sqrt[5 + Sqrt[5]]*x^3 - 28*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      24*Sqrt[5 - Sqrt[5]]*x*y - 12*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      16*Sqrt[5 + Sqrt[5]]*x*y - 8*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      40*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      180*Sqrt[5 - Sqrt[5]]*x^2*y + 72*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      546*Sqrt[5 + Sqrt[5]]*x^2*y + 242*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      228*Sqrt[5 + Sqrt[5]]*x^3*y + 104*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      24*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 12*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      100*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 40*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      275*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 121*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      50*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      299*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 135*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      18*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 9*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      138*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     248*Sqrt[(25 - 5*Sqrt[5])/5] - 124*Sqrt[25 - 5*Sqrt[5]] - 
      420*Sqrt[5 - Sqrt[5]] + 168*Sqrt[5*(5 - Sqrt[5])] - 
      196*Sqrt[5 + Sqrt[5]] + 124*Sqrt[5*(5 + Sqrt[5])] + 
      60*Sqrt[25 - 5*Sqrt[5]]*x - 24*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      20*Sqrt[5 - Sqrt[5]]*x - 8*Sqrt[5*(5 - Sqrt[5])]*x - 
      148*Sqrt[5 + Sqrt[5]]*x + 92*Sqrt[5*(5 + Sqrt[5])]*x + 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 8*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      80*Sqrt[5 - Sqrt[5]]*x^2 - 32*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      204*Sqrt[5 + Sqrt[5]]*x^2 - 92*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      60*Sqrt[5 + Sqrt[5]]*x^3 - 28*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      76*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 38*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      90*Sqrt[5 - Sqrt[5]]*x*y - 36*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      244*Sqrt[5 + Sqrt[5]]*x*y - 128*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      180*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      240*Sqrt[5 - Sqrt[5]]*x^2*y - 96*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      386*Sqrt[5 + Sqrt[5]]*x^2*y + 178*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      228*Sqrt[5 + Sqrt[5]]*x^3*y + 104*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      204*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 102*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 180*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 72*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 165*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 77*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 299*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 135*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 18*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 9*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 - 25*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 - 138*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, 8*Sqrt[(25 - 5*Sqrt[5])/5] - 4*Sqrt[25 - 5*Sqrt[5]] + 
      60*Sqrt[5 - Sqrt[5]] - 24*Sqrt[5*(5 - Sqrt[5])] + 
      104*Sqrt[5 + Sqrt[5]] - 32*Sqrt[5*(5 + Sqrt[5])] + 
      40*Sqrt[25 - 5*Sqrt[5]]*x - 16*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      80*Sqrt[5 - Sqrt[5]]*x + 32*Sqrt[5*(5 - Sqrt[5])]*x - 
      308*Sqrt[5 + Sqrt[5]]*x + 132*Sqrt[5*(5 + Sqrt[5])]*x + 
      56*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 28*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      20*Sqrt[5 - Sqrt[5]]*x^2 - 8*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      144*Sqrt[5 + Sqrt[5]]*x^2 - 72*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      60*Sqrt[5 + Sqrt[5]]*x^3 - 28*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 18*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      90*Sqrt[5 - Sqrt[5]]*x*y - 36*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      244*Sqrt[5 + Sqrt[5]]*x*y - 104*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      80*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 32*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      20*Sqrt[5 - Sqrt[5]]*x^2*y + 8*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      366*Sqrt[5 + Sqrt[5]]*x^2*y + 174*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      228*Sqrt[5 + Sqrt[5]]*x^3*y + 104*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      104*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 52*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 30*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 12*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 270*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 124*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 299*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 135*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 18*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 9*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 - 25*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 - 138*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, 192*Sqrt[25 - 5*Sqrt[5]] + 480*Sqrt[5 - Sqrt[5]] + 
      16*(5 + Sqrt[5])^(3/2) + 60*Sqrt[25 - 5*Sqrt[5]]*x + 
      380*Sqrt[5 - Sqrt[5]]*x - 320*Sqrt[5 + Sqrt[5]]*x - 
      312*Sqrt[5*(5 + Sqrt[5])]*x + 44*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      220*Sqrt[5 - Sqrt[5]]*x^2 - 104*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[25 - 5*Sqrt[5]]*x^3 + 20*Sqrt[5 - Sqrt[5]]*x^3 + 
      40*Sqrt[5 + Sqrt[5]]*x^3 + 34*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      290*Sqrt[5 - Sqrt[5]]*x*y - 70*Sqrt[5 + Sqrt[5]]*x*y + 
      226*Sqrt[5*(5 + Sqrt[5])]*x*y - 20*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      360*Sqrt[5 - Sqrt[5]]*x^2*y - 170*Sqrt[5 + Sqrt[5]]*x^2*y + 
      186*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 110*Sqrt[5 + Sqrt[5]]*x^3*y + 
      18*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 14*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      180*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 145*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      105*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 120*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      34*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      10*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 50*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      18*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 96*Sqrt[25 - 5*Sqrt[5]] - 
      224*Sqrt[5 - Sqrt[5]] - 352*Sqrt[5 + Sqrt[5]] + 
      192*Sqrt[5*(5 + Sqrt[5])] + 12*Sqrt[25 - 5*Sqrt[5]]*x - 
      60*Sqrt[5 - Sqrt[5]]*x - 76*Sqrt[5 + Sqrt[5]]*x + 
      68*Sqrt[5*(5 + Sqrt[5])]*x - 48*Sqrt[5 - Sqrt[5]]*x^2 - 
      72*Sqrt[5 + Sqrt[5]]*x^2 + 24*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      8*Sqrt[5 - Sqrt[5]]*x^3 - 20*Sqrt[5 + Sqrt[5]]*x^3 + 
      4*Sqrt[5*(5 + Sqrt[5])]*x^3 - 42*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      62*Sqrt[5 - Sqrt[5]]*x*y + 128*Sqrt[5 + Sqrt[5]]*x*y - 
      84*Sqrt[5*(5 + Sqrt[5])]*x*y - 40*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      120*Sqrt[5 - Sqrt[5]]*x^2*y + 228*Sqrt[5 + Sqrt[5]]*x^2*y - 
      92*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      18*Sqrt[5 - Sqrt[5]]*x^3*y + 64*Sqrt[5 + Sqrt[5]]*x^3*y - 
      20*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 38*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      82*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 160*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      72*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 
      20*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 77*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 
      29*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 5*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 
      9*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 34*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 
      14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 860*Sqrt[25 - 5*Sqrt[5]] - 
      344*Sqrt[5*(25 - 5*Sqrt[5])] + 3100*Sqrt[5 - Sqrt[5]] - 
      1240*Sqrt[5*(5 - Sqrt[5])] + 1640*Sqrt[5 + Sqrt[5]] - 
      720*Sqrt[5*(5 + Sqrt[5])] + 1800*Sqrt[25 - 5*Sqrt[5]]*x - 
      720*Sqrt[5*(25 - 5*Sqrt[5])]*x + 5400*Sqrt[5 - Sqrt[5]]*x - 
      2160*Sqrt[5*(5 - Sqrt[5])]*x + 1920*Sqrt[5 + Sqrt[5]]*x - 
      720*Sqrt[5*(5 + Sqrt[5])]*x + 520*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      208*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 1800*Sqrt[5 - Sqrt[5]]*x^2 - 
      720*Sqrt[5*(5 - Sqrt[5])]*x^2 + 1040*Sqrt[5 + Sqrt[5]]*x^2 - 
      400*Sqrt[5*(5 + Sqrt[5])]*x^2 + 20*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 + 100*Sqrt[5 - Sqrt[5]]*x^3 - 
      40*Sqrt[5*(5 - Sqrt[5])]*x^3 + 200*Sqrt[5 + Sqrt[5]]*x^3 - 
      80*Sqrt[5*(5 + Sqrt[5])]*x^3 - 1180*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      472*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 4500*Sqrt[5 - Sqrt[5]]*x*y + 
      1800*Sqrt[5*(5 - Sqrt[5])]*x*y - 2660*Sqrt[5 + Sqrt[5]]*x*y + 
      1060*Sqrt[5*(5 + Sqrt[5])]*x*y + 150*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      60*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 1250*Sqrt[5 - Sqrt[5]]*x^2*y + 
      500*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 2760*Sqrt[5 + Sqrt[5]]*x^2*y + 
      1140*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 150*Sqrt[5 - Sqrt[5]]*x^3*y + 
      60*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 730*Sqrt[5 + Sqrt[5]]*x^3*y + 
      310*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 320*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      128*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 + 200*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      80*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 1750*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      750*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 75*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      30*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 125*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      50*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 940*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      410*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      16*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      20*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 430*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      190*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, -44*Sqrt[25 - 5*Sqrt[5]] - 
      12*Sqrt[5 - Sqrt[5]] + 184*Sqrt[5 + Sqrt[5]] + 
      28*Sqrt[25 - 5*Sqrt[5]]*x - 12*Sqrt[5 - Sqrt[5]]*x + 
      76*Sqrt[5 + Sqrt[5]]*x + 76*Sqrt[5*(5 + Sqrt[5])]*x + 
      8*Sqrt[25 - 5*Sqrt[5]]*x^2 + 12*Sqrt[5 + Sqrt[5]]*x^2 + 
      20*Sqrt[5*(5 + Sqrt[5])]*x^2 - 10*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      14*Sqrt[5 - Sqrt[5]]*x*y - 72*Sqrt[5 + Sqrt[5]]*x*y - 
      52*Sqrt[5*(5 + Sqrt[5])]*x*y + 40*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      152*Sqrt[5 - Sqrt[5]]*x^2*y + 48*Sqrt[5 + Sqrt[5]]*x^2*y - 
      32*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 24*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      98*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 49*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      17*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, -160*Sqrt[25 - 5*Sqrt[5]] + 
      64*Sqrt[5*(25 - 5*Sqrt[5])] - 480*Sqrt[5 - Sqrt[5]] + 
      192*Sqrt[5*(5 - Sqrt[5])] + 80*Sqrt[5 + Sqrt[5]] + 
      16*Sqrt[5*(5 + Sqrt[5])] + 60*Sqrt[25 - 5*Sqrt[5]]*x - 
      24*Sqrt[5*(25 - 5*Sqrt[5])]*x + 100*Sqrt[5 - Sqrt[5]]*x - 
      40*Sqrt[5*(5 - Sqrt[5])]*x + 100*Sqrt[5 + Sqrt[5]]*x - 
      44*Sqrt[5*(5 + Sqrt[5])]*x - 40*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 80*Sqrt[5 - Sqrt[5]]*x^2 - 
      32*Sqrt[5*(5 - Sqrt[5])]*x^2 + 300*Sqrt[5 + Sqrt[5]]*x^2 - 
      156*Sqrt[5*(5 + Sqrt[5])]*x^2 - 20*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 - 20*Sqrt[5 - Sqrt[5]]*x^3 + 
      8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 80*Sqrt[5 + Sqrt[5]]*x^3 - 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3 + 10*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 50*Sqrt[5 - Sqrt[5]]*x*y + 
      20*Sqrt[5*(5 - Sqrt[5])]*x*y - 370*Sqrt[5 + Sqrt[5]]*x*y + 
      166*Sqrt[5*(5 + Sqrt[5])]*x*y + 280*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      112*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 220*Sqrt[5 - Sqrt[5]]*x^2*y - 
      88*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 910*Sqrt[5 + Sqrt[5]]*x^2*y + 
      430*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 30*Sqrt[5 - Sqrt[5]]*x^3*y + 
      12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 310*Sqrt[5 + Sqrt[5]]*x^3*y + 
      146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 180*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 - 110*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      44*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 725*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      329*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 75*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      30*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 410*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      188*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 - 40*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      16*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 190*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      86*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, -160*Sqrt[25 - 5*Sqrt[5]] + 
      64*Sqrt[5*(25 - 5*Sqrt[5])] - 480*Sqrt[5 - Sqrt[5]] + 
      192*Sqrt[5*(5 - Sqrt[5])] + 80*Sqrt[5 + Sqrt[5]] + 
      16*Sqrt[5*(5 + Sqrt[5])] - 100*Sqrt[25 - 5*Sqrt[5]]*x + 
      40*Sqrt[5*(25 - 5*Sqrt[5])]*x - 500*Sqrt[5 - Sqrt[5]]*x + 
      200*Sqrt[5*(5 - Sqrt[5])]*x - 320*Sqrt[5 + Sqrt[5]]*x + 
      136*Sqrt[5*(5 + Sqrt[5])]*x - 20*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 180*Sqrt[5 - Sqrt[5]]*x^2 - 
      72*Sqrt[5*(5 - Sqrt[5])]*x^2 + 420*Sqrt[5 + Sqrt[5]]*x^2 - 
      188*Sqrt[5*(5 + Sqrt[5])]*x^2 + 40*Sqrt[5 - Sqrt[5]]*x^3 - 
      16*Sqrt[5*(5 - Sqrt[5])]*x^3 + 140*Sqrt[5 + Sqrt[5]]*x^3 - 
      60*Sqrt[5*(5 + Sqrt[5])]*x^3 + 60*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      24*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 300*Sqrt[5 - Sqrt[5]]*x*y - 
      120*Sqrt[5*(5 - Sqrt[5])]*x*y + 240*Sqrt[5 + Sqrt[5]]*x*y - 
      104*Sqrt[5*(5 + Sqrt[5])]*x*y + 60*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      24*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 440*Sqrt[5 - Sqrt[5]]*x^2*y + 
      176*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 970*Sqrt[5 + Sqrt[5]]*x^2*y + 
      434*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 90*Sqrt[5 - Sqrt[5]]*x^3*y + 
      36*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 520*Sqrt[5 + Sqrt[5]]*x^3*y + 
      228*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 60*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      24*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 + 280*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      112*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 640*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      288*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 50*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      20*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      40*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 675*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      299*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 - 45*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      18*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 310*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      138*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, -160*Sqrt[25 - 5*Sqrt[5]] + 
      64*Sqrt[5*(25 - 5*Sqrt[5])] - 480*Sqrt[5 - Sqrt[5]] + 
      192*Sqrt[5*(5 - Sqrt[5])] + 80*Sqrt[5 + Sqrt[5]] + 
      16*Sqrt[5*(5 + Sqrt[5])] - 140*Sqrt[25 - 5*Sqrt[5]]*x + 
      56*Sqrt[5*(25 - 5*Sqrt[5])]*x - 700*Sqrt[5 - Sqrt[5]]*x + 
      280*Sqrt[5*(5 - Sqrt[5])]*x - 400*Sqrt[5 + Sqrt[5]]*x + 
      216*Sqrt[5*(5 + Sqrt[5])]*x - 140*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      56*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 220*Sqrt[5 - Sqrt[5]]*x^2 + 
      88*Sqrt[5*(5 - Sqrt[5])]*x^2 + 200*Sqrt[5 + Sqrt[5]]*x^2 - 
      96*Sqrt[5*(5 + Sqrt[5])]*x^2 - 20*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 - 20*Sqrt[5 - Sqrt[5]]*x^3 + 
      8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 80*Sqrt[5 + Sqrt[5]]*x^3 - 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3 - 70*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      28*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 230*Sqrt[5 - Sqrt[5]]*x*y - 
      92*Sqrt[5*(5 - Sqrt[5])]*x*y + 350*Sqrt[5 + Sqrt[5]]*x*y - 
      178*Sqrt[5*(5 + Sqrt[5])]*x*y + 120*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      48*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 140*Sqrt[5 - Sqrt[5]]*x^2*y - 
      56*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 410*Sqrt[5 + Sqrt[5]]*x^2*y + 
      194*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 30*Sqrt[5 - Sqrt[5]]*x^3*y + 
      12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 310*Sqrt[5 + Sqrt[5]]*x^3*y + 
      146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 20*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 + 10*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      4*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 255*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      115*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 75*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      30*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 410*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      188*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 - 40*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      16*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 190*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      86*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 140*Sqrt[25 - 5*Sqrt[5]] - 
      56*Sqrt[5*(25 - 5*Sqrt[5])] + 420*Sqrt[5 - Sqrt[5]] - 
      168*Sqrt[5*(5 - Sqrt[5])] + 260*Sqrt[5 + Sqrt[5]] - 
      124*Sqrt[5*(5 + Sqrt[5])] + 120*Sqrt[25 - 5*Sqrt[5]]*x - 
      48*Sqrt[5*(25 - 5*Sqrt[5])]*x + 520*Sqrt[5 - Sqrt[5]]*x - 
      208*Sqrt[5*(5 - Sqrt[5])]*x + 460*Sqrt[5 + Sqrt[5]]*x - 
      196*Sqrt[5*(5 + Sqrt[5])]*x + 20*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 100*Sqrt[5 - Sqrt[5]]*x^2 - 
      40*Sqrt[5*(5 - Sqrt[5])]*x^2 + 80*Sqrt[5 + Sqrt[5]]*x^2 - 
      32*Sqrt[5*(5 + Sqrt[5])]*x^2 - 30*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 510*Sqrt[5 - Sqrt[5]]*x*y + 
      204*Sqrt[5*(5 - Sqrt[5])]*x*y - 760*Sqrt[5 + Sqrt[5]]*x*y + 
      328*Sqrt[5*(5 + Sqrt[5])]*x*y - 10*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 150*Sqrt[5 - Sqrt[5]]*x^2*y + 
      60*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 180*Sqrt[5 + Sqrt[5]]*x^2*y + 
      76*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 5*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      2*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 + 75*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      30*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 120*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      52*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, -260*Sqrt[25 - 5*Sqrt[5]] + 
      104*Sqrt[5*(25 - 5*Sqrt[5])] - 900*Sqrt[5 - Sqrt[5]] + 
      360*Sqrt[5*(5 - Sqrt[5])] - 280*Sqrt[5 + Sqrt[5]] + 
      240*Sqrt[5*(5 + Sqrt[5])] + 120*Sqrt[25 - 5*Sqrt[5]]*x - 
      48*Sqrt[5*(25 - 5*Sqrt[5])]*x + 280*Sqrt[5 - Sqrt[5]]*x - 
      112*Sqrt[5*(5 - Sqrt[5])]*x + 280*Sqrt[5 + Sqrt[5]]*x - 
      72*Sqrt[5*(5 + Sqrt[5])]*x + 160*Sqrt[5 - Sqrt[5]]*x^2 - 
      64*Sqrt[5*(5 - Sqrt[5])]*x^2 + 400*Sqrt[5 + Sqrt[5]]*x^2 - 
      192*Sqrt[5*(5 + Sqrt[5])]*x^2 - 20*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 - 20*Sqrt[5 - Sqrt[5]]*x^3 + 
      8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 80*Sqrt[5 + Sqrt[5]]*x^3 - 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3 - 140*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      56*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 340*Sqrt[5 - Sqrt[5]]*x*y + 
      136*Sqrt[5*(5 - Sqrt[5])]*x*y - 300*Sqrt[5 + Sqrt[5]]*x*y + 
      124*Sqrt[5*(5 + Sqrt[5])]*x*y + 250*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      100*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 210*Sqrt[5 - Sqrt[5]]*x^2*y - 
      84*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 920*Sqrt[5 + Sqrt[5]]*x^2*y + 
      444*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 30*Sqrt[5 - Sqrt[5]]*x^3*y + 
      12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 310*Sqrt[5 + Sqrt[5]]*x^3*y + 
      146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 180*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 - 200*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      80*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 560*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      264*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 75*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      30*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 410*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      188*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 - 40*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      16*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 190*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      86*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 20*Sqrt[5 - Sqrt[5]] - 
      4*Sqrt[5*(5 - Sqrt[5])] + 60*Sqrt[5 + Sqrt[5]] - 
      12*Sqrt[5*(5 + Sqrt[5])] - 20*Sqrt[5 - Sqrt[5]]*x + 
      4*Sqrt[5*(5 - Sqrt[5])]*x - 40*Sqrt[5 + Sqrt[5]]*x + 
      8*Sqrt[5*(5 + Sqrt[5])]*x - 20*Sqrt[5 + Sqrt[5]]*x^2 + 
      4*Sqrt[5*(5 + Sqrt[5])]*x^2 + 30*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 90*Sqrt[5 - Sqrt[5]]*x*y - 
      36*Sqrt[5*(5 - Sqrt[5])]*x*y + 40*Sqrt[5 + Sqrt[5]]*x*y - 
      12*Sqrt[5*(5 + Sqrt[5])]*x*y + 40*Sqrt[5 + Sqrt[5]]*x^2*y - 
      12*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 25*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      9*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 40*Sqrt[5 - Sqrt[5]] - 
      8*Sqrt[5*(5 - Sqrt[5])] + 120*Sqrt[5 + Sqrt[5]] - 
      24*Sqrt[5*(5 + Sqrt[5])] - 40*Sqrt[5 - Sqrt[5]]*x + 
      8*Sqrt[5*(5 - Sqrt[5])]*x - 80*Sqrt[5 + Sqrt[5]]*x + 
      16*Sqrt[5*(5 + Sqrt[5])]*x - 40*Sqrt[5 + Sqrt[5]]*x^2 + 
      8*Sqrt[5*(5 + Sqrt[5])]*x^2 - 12*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      80*Sqrt[5 + Sqrt[5]]*x*y - 24*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      80*Sqrt[5 + Sqrt[5]]*x^2*y - 24*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      35*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 13*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 
     280*Sqrt[25 - 5*Sqrt[5]] - 112*Sqrt[5*(25 - 5*Sqrt[5])] + 
      600*Sqrt[5 - Sqrt[5]] - 240*Sqrt[5*(5 - Sqrt[5])] + 
      80*Sqrt[5 + Sqrt[5]] + 180*Sqrt[25 - 5*Sqrt[5]]*x - 
      72*Sqrt[5*(25 - 5*Sqrt[5])]*x + 820*Sqrt[5 - Sqrt[5]]*x - 
      328*Sqrt[5*(5 - Sqrt[5])]*x + 880*Sqrt[5 + Sqrt[5]]*x - 
      360*Sqrt[5*(5 + Sqrt[5])]*x - 60*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      24*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 100*Sqrt[5 - Sqrt[5]]*x^2 - 
      40*Sqrt[5*(5 - Sqrt[5])]*x^2 + 520*Sqrt[5 + Sqrt[5]]*x^2 - 
      240*Sqrt[5*(5 + Sqrt[5])]*x^2 - 20*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 - 20*Sqrt[5 - Sqrt[5]]*x^3 + 
      8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 80*Sqrt[5 + Sqrt[5]]*x^3 - 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3 - 290*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      116*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 1150*Sqrt[5 - Sqrt[5]]*x*y + 
      460*Sqrt[5*(5 - Sqrt[5])]*x*y - 1110*Sqrt[5 + Sqrt[5]]*x*y + 
      466*Sqrt[5*(5 + Sqrt[5])]*x*y + 100*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      40*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 360*Sqrt[5 - Sqrt[5]]*x^2*y + 
      144*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 1370*Sqrt[5 + Sqrt[5]]*x^2*y + 
      618*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 30*Sqrt[5 - Sqrt[5]]*x^3*y + 
      12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 310*Sqrt[5 + Sqrt[5]]*x^3*y + 
      146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 50*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      20*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 + 240*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      96*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 875*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      387*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 75*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      30*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 410*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      188*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 - 40*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      16*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 190*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      86*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 120*Sqrt[25 - 5*Sqrt[5]] - 
      48*Sqrt[5*(25 - 5*Sqrt[5])] + 840*Sqrt[5 - Sqrt[5]] - 
      336*Sqrt[5*(5 - Sqrt[5])] + 1000*Sqrt[5 + Sqrt[5]] - 
      408*Sqrt[5*(5 + Sqrt[5])] + 420*Sqrt[25 - 5*Sqrt[5]]*x - 
      168*Sqrt[5*(25 - 5*Sqrt[5])]*x + 540*Sqrt[5 - Sqrt[5]]*x - 
      216*Sqrt[5*(5 - Sqrt[5])]*x - 660*Sqrt[5 + Sqrt[5]]*x + 
      396*Sqrt[5*(5 + Sqrt[5])]*x + 40*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 280*Sqrt[5 - Sqrt[5]]*x^2 - 
      112*Sqrt[5*(5 - Sqrt[5])]*x^2 + 280*Sqrt[5 + Sqrt[5]]*x^2 - 
      88*Sqrt[5*(5 + Sqrt[5])]*x^2 + 40*Sqrt[5 - Sqrt[5]]*x^3 - 
      16*Sqrt[5*(5 - Sqrt[5])]*x^3 + 140*Sqrt[5 + Sqrt[5]]*x^3 - 
      60*Sqrt[5*(5 + Sqrt[5])]*x^3 - 370*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      148*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 370*Sqrt[5 - Sqrt[5]]*x*y + 
      148*Sqrt[5*(5 - Sqrt[5])]*x*y + 860*Sqrt[5 + Sqrt[5]]*x*y - 
      456*Sqrt[5*(5 + Sqrt[5])]*x*y + 100*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      40*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 20*Sqrt[5 - Sqrt[5]]*x^2*y + 
      8*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 280*Sqrt[5 + Sqrt[5]]*x^2*y + 
      88*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 90*Sqrt[5 - Sqrt[5]]*x^3*y + 
      36*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 520*Sqrt[5 + Sqrt[5]]*x^3*y + 
      228*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 50*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      20*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 - 150*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      60*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 - 130*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      66*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 50*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      20*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      40*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 675*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      299*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 - 45*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      18*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 310*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      138*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 60*Sqrt[25 - 5*Sqrt[5]] - 
      24*Sqrt[5*(25 - 5*Sqrt[5])] + 500*Sqrt[5 - Sqrt[5]] - 
      200*Sqrt[5*(5 - Sqrt[5])] + 740*Sqrt[5 + Sqrt[5]] - 
      300*Sqrt[5*(5 + Sqrt[5])] + 900*Sqrt[25 - 5*Sqrt[5]]*x - 
      360*Sqrt[5*(25 - 5*Sqrt[5])]*x + 2500*Sqrt[5 - Sqrt[5]]*x - 
      1000*Sqrt[5*(5 - Sqrt[5])]*x + 120*Sqrt[5 + Sqrt[5]]*x - 
      160*Sqrt[5*(5 + Sqrt[5])]*x + 420*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      168*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 1500*Sqrt[5 - Sqrt[5]]*x^2 - 
      600*Sqrt[5*(5 - Sqrt[5])]*x^2 + 540*Sqrt[5 + Sqrt[5]]*x^2 - 
      260*Sqrt[5*(5 + Sqrt[5])]*x^2 + 20*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 + 100*Sqrt[5 - Sqrt[5]]*x^3 - 
      40*Sqrt[5*(5 - Sqrt[5])]*x^3 + 200*Sqrt[5 + Sqrt[5]]*x^3 - 
      80*Sqrt[5*(5 + Sqrt[5])]*x^3 - 780*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      312*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 2200*Sqrt[5 - Sqrt[5]]*x*y + 
      880*Sqrt[5*(5 - Sqrt[5])]*x*y + 90*Sqrt[5 + Sqrt[5]]*x*y + 
      30*Sqrt[5*(5 + Sqrt[5])]*x*y + 200*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      80*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 900*Sqrt[5 - Sqrt[5]]*x^2*y + 
      360*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 1610*Sqrt[5 + Sqrt[5]]*x^2*y + 
      730*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 150*Sqrt[5 - Sqrt[5]]*x^3*y + 
      60*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 730*Sqrt[5 + Sqrt[5]]*x^3*y + 
      310*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 320*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      128*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 + 1050*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      470*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 75*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      30*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 125*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      50*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 940*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      410*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      16*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      20*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 430*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      190*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 216*Sqrt[(25 - 5*Sqrt[5])/5] - 
      108*Sqrt[25 - 5*Sqrt[5]] - 380*Sqrt[5 - Sqrt[5]] + 
      152*Sqrt[5*(5 - Sqrt[5])] - 152*Sqrt[5 + Sqrt[5]] + 
      96*Sqrt[5*(5 + Sqrt[5])] + 20*Sqrt[25 - 5*Sqrt[5]]*x - 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x - 20*Sqrt[5 - Sqrt[5]]*x + 
      8*Sqrt[5*(5 - Sqrt[5])]*x + 28*(5 + Sqrt[5])^(3/2)*x - 
      (56*(5 + Sqrt[5])^(3/2)*x)/Sqrt[5] + 112*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 
      56*Sqrt[25 - 5*Sqrt[5]]*x^2 + 80*Sqrt[5 - Sqrt[5]]*x^2 - 
      32*Sqrt[5*(5 - Sqrt[5])]*x^2 + 508*Sqrt[5 + Sqrt[5]]*x^2 - 
      236*Sqrt[5*(5 + Sqrt[5])]*x^2 + 32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 
      16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 120*Sqrt[5 + Sqrt[5]]*x^3 - 
      56*Sqrt[5*(5 + Sqrt[5])]*x^3 + 112*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 
      56*Sqrt[25 - 5*Sqrt[5]]*x*y + 20*Sqrt[5 - Sqrt[5]]*x*y - 
      8*Sqrt[5*(5 - Sqrt[5])]*x*y - 22*Sqrt[5 + Sqrt[5]]*x*y - 
      10*Sqrt[5*(5 + Sqrt[5])]*x*y + 390*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      156*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 550*Sqrt[5 - Sqrt[5]]*x^2*y - 
      220*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 972*Sqrt[5 + Sqrt[5]]*x^2*y + 
      456*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 
      36*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 60*Sqrt[5 - Sqrt[5]]*x^3*y + 
      24*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 456*Sqrt[5 + Sqrt[5]]*x^3*y + 
      208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 388*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*
       y^2 - 194*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 380*Sqrt[5 - Sqrt[5]]*x^2*
       y^2 + 152*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 385*Sqrt[5 + Sqrt[5]]*x^2*
       y^2 - 181*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^2 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 100*Sqrt[5 - Sqrt[5]]*x^3*
       y^2 - 40*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 598*Sqrt[5 + Sqrt[5]]*x^3*
       y^2 - 270*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 36*Sqrt[(25 - 5*Sqrt[5])/5]*
       x^3*y^3 + 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 50*Sqrt[5 - Sqrt[5]]*x^3*
       y^3 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 276*Sqrt[5 + Sqrt[5]]*x^3*
       y^3 + 124*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     536*Sqrt[(25 - 5*Sqrt[5])/5] - 268*Sqrt[25 - 5*Sqrt[5]] - 
      580*Sqrt[5 - Sqrt[5]] + 232*Sqrt[5*(5 - Sqrt[5])] + 
      108*Sqrt[5 + Sqrt[5]] - 4*Sqrt[5*(5 + Sqrt[5])] + 
      160*Sqrt[25 - 5*Sqrt[5]]*x - 64*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      160*Sqrt[5 - Sqrt[5]]*x + 64*Sqrt[5*(5 - Sqrt[5])]*x - 
      936*Sqrt[5 + Sqrt[5]]*x + 440*Sqrt[5*(5 + Sqrt[5])]*x + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 16*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      120*Sqrt[5 - Sqrt[5]]*x^2 - 48*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      188*Sqrt[5 + Sqrt[5]]*x^2 - 92*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      120*Sqrt[5 + Sqrt[5]]*x^3 - 56*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      492*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 246*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      50*Sqrt[5 - Sqrt[5]]*x*y - 20*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      1088*Sqrt[5 + Sqrt[5]]*x*y - 500*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      100*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 40*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      100*Sqrt[5 - Sqrt[5]]*x^2*y + 40*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      412*Sqrt[5 + Sqrt[5]]*x^2*y + 196*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 36*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      60*Sqrt[5 - Sqrt[5]]*x^3*y + 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      456*Sqrt[5 + Sqrt[5]]*x^3*y + 208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      128*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 64*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 50*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 20*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 265*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 121*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 598*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 270*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 18*Sqrt[25 - 5*Sqrt[5]]*
       x^3*y^3 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 - 276*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 124*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -464*Sqrt[(25 - 5*Sqrt[5])/5] + 232*Sqrt[25 - 5*Sqrt[5]] + 
      760*Sqrt[5 - Sqrt[5]] - 304*Sqrt[5*(5 - Sqrt[5])] + 
      368*Sqrt[5 + Sqrt[5]] - 192*Sqrt[5*(5 + Sqrt[5])] + 
      220*Sqrt[25 - 5*Sqrt[5]]*x - 88*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      900*Sqrt[5 - Sqrt[5]]*x - 360*Sqrt[5*(5 - Sqrt[5])]*x + 
      724*Sqrt[5 + Sqrt[5]]*x - 332*Sqrt[5*(5 + Sqrt[5])]*x - 
      128*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 + 64*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      280*Sqrt[5 - Sqrt[5]]*x^2 - 112*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      308*Sqrt[5 + Sqrt[5]]*x^2 - 132*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 4*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      40*Sqrt[5 + Sqrt[5]]*x^3 - 16*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 4*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      620*Sqrt[5 - Sqrt[5]]*x*y + 248*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      1072*Sqrt[5 + Sqrt[5]]*x*y + 480*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      30*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      450*Sqrt[5 - Sqrt[5]]*x^2*y + 180*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      802*Sqrt[5 + Sqrt[5]]*x^2*y + 350*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      146*Sqrt[5 + Sqrt[5]]*x^3*y + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      48*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 24*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      210*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 84*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      525*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 233*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      188*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 82*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      10*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     120*Sqrt[25 - 5*Sqrt[5]] - 344*Sqrt[5 - Sqrt[5]] - 
      432*Sqrt[5 + Sqrt[5]] + 224*Sqrt[5*(5 + Sqrt[5])] + 
      20*Sqrt[25 - 5*Sqrt[5]]*x - 100*Sqrt[5 - Sqrt[5]]*x - 
      76*Sqrt[5 + Sqrt[5]]*x + 68*Sqrt[5*(5 + Sqrt[5])]*x - 
      48*Sqrt[5 - Sqrt[5]]*x^2 - 72*Sqrt[5 + Sqrt[5]]*x^2 + 
      24*Sqrt[5*(5 + Sqrt[5])]*x^2 - 8*Sqrt[5 - Sqrt[5]]*x^3 - 
      20*Sqrt[5 + Sqrt[5]]*x^3 + 4*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      60*Sqrt[25 - 5*Sqrt[5]]*x*y + 192*Sqrt[5 - Sqrt[5]]*x*y + 
      198*Sqrt[5 + Sqrt[5]]*x*y - 110*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      34*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 110*Sqrt[5 - Sqrt[5]]*x^2*y + 
      208*Sqrt[5 + Sqrt[5]]*x^2*y - 84*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 18*Sqrt[5 - Sqrt[5]]*x^3*y + 
      64*Sqrt[5 + Sqrt[5]]*x^3*y - 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      32*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 72*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      150*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 66*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 20*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      77*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 29*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      5*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 9*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -104*Sqrt[(25 - 5*Sqrt[5])/5] + 52*Sqrt[25 - 5*Sqrt[5]] - 
      180*Sqrt[5 - Sqrt[5]] + 72*Sqrt[5*(5 - Sqrt[5])] - 
      412*Sqrt[5 + Sqrt[5]] + 196*Sqrt[5*(5 + Sqrt[5])] - 
      40*Sqrt[25 - 5*Sqrt[5]]*x + 16*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      40*Sqrt[5 - Sqrt[5]]*x - 16*Sqrt[5*(5 - Sqrt[5])]*x + 
      384*Sqrt[5 + Sqrt[5]]*x - 160*Sqrt[5*(5 + Sqrt[5])]*x + 
      192*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 96*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      40*Sqrt[5 - Sqrt[5]]*x^2 - 16*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      588*Sqrt[5 + Sqrt[5]]*x^2 - 268*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      120*Sqrt[5 + Sqrt[5]]*x^3 - 56*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      68*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 34*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      10*Sqrt[5 - Sqrt[5]]*x*y - 4*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      312*Sqrt[5 + Sqrt[5]]*x*y + 132*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      140*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 56*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      300*Sqrt[5 - Sqrt[5]]*x^2*y + 120*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      1412*Sqrt[5 + Sqrt[5]]*x^2*y + 636*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 36*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      60*Sqrt[5 - Sqrt[5]]*x^3*y + 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      456*Sqrt[5 + Sqrt[5]]*x^3*y + 208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      128*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 64*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 210*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 84*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 825*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 369*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 598*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 270*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 18*Sqrt[25 - 5*Sqrt[5]]*
       x^3*y^3 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 - 276*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 124*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -224*Sqrt[(25 - 5*Sqrt[5])/5] + 112*Sqrt[25 - 5*Sqrt[5]] + 
      720*Sqrt[5 - Sqrt[5]] - 288*Sqrt[5*(5 - Sqrt[5])] + 
      728*Sqrt[5 + Sqrt[5]] - 344*Sqrt[5*(5 + Sqrt[5])] + 
      60*Sqrt[25 - 5*Sqrt[5]]*x - 24*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      220*Sqrt[5 - Sqrt[5]]*x + 88*Sqrt[5*(5 - Sqrt[5])]*x - 
      636*Sqrt[5 + Sqrt[5]]*x + 292*Sqrt[5*(5 + Sqrt[5])]*x + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 16*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      40*Sqrt[5 - Sqrt[5]]*x^2 + 16*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      52*Sqrt[5 + Sqrt[5]]*x^2 + 36*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 4*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      40*Sqrt[5 + Sqrt[5]]*x^3 - 16*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      152*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 76*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      20*Sqrt[5 - Sqrt[5]]*x*y - 8*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      368*Sqrt[5 + Sqrt[5]]*x*y - 176*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      130*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 52*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      550*Sqrt[5 - Sqrt[5]]*x^2*y - 220*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      538*Sqrt[5 + Sqrt[5]]*x^2*y - 238*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      146*Sqrt[5 + Sqrt[5]]*x^3*y + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      88*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 44*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      390*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 156*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 - 
      545*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 237*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      188*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 82*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      10*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     736*Sqrt[(25 - 5*Sqrt[5])/5] - 368*Sqrt[25 - 5*Sqrt[5]] - 
      1200*Sqrt[5 - Sqrt[5]] + 480*Sqrt[5*(5 - Sqrt[5])] - 
      472*Sqrt[5 + Sqrt[5]] + 280*Sqrt[5*(5 + Sqrt[5])] + 
      60*Sqrt[25 - 5*Sqrt[5]]*x - 24*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      100*Sqrt[5 - Sqrt[5]]*x - 40*Sqrt[5*(5 - Sqrt[5])]*x - 
      36*Sqrt[5 + Sqrt[5]]*x + 28*Sqrt[5*(5 + Sqrt[5])]*x - 
      48*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 + 24*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      40*Sqrt[5 - Sqrt[5]]*x^2 - 16*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      72*Sqrt[5 + Sqrt[5]]*x^2 + 8*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 16*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      40*Sqrt[5 - Sqrt[5]]*x^3 + 16*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      20*Sqrt[5 + Sqrt[5]]*x^3 + 4*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      392*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 196*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      320*Sqrt[5 - Sqrt[5]]*x*y + 128*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      198*Sqrt[5 + Sqrt[5]]*x*y - 94*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      170*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 68*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      450*Sqrt[5 - Sqrt[5]]*x^2*y - 180*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      188*Sqrt[5 + Sqrt[5]]*x^2*y - 48*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      64*Sqrt[5 + Sqrt[5]]*x^3*y - 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      208*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 104*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 300*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 120*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 120*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 44*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 77*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 29*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 14*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 7*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 - 5*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 2*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     136*Sqrt[(25 - 5*Sqrt[5])/5] - 68*Sqrt[25 - 5*Sqrt[5]] - 
      220*Sqrt[5 - Sqrt[5]] + 88*Sqrt[5*(5 - Sqrt[5])] - 
      52*Sqrt[5 + Sqrt[5]] + 44*Sqrt[5*(5 + Sqrt[5])] - 
      100*Sqrt[25 - 5*Sqrt[5]]*x + 40*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      420*Sqrt[5 - Sqrt[5]]*x + 168*Sqrt[5*(5 - Sqrt[5])]*x - 
      136*Sqrt[5 + Sqrt[5]]*x + 112*Sqrt[5*(5 + Sqrt[5])]*x + 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 36*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      60*Sqrt[5 - Sqrt[5]]*x^2 + 24*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      148*Sqrt[5 + Sqrt[5]]*x^2 - 44*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 4*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      40*Sqrt[5 + Sqrt[5]]*x^3 - 16*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      128*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 64*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      380*Sqrt[5 - Sqrt[5]]*x*y - 152*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      158*Sqrt[5 + Sqrt[5]]*x*y - 110*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      60*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 24*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      80*Sqrt[5 - Sqrt[5]]*x^2*y - 32*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      362*Sqrt[5 + Sqrt[5]]*x^2*y + 130*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      146*Sqrt[5 + Sqrt[5]]*x^3*y + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      48*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 24*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      250*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 102*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      188*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 82*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      10*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -104*Sqrt[(25 - 5*Sqrt[5])/5] + 52*Sqrt[25 - 5*Sqrt[5]] + 
      260*Sqrt[5 - Sqrt[5]] - 104*Sqrt[5*(5 - Sqrt[5])] + 
      248*Sqrt[5 + Sqrt[5]] - 112*Sqrt[5*(5 + Sqrt[5])] + 
      180*Sqrt[25 - 5*Sqrt[5]]*x - 72*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      140*Sqrt[5 - Sqrt[5]]*x - 56*Sqrt[5*(5 - Sqrt[5])]*x - 
      556*Sqrt[5 + Sqrt[5]]*x + 260*Sqrt[5*(5 + Sqrt[5])]*x + 
      112*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 56*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      80*Sqrt[5 - Sqrt[5]]*x^2 - 32*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      268*Sqrt[5 + Sqrt[5]]*x^2 - 124*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 16*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      120*Sqrt[5 + Sqrt[5]]*x^3 - 56*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      192*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 96*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      100*Sqrt[5 - Sqrt[5]]*x*y + 40*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      378*Sqrt[5 + Sqrt[5]]*x*y - 170*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      110*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 44*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      210*Sqrt[5 - Sqrt[5]]*x^2*y + 84*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      652*Sqrt[5 + Sqrt[5]]*x^2*y + 296*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      72*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 36*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      60*Sqrt[5 - Sqrt[5]]*x^3*y + 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      456*Sqrt[5 + Sqrt[5]]*x^3*y + 208*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      148*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 74*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 + 140*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 56*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 485*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 217*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 598*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 270*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 18*Sqrt[25 - 5*Sqrt[5]]*
       x^3*y^3 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 - 276*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 124*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -32*Sqrt[(25 - 5*Sqrt[5])/5] + 16*Sqrt[25 - 5*Sqrt[5]] - 
      80*Sqrt[5 - Sqrt[5]] + 32*Sqrt[5*(5 - Sqrt[5])] - 
      176*Sqrt[5 + Sqrt[5]] + 96*Sqrt[5*(5 + Sqrt[5])] - 
      20*Sqrt[25 - 5*Sqrt[5]]*x + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      140*Sqrt[5 - Sqrt[5]]*x + 56*Sqrt[5*(5 - Sqrt[5])]*x - 
      188*Sqrt[5 + Sqrt[5]]*x + 84*Sqrt[5*(5 + Sqrt[5])]*x + 
      96*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 48*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      184*Sqrt[5 + Sqrt[5]]*x^2 - 88*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      60*Sqrt[5 + Sqrt[5]]*x^3 - 28*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      44*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 22*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      230*Sqrt[5 - Sqrt[5]]*x*y - 92*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      324*Sqrt[5 + Sqrt[5]]*x*y - 144*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      60*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 24*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      100*Sqrt[5 - Sqrt[5]]*x^2*y + 40*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      416*Sqrt[5 + Sqrt[5]]*x^2*y + 192*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      228*Sqrt[5 + Sqrt[5]]*x^3*y + 104*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      44*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 22*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      70*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 28*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      220*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 100*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      50*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      299*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 135*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      18*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 9*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      138*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -344*Sqrt[(25 - 5*Sqrt[5])/5] + 172*Sqrt[25 - 5*Sqrt[5]] + 
      620*Sqrt[5 - Sqrt[5]] - 248*Sqrt[5*(5 - Sqrt[5])] + 
      328*Sqrt[5 + Sqrt[5]] - 144*Sqrt[5*(5 + Sqrt[5])] - 
      120*Sqrt[25 - 5*Sqrt[5]]*x + 48*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      520*Sqrt[5 - Sqrt[5]]*x + 208*Sqrt[5*(5 - Sqrt[5])]*x - 
      416*Sqrt[5 + Sqrt[5]]*x + 176*Sqrt[5*(5 + Sqrt[5])]*x + 
      112*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 56*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      120*Sqrt[5 - Sqrt[5]]*x^2 + 48*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      48*Sqrt[5 + Sqrt[5]]*x^2 - 16*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 4*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      40*Sqrt[5 + Sqrt[5]]*x^3 - 16*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 6*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      130*Sqrt[5 - Sqrt[5]]*x*y - 52*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      228*Sqrt[5 + Sqrt[5]]*x*y - 104*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      190*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 76*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      650*Sqrt[5 - Sqrt[5]]*x^2*y - 260*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      278*Sqrt[5 + Sqrt[5]]*x^2*y - 114*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      146*Sqrt[5 + Sqrt[5]]*x^3*y + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      128*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 64*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 420*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 168*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 390*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 166*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 + 25*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 188*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 82*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 - 16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 - 10*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     496*Sqrt[(25 - 5*Sqrt[5])/5] - 248*Sqrt[25 - 5*Sqrt[5]] - 
      840*Sqrt[5 - Sqrt[5]] + 336*Sqrt[5*(5 - Sqrt[5])] - 
      392*Sqrt[5 + Sqrt[5]] + 248*Sqrt[5*(5 + Sqrt[5])] + 
      100*Sqrt[25 - 5*Sqrt[5]]*x - 40*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      220*Sqrt[5 - Sqrt[5]]*x - 88*Sqrt[5*(5 - Sqrt[5])]*x - 
      36*Sqrt[5 + Sqrt[5]]*x + 28*Sqrt[5*(5 + Sqrt[5])]*x - 
      48*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 + 24*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      40*Sqrt[5 - Sqrt[5]]*x^2 - 16*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      72*Sqrt[5 + Sqrt[5]]*x^2 + 8*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 16*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      40*Sqrt[5 - Sqrt[5]]*x^3 + 16*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      20*Sqrt[5 + Sqrt[5]]*x^3 + 4*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      452*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 226*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      470*Sqrt[5 - Sqrt[5]]*x*y + 188*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      58*Sqrt[5 + Sqrt[5]]*x*y - 46*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      170*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 68*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      470*Sqrt[5 - Sqrt[5]]*x^2*y - 188*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      218*Sqrt[5 + Sqrt[5]]*x^2*y - 62*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      64*Sqrt[5 + Sqrt[5]]*x^3*y - 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      188*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 94*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 290*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 116*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 150*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 58*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 + 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 77*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 29*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 14*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 7*Sqrt[25 - 5*Sqrt[5]]*x^3*
       y^3 - 5*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 2*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     16*Sqrt[(25 - 5*Sqrt[5])/5] - 8*Sqrt[25 - 5*Sqrt[5]] + 
      120*Sqrt[5 - Sqrt[5]] - 48*Sqrt[5*(5 - Sqrt[5])] + 
      208*Sqrt[5 + Sqrt[5]] - 64*Sqrt[5*(5 + Sqrt[5])] + 
      100*Sqrt[25 - 5*Sqrt[5]]*x - 40*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      60*Sqrt[5 - Sqrt[5]]*x + 24*Sqrt[5*(5 - Sqrt[5])]*x - 
      416*Sqrt[5 + Sqrt[5]]*x + 264*Sqrt[5*(5 + Sqrt[5])]*x - 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 + 4*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      20*Sqrt[5 - Sqrt[5]]*x^2 - 8*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      48*Sqrt[5 + Sqrt[5]]*x^2 + 8*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 4*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      40*Sqrt[5 + Sqrt[5]]*x^3 - 16*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      192*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 96*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      120*Sqrt[5 - Sqrt[5]]*x*y - 48*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      528*Sqrt[5 + Sqrt[5]]*x*y - 296*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      30*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      50*Sqrt[5 - Sqrt[5]]*x^2*y - 20*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      102*Sqrt[5 + Sqrt[5]]*x^2*y + 2*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      146*Sqrt[5 + Sqrt[5]]*x^3*y + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      28*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 14*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      20*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 8*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      75*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 19*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      188*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 82*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      10*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     96*Sqrt[25 - 5*Sqrt[5]] + 240*Sqrt[5 - Sqrt[5]] + 
      8*(5 + Sqrt[5])^(3/2) + 100*Sqrt[25 - 5*Sqrt[5]]*x + 
      260*Sqrt[5 - Sqrt[5]]*x + 200*Sqrt[5 + Sqrt[5]]*x + 
      64*Sqrt[5*(5 + Sqrt[5])]*x - 28*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      60*Sqrt[5 - Sqrt[5]]*x^2 + 140*Sqrt[5 + Sqrt[5]]*x^2 - 
      52*Sqrt[5*(5 + Sqrt[5])]*x^2 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      20*Sqrt[5 + Sqrt[5]]*x^3 - 20*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      2*Sqrt[25 - 5*Sqrt[5]]*x*y - 130*Sqrt[5 - Sqrt[5]]*x*y - 
      190*Sqrt[5 + Sqrt[5]]*x*y + 18*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      70*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 150*Sqrt[5 - Sqrt[5]]*x^2*y - 
      350*Sqrt[5 + Sqrt[5]]*x^2*y + 138*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      18*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 30*Sqrt[5 - Sqrt[5]]*x^3*y - 
      100*Sqrt[5 + Sqrt[5]]*x^3*y + 64*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      52*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 100*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      240*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 100*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 50*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 
      145*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 77*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      9*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 25*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 
      70*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 34*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -64*Sqrt[(25 - 5*Sqrt[5])/5] + 32*Sqrt[25 - 5*Sqrt[5]] - 
      160*Sqrt[5 - Sqrt[5]] + 64*Sqrt[5*(5 - Sqrt[5])] - 
      352*Sqrt[5 + Sqrt[5]] + 192*Sqrt[5*(5 + Sqrt[5])] - 
      60*Sqrt[25 - 5*Sqrt[5]]*x + 24*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      180*Sqrt[5 - Sqrt[5]]*x + 72*Sqrt[5*(5 - Sqrt[5])]*x - 
      76*Sqrt[5 + Sqrt[5]]*x + 68*Sqrt[5*(5 + Sqrt[5])]*x + 
      192*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 96*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      240*Sqrt[5 - Sqrt[5]]*x^2 + 96*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      24*(5 + Sqrt[5])^(3/2)*x^2 + (48*(5 + Sqrt[5])^(3/2)*x^2)/Sqrt[5] + 
      32*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 16*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      40*Sqrt[5 - Sqrt[5]]*x^3 + 16*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      20*Sqrt[5 + Sqrt[5]]*x^3 + 4*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      148*Sqrt[(25 - 5*Sqrt[5])/5]*x*y + 74*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      310*Sqrt[5 - Sqrt[5]]*x*y - 124*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      258*Sqrt[5 + Sqrt[5]]*x*y - 126*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      50*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 20*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      190*Sqrt[5 - Sqrt[5]]*x^2*y - 76*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      178*Sqrt[5 + Sqrt[5]]*x^2*y - 70*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 
      30*Sqrt[5 - Sqrt[5]]*x^3*y - 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      64*Sqrt[5 + Sqrt[5]]*x^3*y - 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 + 6*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      50*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 20*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 - 
      120*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 52*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      77*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 29*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      14*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 - 7*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      5*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 2*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 + 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^3 - 14*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     960*Sqrt[25 - 5*Sqrt[5]] - 384*Sqrt[5*(25 - 5*Sqrt[5])] + 
      2400*Sqrt[5 - Sqrt[5]] - 960*Sqrt[5*(5 - Sqrt[5])] + 
      80*(5 + Sqrt[5])^(3/2) - 32*Sqrt[5]*(5 + Sqrt[5])^(3/2) + 
      300*Sqrt[25 - 5*Sqrt[5]]*x - 120*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      1900*Sqrt[5 - Sqrt[5]]*x - 760*Sqrt[5*(5 - Sqrt[5])]*x + 
      1520*Sqrt[5 + Sqrt[5]]*x - 920*Sqrt[5*(5 + Sqrt[5])]*x + 
      220*Sqrt[25 - 5*Sqrt[5]]*x^2 - 88*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      1100*Sqrt[5 - Sqrt[5]]*x^2 - 440*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      1040*Sqrt[5 + Sqrt[5]]*x^2 - 520*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3 - 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 + 
      100*Sqrt[5 - Sqrt[5]]*x^3 - 40*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      200*Sqrt[5 + Sqrt[5]]*x^3 - 80*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      180*Sqrt[25 - 5*Sqrt[5]]*x*y + 72*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 
      1900*Sqrt[5 - Sqrt[5]]*x*y + 760*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      2160*Sqrt[5 + Sqrt[5]]*x*y + 1120*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      350*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 140*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      750*Sqrt[5 - Sqrt[5]]*x^2*y + 300*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      2910*Sqrt[5 + Sqrt[5]]*x^2*y + 1370*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 
      150*Sqrt[5 - Sqrt[5]]*x^3*y + 60*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      730*Sqrt[5 + Sqrt[5]]*x^3*y + 310*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      370*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 148*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 100*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 40*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 1925*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 885*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 75*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 30*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 125*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 50*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 940*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 410*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 40*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 16*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 50*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 20*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 - 430*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 190*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, 8*Sqrt[(25 - 5*Sqrt[5])/5] - 4*Sqrt[25 - 5*Sqrt[5]] + 
      60*Sqrt[5 - Sqrt[5]] - 24*Sqrt[5*(5 - Sqrt[5])] + 
      104*Sqrt[5 + Sqrt[5]] - 32*Sqrt[5*(5 + Sqrt[5])] + 
      40*Sqrt[25 - 5*Sqrt[5]]*x - 16*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      80*Sqrt[5 - Sqrt[5]]*x + 32*Sqrt[5*(5 - Sqrt[5])]*x - 
      308*Sqrt[5 + Sqrt[5]]*x + 132*Sqrt[5*(5 + Sqrt[5])]*x + 
      56*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 28*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      20*Sqrt[5 - Sqrt[5]]*x^2 - 8*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      144*Sqrt[5 + Sqrt[5]]*x^2 - 72*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      60*Sqrt[5 + Sqrt[5]]*x^3 - 28*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      196*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 98*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      10*Sqrt[5 - Sqrt[5]]*x*y + 4*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      364*Sqrt[5 + Sqrt[5]]*x*y - 168*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      180*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 72*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      320*Sqrt[5 - Sqrt[5]]*x^2*y - 128*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      186*Sqrt[5 + Sqrt[5]]*x^2*y + 98*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      228*Sqrt[5 + Sqrt[5]]*x^3*y + 104*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      164*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 82*Sqrt[25 - 5*Sqrt[5]]*x^2*
       y^2 - 220*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 88*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 5*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 3*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      50*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      299*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 135*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      18*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 9*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      138*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     248*Sqrt[(25 - 5*Sqrt[5])/5] - 124*Sqrt[25 - 5*Sqrt[5]] - 
      420*Sqrt[5 - Sqrt[5]] + 168*Sqrt[5*(5 - Sqrt[5])] - 
      196*Sqrt[5 + Sqrt[5]] + 124*Sqrt[5*(5 + Sqrt[5])] + 
      60*Sqrt[25 - 5*Sqrt[5]]*x - 24*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      20*Sqrt[5 - Sqrt[5]]*x - 8*Sqrt[5*(5 - Sqrt[5])]*x - 
      148*Sqrt[5 + Sqrt[5]]*x + 92*Sqrt[5*(5 + Sqrt[5])]*x + 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 - 8*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      80*Sqrt[5 - Sqrt[5]]*x^2 - 32*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      204*Sqrt[5 + Sqrt[5]]*x^2 - 92*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 - 8*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      60*Sqrt[5 + Sqrt[5]]*x^3 - 28*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      296*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 148*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      180*Sqrt[5 - Sqrt[5]]*x*y + 72*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      204*Sqrt[5 + Sqrt[5]]*x*y - 108*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      60*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 24*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      100*Sqrt[5 - Sqrt[5]]*x^2*y + 40*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      496*Sqrt[5 + Sqrt[5]]*x^2*y + 224*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      36*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 18*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      228*Sqrt[5 + Sqrt[5]]*x^3*y + 104*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      84*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 42*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      60*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 24*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      325*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 145*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      50*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 20*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      299*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 135*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      18*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 9*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      138*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -344*Sqrt[(25 - 5*Sqrt[5])/5] + 172*Sqrt[25 - 5*Sqrt[5]] + 
      620*Sqrt[5 - Sqrt[5]] - 248*Sqrt[5*(5 - Sqrt[5])] + 
      328*Sqrt[5 + Sqrt[5]] - 144*Sqrt[5*(5 + Sqrt[5])] + 
      360*Sqrt[25 - 5*Sqrt[5]]*x - 144*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      1080*Sqrt[5 - Sqrt[5]]*x - 432*Sqrt[5*(5 - Sqrt[5])]*x + 
      384*Sqrt[5 + Sqrt[5]]*x - 144*Sqrt[5*(5 + Sqrt[5])]*x - 
      208*Sqrt[(25 - 5*Sqrt[5])/5]*x^2 + 104*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      360*Sqrt[5 - Sqrt[5]]*x^2 - 144*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      208*Sqrt[5 + Sqrt[5]]*x^2 - 80*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^3 + 4*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      20*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      40*Sqrt[5 + Sqrt[5]]*x^3 - 16*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      212*Sqrt[(25 - 5*Sqrt[5])/5]*x*y - 106*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      690*Sqrt[5 - Sqrt[5]]*x*y + 276*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      652*Sqrt[5 + Sqrt[5]]*x*y + 272*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      90*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 36*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 
      550*Sqrt[5 - Sqrt[5]]*x^2*y + 220*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      542*Sqrt[5 + Sqrt[5]]*x^2*y + 226*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      12*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y + 6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      146*Sqrt[5 + Sqrt[5]]*x^3*y + 62*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      8*Sqrt[(25 - 5*Sqrt[5])/5]*x^2*y^2 - 4*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      240*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 96*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      370*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 162*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      15*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      25*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 10*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      188*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 82*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      16*Sqrt[(25 - 5*Sqrt[5])/5]*x^3*y^3 + 8*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      10*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 4*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      86*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 38*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -160*Sqrt[25 - 5*Sqrt[5]] + 64*Sqrt[5*(25 - 5*Sqrt[5])] - 
      480*Sqrt[5 - Sqrt[5]] + 192*Sqrt[5*(5 - Sqrt[5])] + 
      80*Sqrt[5 + Sqrt[5]] + 16*Sqrt[5*(5 + Sqrt[5])] - 
      140*Sqrt[25 - 5*Sqrt[5]]*x + 56*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      700*Sqrt[5 - Sqrt[5]]*x + 280*Sqrt[5*(5 - Sqrt[5])]*x - 
      400*Sqrt[5 + Sqrt[5]]*x + 216*Sqrt[5*(5 + Sqrt[5])]*x - 
      140*Sqrt[25 - 5*Sqrt[5]]*x^2 + 56*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      220*Sqrt[5 - Sqrt[5]]*x^2 + 88*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      200*Sqrt[5 + Sqrt[5]]*x^2 - 96*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 - 
      20*Sqrt[5 - Sqrt[5]]*x^3 + 8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      80*Sqrt[5 + Sqrt[5]]*x^3 - 40*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      60*Sqrt[25 - 5*Sqrt[5]]*x*y - 24*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 
      700*Sqrt[5 - Sqrt[5]]*x*y - 280*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      780*Sqrt[5 + Sqrt[5]]*x*y - 364*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      130*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 52*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      70*Sqrt[5 - Sqrt[5]]*x^2*y - 28*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      410*Sqrt[5 + Sqrt[5]]*x^2*y + 190*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      310*Sqrt[5 + Sqrt[5]]*x^3*y + 146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      30*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      40*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 16*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      175*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 79*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      75*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 30*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      410*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 188*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      40*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      190*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 86*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -160*Sqrt[25 - 5*Sqrt[5]] + 64*Sqrt[5*(25 - 5*Sqrt[5])] - 
      480*Sqrt[5 - Sqrt[5]] + 192*Sqrt[5*(5 - Sqrt[5])] + 
      80*Sqrt[5 + Sqrt[5]] + 16*Sqrt[5*(5 + Sqrt[5])] - 
      100*Sqrt[25 - 5*Sqrt[5]]*x + 40*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      500*Sqrt[5 - Sqrt[5]]*x + 200*Sqrt[5*(5 - Sqrt[5])]*x - 
      320*Sqrt[5 + Sqrt[5]]*x + 136*Sqrt[5*(5 + Sqrt[5])]*x - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^2 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      180*Sqrt[5 - Sqrt[5]]*x^2 - 72*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      420*Sqrt[5 + Sqrt[5]]*x^2 - 188*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      40*Sqrt[5 - Sqrt[5]]*x^3 - 16*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      140*Sqrt[5 + Sqrt[5]]*x^3 - 60*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      90*Sqrt[25 - 5*Sqrt[5]]*x*y + 36*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 
      250*Sqrt[5 - Sqrt[5]]*x*y - 100*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      490*Sqrt[5 + Sqrt[5]]*x*y - 214*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      210*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 84*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      110*Sqrt[5 - Sqrt[5]]*x^2*y - 44*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      870*Sqrt[5 + Sqrt[5]]*x^2*y + 394*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 
      90*Sqrt[5 - Sqrt[5]]*x^3*y + 36*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      520*Sqrt[5 + Sqrt[5]]*x^3*y + 228*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      110*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 44*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 170*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 68*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 + 390*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 178*Sqrt[5*(5 + Sqrt[5])]*x^2*
       y^2 - 50*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 20*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 40*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^2 + 675*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 299*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^2 + 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 10*Sqrt[5*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 45*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 18*Sqrt[5*(5 - Sqrt[5])]*x^3*
       y^3 - 310*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 138*Sqrt[5*(5 + Sqrt[5])]*x^3*
       y^3, -160*Sqrt[25 - 5*Sqrt[5]] + 64*Sqrt[5*(25 - 5*Sqrt[5])] - 
      480*Sqrt[5 - Sqrt[5]] + 192*Sqrt[5*(5 - Sqrt[5])] + 
      80*Sqrt[5 + Sqrt[5]] + 16*Sqrt[5*(5 + Sqrt[5])] + 
      60*Sqrt[25 - 5*Sqrt[5]]*x - 24*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      100*Sqrt[5 - Sqrt[5]]*x - 40*Sqrt[5*(5 - Sqrt[5])]*x + 
      100*Sqrt[5 + Sqrt[5]]*x - 44*Sqrt[5*(5 + Sqrt[5])]*x - 
      40*Sqrt[25 - 5*Sqrt[5]]*x^2 + 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 
      80*Sqrt[5 - Sqrt[5]]*x^2 - 32*Sqrt[5*(5 - Sqrt[5])]*x^2 + 
      300*Sqrt[5 + Sqrt[5]]*x^2 - 156*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      20*Sqrt[25 - 5*Sqrt[5]]*x^3 + 8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 - 
      20*Sqrt[5 - Sqrt[5]]*x^3 + 8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 
      80*Sqrt[5 + Sqrt[5]]*x^3 - 40*Sqrt[5*(5 + Sqrt[5])]*x^3 - 
      170*Sqrt[25 - 5*Sqrt[5]]*x*y + 68*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 
      370*Sqrt[5 - Sqrt[5]]*x*y + 148*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      100*Sqrt[5 + Sqrt[5]]*x*y + 32*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      270*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 108*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      390*Sqrt[5 - Sqrt[5]]*x^2*y - 156*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 
      360*Sqrt[5 + Sqrt[5]]*x^2*y + 204*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 
      30*Sqrt[5 - Sqrt[5]]*x^3*y + 12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 
      310*Sqrt[5 + Sqrt[5]]*x^3*y + 146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      120*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 48*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 290*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 116*Sqrt[5*(5 - Sqrt[5])]*x^2*
       y^2 - 45*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 5*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      75*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 30*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 
      410*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 188*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 - 
      40*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 16*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 
      190*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 86*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -220*Sqrt[25 - 5*Sqrt[5]] + 88*Sqrt[5*(25 - 5*Sqrt[5])] - 
      60*Sqrt[5 - Sqrt[5]] + 24*Sqrt[5*(5 - Sqrt[5])] + 
      920*Sqrt[5 + Sqrt[5]] - 368*Sqrt[5*(5 + Sqrt[5])] + 
      140*Sqrt[25 - 5*Sqrt[5]]*x - 56*Sqrt[5*(25 - 5*Sqrt[5])]*x - 
      60*Sqrt[5 - Sqrt[5]]*x + 24*Sqrt[5*(5 - Sqrt[5])]*x - 
      380*Sqrt[5 + Sqrt[5]]*x + 228*Sqrt[5*(5 + Sqrt[5])]*x + 
      40*Sqrt[25 - 5*Sqrt[5]]*x^2 - 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      140*Sqrt[5 + Sqrt[5]]*x^2 + 76*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      260*Sqrt[25 - 5*Sqrt[5]]*x*y + 104*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 
      120*Sqrt[5 - Sqrt[5]]*x*y + 48*Sqrt[5*(5 - Sqrt[5])]*x*y + 
      530*Sqrt[5 + Sqrt[5]]*x*y - 274*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      70*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 28*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 
      50*Sqrt[5 - Sqrt[5]]*x^2*y - 20*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      340*Sqrt[5 + Sqrt[5]]*x^2*y - 168*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      40*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      50*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 20*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 - 
      235*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 111*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 
     14*Sqrt[25 - 5*Sqrt[5]] + 42*Sqrt[5 - Sqrt[5]] + 6*Sqrt[5 + Sqrt[5]] - 
      10*Sqrt[5*(5 + Sqrt[5])] + 12*Sqrt[25 - 5*Sqrt[5]]*x + 
      52*Sqrt[5 - Sqrt[5]]*x + 34*Sqrt[5 + Sqrt[5]]*x - 
      6*Sqrt[5*(5 + Sqrt[5])]*x + 2*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      10*Sqrt[5 - Sqrt[5]]*x^2 + 8*Sqrt[5 + Sqrt[5]]*x^2 - 
      34*Sqrt[5 - Sqrt[5]]*x*y - 38*Sqrt[5 + Sqrt[5]]*x*y + 
      12*Sqrt[5*(5 + Sqrt[5])]*x*y - 12*Sqrt[5 - Sqrt[5]]*x^2*y - 
      18*Sqrt[5 + Sqrt[5]]*x^2*y + 2*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 3*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      9*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 2*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 
     56*Sqrt[25 - 5*Sqrt[5]] + 120*Sqrt[5 - Sqrt[5]] + 80*Sqrt[5 + Sqrt[5]] + 
      32*Sqrt[5*(5 + Sqrt[5])] + 36*Sqrt[25 - 5*Sqrt[5]]*x + 
      164*Sqrt[5 - Sqrt[5]]*x + 160*Sqrt[5 + Sqrt[5]]*x - 
      8*Sqrt[5*(5 + Sqrt[5])]*x - 12*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      20*Sqrt[5 - Sqrt[5]]*x^2 + 40*Sqrt[5 + Sqrt[5]]*x^2 - 
      32*Sqrt[5*(5 + Sqrt[5])]*x^2 - 4*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      4*Sqrt[5 - Sqrt[5]]*x^3 - 8*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      32*Sqrt[25 - 5*Sqrt[5]]*x*y - 56*Sqrt[5 - Sqrt[5]]*x*y - 
      160*Sqrt[5 + Sqrt[5]]*x*y + 40*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      26*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 66*Sqrt[5 - Sqrt[5]]*x^2*y - 
      122*Sqrt[5 + Sqrt[5]]*x^2*y + 70*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      6*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 6*Sqrt[5 - Sqrt[5]]*x^3*y - 
      18*Sqrt[5 + Sqrt[5]]*x^3*y + 22*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      18*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 44*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      83*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 43*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      5*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 15*Sqrt[5 - Sqrt[5]]*x^3*y^2 + 
      34*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 24*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      2*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 8*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 
      18*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 10*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     20*Sqrt[5 - Sqrt[5]] - 4*Sqrt[5*(5 - Sqrt[5])] + 60*Sqrt[5 + Sqrt[5]] - 
      12*Sqrt[5*(5 + Sqrt[5])] - 20*Sqrt[5 - Sqrt[5]]*x + 
      4*Sqrt[5*(5 - Sqrt[5])]*x - 40*Sqrt[5 + Sqrt[5]]*x + 
      8*Sqrt[5*(5 + Sqrt[5])]*x - 20*Sqrt[5 + Sqrt[5]]*x^2 + 
      4*Sqrt[5*(5 + Sqrt[5])]*x^2 + 30*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x*y + 90*Sqrt[5 - Sqrt[5]]*x*y - 
      36*Sqrt[5*(5 - Sqrt[5])]*x*y + 40*Sqrt[5 + Sqrt[5]]*x*y - 
      12*Sqrt[5*(5 + Sqrt[5])]*x*y + 40*Sqrt[5 + Sqrt[5]]*x^2*y - 
      12*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 25*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      9*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 12*Sqrt[5 - Sqrt[5]] + 
      4*Sqrt[5*(5 - Sqrt[5])] + 36*Sqrt[5 + Sqrt[5]] + 
      12*Sqrt[5*(5 + Sqrt[5])] - 12*Sqrt[5 - Sqrt[5]]*x - 
      4*Sqrt[5*(5 - Sqrt[5])]*x - 24*Sqrt[5 + Sqrt[5]]*x - 
      8*Sqrt[5*(5 + Sqrt[5])]*x - 12*Sqrt[5 + Sqrt[5]]*x^2 - 
      4*Sqrt[5*(5 + Sqrt[5])]*x^2 - 6*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      18*Sqrt[5 - Sqrt[5]]*x*y + 4*Sqrt[5 + Sqrt[5]]*x*y + 
      4*Sqrt[5*(5 + Sqrt[5])]*x*y + 12*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      36*Sqrt[5 - Sqrt[5]]*x^2*y + 28*Sqrt[5 + Sqrt[5]]*x^2*y + 
      4*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 6*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      24*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 15*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, -260*Sqrt[25 - 5*Sqrt[5]] + 
      104*Sqrt[5*(25 - 5*Sqrt[5])] - 900*Sqrt[5 - Sqrt[5]] + 
      360*Sqrt[5*(5 - Sqrt[5])] - 280*Sqrt[5 + Sqrt[5]] + 
      240*Sqrt[5*(5 + Sqrt[5])] + 120*Sqrt[25 - 5*Sqrt[5]]*x - 
      48*Sqrt[5*(25 - 5*Sqrt[5])]*x + 280*Sqrt[5 - Sqrt[5]]*x - 
      112*Sqrt[5*(5 - Sqrt[5])]*x + 280*Sqrt[5 + Sqrt[5]]*x - 
      72*Sqrt[5*(5 + Sqrt[5])]*x + 160*Sqrt[5 - Sqrt[5]]*x^2 - 
      64*Sqrt[5*(5 - Sqrt[5])]*x^2 + 400*Sqrt[5 + Sqrt[5]]*x^2 - 
      192*Sqrt[5*(5 + Sqrt[5])]*x^2 - 20*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      8*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 - 20*Sqrt[5 - Sqrt[5]]*x^3 + 
      8*Sqrt[5*(5 - Sqrt[5])]*x^3 + 80*Sqrt[5 + Sqrt[5]]*x^3 - 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3 - 230*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      92*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 430*Sqrt[5 - Sqrt[5]]*x*y + 
      172*Sqrt[5*(5 - Sqrt[5])]*x*y - 180*Sqrt[5 + Sqrt[5]]*x*y + 
      16*Sqrt[5*(5 + Sqrt[5])]*x*y + 250*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      100*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y + 150*Sqrt[5 - Sqrt[5]]*x^2*y - 
      60*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 1010*Sqrt[5 + Sqrt[5]]*x^2*y + 
      462*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 30*Sqrt[5 - Sqrt[5]]*x^3*y + 
      12*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 310*Sqrt[5 + Sqrt[5]]*x^3*y + 
      146*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 140*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      56*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 - 60*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      24*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 620*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      276*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 75*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      30*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 410*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      188*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 10*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 - 40*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      16*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 190*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      86*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 120*Sqrt[25 - 5*Sqrt[5]] - 
      48*Sqrt[5*(25 - 5*Sqrt[5])] + 840*Sqrt[5 - Sqrt[5]] - 
      336*Sqrt[5*(5 - Sqrt[5])] + 1000*Sqrt[5 + Sqrt[5]] - 
      408*Sqrt[5*(5 + Sqrt[5])] + 420*Sqrt[25 - 5*Sqrt[5]]*x - 
      168*Sqrt[5*(25 - 5*Sqrt[5])]*x + 540*Sqrt[5 - Sqrt[5]]*x - 
      216*Sqrt[5*(5 - Sqrt[5])]*x - 660*Sqrt[5 + Sqrt[5]]*x + 
      396*Sqrt[5*(5 + Sqrt[5])]*x + 40*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      16*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 + 280*Sqrt[5 - Sqrt[5]]*x^2 - 
      112*Sqrt[5*(5 - Sqrt[5])]*x^2 + 280*Sqrt[5 + Sqrt[5]]*x^2 - 
      88*Sqrt[5*(5 + Sqrt[5])]*x^2 + 40*Sqrt[5 - Sqrt[5]]*x^3 - 
      16*Sqrt[5*(5 - Sqrt[5])]*x^3 + 140*Sqrt[5 + Sqrt[5]]*x^3 - 
      60*Sqrt[5*(5 + Sqrt[5])]*x^3 - 250*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      100*Sqrt[5*(25 - 5*Sqrt[5])]*x*y - 430*Sqrt[5 - Sqrt[5]]*x*y + 
      172*Sqrt[5*(5 - Sqrt[5])]*x*y + 290*Sqrt[5 + Sqrt[5]]*x*y - 
      198*Sqrt[5*(5 + Sqrt[5])]*x*y + 10*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      4*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y - 410*Sqrt[5 - Sqrt[5]]*x^2*y + 
      164*Sqrt[5*(5 - Sqrt[5])]*x^2*y - 670*Sqrt[5 + Sqrt[5]]*x^2*y + 
      250*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 30*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      12*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y - 90*Sqrt[5 - Sqrt[5]]*x^3*y + 
      36*Sqrt[5*(5 - Sqrt[5])]*x^3*y - 520*Sqrt[5 + Sqrt[5]]*x^3*y + 
      228*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 50*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      20*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 + 210*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      84*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 530*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      222*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 50*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      20*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 + 100*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      40*Sqrt[5*(5 - Sqrt[5])]*x^3*y^2 + 675*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      299*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 25*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      10*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^3 - 45*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      18*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3 - 310*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      138*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3}
 
F839 = {4840*Sqrt[25 - 5*Sqrt[5]] + 10920*Sqrt[5 - Sqrt[5]] - 
      2160*Sqrt[5 + Sqrt[5]] - 992*Sqrt[5*(5 + Sqrt[5])] - 
      3296*Sqrt[25 - 5*Sqrt[5]]*x - 7520*Sqrt[5 - Sqrt[5]]*x + 
      9280*Sqrt[5 + Sqrt[5]]*x + 4224*Sqrt[5*(5 + Sqrt[5])]*x + 
      352*Sqrt[25 - 5*Sqrt[5]]*x^2 + 720*Sqrt[5 - Sqrt[5]]*x^2 + 
      760*Sqrt[5 + Sqrt[5]]*x^2 + 328*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      104*Sqrt[25 - 5*Sqrt[5]]*x^3 + 280*Sqrt[5 - Sqrt[5]]*x^3 - 
      280*Sqrt[5 + Sqrt[5]]*x^3 - 120*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      2316*Sqrt[25 - 5*Sqrt[5]]*x*y + 5180*Sqrt[5 - Sqrt[5]]*x*y - 
      6080*Sqrt[5 + Sqrt[5]]*x*y - 2744*Sqrt[5*(5 + Sqrt[5])]*x*y - 
      464*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 960*Sqrt[5 - Sqrt[5]]*x^2*y + 
      600*Sqrt[5 + Sqrt[5]]*x^2*y + 264*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      312*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 720*Sqrt[5 - Sqrt[5]]*x^3*y + 
      500*Sqrt[5 + Sqrt[5]]*x^3*y + 220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      402*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 890*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      1640*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 732*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 660*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      360*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 245*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      90*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     182000*Sqrt[2*(25 - 5*Sqrt[5])] - 72800*Sqrt[10*(25 - 5*Sqrt[5])] + 
      407120*Sqrt[2*(5 - Sqrt[5])] - 162848*Sqrt[10*(5 - Sqrt[5])] - 
      14480*Sqrt[2*(5 + Sqrt[5])] - 6672*Sqrt[10*(5 + Sqrt[5])] - 
      79760*Sqrt[2*(25 - 5*Sqrt[5])]*x + 31904*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      178800*Sqrt[2*(5 - Sqrt[5])]*x + 71520*Sqrt[10*(5 - Sqrt[5])]*x + 
      7760*Sqrt[2*(5 + Sqrt[5])]*x + 3984*Sqrt[10*(5 + Sqrt[5])]*x + 
      160*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 64*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 
      800*Sqrt[2*(5 - Sqrt[5])]*x^2 - 320*Sqrt[10*(5 - Sqrt[5])]*x^2 + 
      1920*Sqrt[2*(5 + Sqrt[5])]*x^2 + 448*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 256*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 
      1280*Sqrt[2*(5 - Sqrt[5])]*x^3 - 512*Sqrt[10*(5 - Sqrt[5])]*x^3 - 
      960*Sqrt[2*(5 + Sqrt[5])]*x^3 - 320*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      123480*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 49392*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 276200*Sqrt[2*(5 - Sqrt[5])]*x*y - 110480*Sqrt[10*(5 - Sqrt[5])]*x*
       y - 6200*Sqrt[2*(5 + Sqrt[5])]*x*y - 2904*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      22800*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 9120*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 50800*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      20320*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 240*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      304*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 7840*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 3136*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 17440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y + 6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 1600*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y + 640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      8960*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 3584*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 20000*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      8000*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 2320*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 1072*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 3840*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 21440*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 1120*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 480*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 1840*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 10280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     77040*Sqrt[2*(25 - 5*Sqrt[5])] - 30816*Sqrt[10*(25 - 5*Sqrt[5])] + 
      172400*Sqrt[2*(5 - Sqrt[5])] - 68960*Sqrt[10*(5 - Sqrt[5])] - 
      4960*Sqrt[2*(5 + Sqrt[5])] - 2240*Sqrt[10*(5 + Sqrt[5])] - 
      13520*Sqrt[2*(25 - 5*Sqrt[5])]*x + 5408*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      30640*Sqrt[2*(5 - Sqrt[5])]*x + 12256*Sqrt[10*(5 - Sqrt[5])]*x - 
      2800*Sqrt[2*(5 + Sqrt[5])]*x - 1200*Sqrt[10*(5 + Sqrt[5])]*x - 
      800*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 320*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 
      1440*Sqrt[2*(5 - Sqrt[5])]*x^2 + 576*Sqrt[10*(5 - Sqrt[5])]*x^2 + 
      640*Sqrt[2*(5 + Sqrt[5])]*x^2 + 320*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 
      1920*Sqrt[2*(5 - Sqrt[5])]*x^3 + 768*Sqrt[10*(5 - Sqrt[5])]*x^3 + 
      240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 80*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      18880*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 7552*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 42240*Sqrt[2*(5 - Sqrt[5])]*x*y - 16896*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 1760*Sqrt[2*(5 + Sqrt[5])]*x*y + 800*Sqrt[10*(5 + Sqrt[5])]*x*y - 
      5680*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y + 2272*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y - 12720*Sqrt[2*(5 - Sqrt[5])]*x^2*y + 
      5088*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 960*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      480*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 5160*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y - 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 400*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y + 
      880*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 352*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 1960*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 
      784*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 660*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 300*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 848*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 
      1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, -51640*Sqrt[2*(25 - 5*Sqrt[5])] + 
      20656*Sqrt[10*(25 - 5*Sqrt[5])] - 115440*Sqrt[2*(5 - Sqrt[5])] + 
      46176*Sqrt[10*(5 - Sqrt[5])] + 9100*Sqrt[2*(5 + Sqrt[5])] + 
      4068*Sqrt[10*(5 + Sqrt[5])] + 36720*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      14688*Sqrt[10*(25 - 5*Sqrt[5])]*x + 82040*Sqrt[2*(5 - Sqrt[5])]*x - 
      32816*Sqrt[10*(5 - Sqrt[5])]*x - 1940*Sqrt[2*(5 + Sqrt[5])]*x - 
      876*Sqrt[10*(5 + Sqrt[5])]*x - 19680*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      7872*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 43920*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      17568*Sqrt[10*(5 - Sqrt[5])]*x^2 + 440*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      168*Sqrt[10*(5 + Sqrt[5])]*x^2 + 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 - 240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 27520*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      11008*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 61540*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      24616*Sqrt[10*(5 - Sqrt[5])]*x*y + 1330*Sqrt[2*(5 + Sqrt[5])]*x*y + 
      606*Sqrt[10*(5 + Sqrt[5])]*x*y + 34640*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      13856*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 77440*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 30976*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 840*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y - 376*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 1960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y + 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 
      4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y + 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      11860*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 4744*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 26520*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      10608*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 610*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 278*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 960*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 5360*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      2144*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 460*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 + 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -177120*Sqrt[2*(25 - 5*Sqrt[5])] + 70848*Sqrt[10*(25 - 5*Sqrt[5])] - 
      396160*Sqrt[2*(5 - Sqrt[5])] + 158464*Sqrt[10*(5 - Sqrt[5])] + 
      31440*Sqrt[2*(5 + Sqrt[5])] + 14064*Sqrt[10*(5 + Sqrt[5])] + 
      70400*Sqrt[2*(25 - 5*Sqrt[5])]*x - 28160*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      157600*Sqrt[2*(5 - Sqrt[5])]*x - 63040*Sqrt[10*(5 - Sqrt[5])]*x - 
      1040*Sqrt[2*(5 + Sqrt[5])]*x - 368*Sqrt[10*(5 + Sqrt[5])]*x - 
      34640*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 13856*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 77520*Sqrt[2*(5 - Sqrt[5])]*x^2 + 31008*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 9440*Sqrt[2*(5 + Sqrt[5])]*x^2 - 4416*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 - 160*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      94080*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 37632*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 210400*Sqrt[2*(5 - Sqrt[5])]*x*y + 84160*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 4720*Sqrt[2*(5 + Sqrt[5])]*x*y + 2128*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      75600*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 30240*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 169040*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      67616*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 5280*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      2432*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 27960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 11184*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      62520*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 25008*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 3200*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 1424*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 61680*Sqrt[2*(25 - 5*Sqrt[5])] - 
      24672*Sqrt[10*(25 - 5*Sqrt[5])] + 137960*Sqrt[2*(5 - Sqrt[5])] - 
      55184*Sqrt[10*(5 - Sqrt[5])] - 5980*Sqrt[2*(5 + Sqrt[5])] - 
      2724*Sqrt[10*(5 + Sqrt[5])] - 10400*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      4160*Sqrt[10*(25 - 5*Sqrt[5])]*x - 23400*Sqrt[2*(5 - Sqrt[5])]*x + 
      9360*Sqrt[10*(5 - Sqrt[5])]*x + 2740*Sqrt[2*(5 + Sqrt[5])]*x + 
      1388*Sqrt[10*(5 + Sqrt[5])]*x + 8760*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      3504*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 19720*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      7888*Sqrt[10*(5 - Sqrt[5])]*x^2 - 120*Sqrt[2*(5 + Sqrt[5])]*x^2 - 
      184*Sqrt[10*(5 + Sqrt[5])]*x^2 + 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 - 240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 + 20960*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      8384*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 46900*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      18760*Sqrt[10*(5 - Sqrt[5])]*x*y - 2330*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      1078*Sqrt[10*(5 + Sqrt[5])]*x*y - 3840*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y + 
      1536*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y - 8640*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y + 3456*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 1040*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y + 528*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 1960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y + 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 
      4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y + 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y + 
      430*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 172*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 970*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 
      388*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 1210*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 554*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 960*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 5360*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      2144*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 460*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 + 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     18240*Sqrt[2*(25 - 5*Sqrt[5])] - 7296*Sqrt[10*(25 - 5*Sqrt[5])] + 
      40800*Sqrt[2*(5 - Sqrt[5])] - 16320*Sqrt[10*(5 - Sqrt[5])] + 
      6320*Sqrt[2*(5 + Sqrt[5])] + 2896*Sqrt[10*(5 + Sqrt[5])] + 
      960*Sqrt[2*(25 - 5*Sqrt[5])]*x - 384*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      2080*Sqrt[2*(5 - Sqrt[5])]*x - 832*Sqrt[10*(5 - Sqrt[5])]*x - 
      9200*Sqrt[2*(5 + Sqrt[5])]*x - 4112*Sqrt[10*(5 + Sqrt[5])]*x - 
      18160*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 7264*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 40560*Sqrt[2*(5 - Sqrt[5])]*x^2 + 16224*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 3040*Sqrt[2*(5 + Sqrt[5])]*x^2 + 1216*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 - 160*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      50240*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 20096*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 112320*Sqrt[2*(5 - Sqrt[5])]*x*y - 44928*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 5440*Sqrt[2*(5 + Sqrt[5])]*x*y + 2432*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      28240*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 11296*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 63120*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      25248*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 3840*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      1632*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 15280*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 6112*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      34160*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 13664*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 1840*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 816*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 856*Sqrt[25 - 5*Sqrt[5]] + 
      1880*Sqrt[5 - Sqrt[5]] + 1680*Sqrt[5 + Sqrt[5]] + 
      704*Sqrt[5*(5 + Sqrt[5])] - 3040*Sqrt[25 - 5*Sqrt[5]]*x - 
      6560*Sqrt[5 - Sqrt[5]]*x + 7200*Sqrt[5 + Sqrt[5]]*x + 
      3232*Sqrt[5*(5 + Sqrt[5])]*x + 880*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      1760*Sqrt[5 - Sqrt[5]]*x^2 - 2280*Sqrt[5 + Sqrt[5]]*x^2 - 
      1016*Sqrt[5*(5 + Sqrt[5])]*x^2 + 104*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      280*Sqrt[5 - Sqrt[5]]*x^3 - 280*Sqrt[5 + Sqrt[5]]*x^3 - 
      120*Sqrt[5*(5 + Sqrt[5])]*x^3 + 1100*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      2460*Sqrt[5 - Sqrt[5]]*x*y - 4400*Sqrt[5 + Sqrt[5]]*x*y - 
      1992*Sqrt[5*(5 + Sqrt[5])]*x*y - 480*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      1040*Sqrt[5 - Sqrt[5]]*x^2*y + 3000*Sqrt[5 + Sqrt[5]]*x^2*y + 
      1352*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 312*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      720*Sqrt[5 - Sqrt[5]]*x^3*y + 500*Sqrt[5 + Sqrt[5]]*x^3*y + 
      220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 550*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      1230*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 1600*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      716*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      660*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 360*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      245*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 90*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, -257840*Sqrt[2*(25 - 5*Sqrt[5])] + 
      103136*Sqrt[10*(25 - 5*Sqrt[5])] - 576400*Sqrt[2*(5 - Sqrt[5])] + 
      230560*Sqrt[10*(5 - Sqrt[5])] + 43920*Sqrt[2*(5 + Sqrt[5])] + 
      19600*Sqrt[10*(5 + Sqrt[5])] + 72720*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      29088*Sqrt[10*(25 - 5*Sqrt[5])]*x + 162160*Sqrt[2*(5 - Sqrt[5])]*x - 
      64864*Sqrt[10*(5 - Sqrt[5])]*x + 2160*Sqrt[2*(5 + Sqrt[5])]*x + 
      1200*Sqrt[10*(5 + Sqrt[5])]*x - 55200*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      22080*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 123040*Sqrt[2*(5 - Sqrt[5])]*
       x^2 + 49216*Sqrt[10*(5 - Sqrt[5])]*x^2 - 8000*Sqrt[2*(5 + Sqrt[5])]*
       x^2 - 3840*Sqrt[10*(5 + Sqrt[5])]*x^2 + 640*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3 - 256*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 1280*Sqrt[2*(5 - Sqrt[5])]*
       x^3 - 512*Sqrt[10*(5 - Sqrt[5])]*x^3 - 960*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 - 83160*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      33264*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 185960*Sqrt[2*(5 - Sqrt[5])]*x*
       y + 74384*Sqrt[10*(5 - Sqrt[5])]*x*y + 2040*Sqrt[2*(5 + Sqrt[5])]*x*
       y + 920*Sqrt[10*(5 + Sqrt[5])]*x*y + 123120*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y - 49248*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      275280*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 110112*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 4720*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 2160*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y - 7840*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 
      3136*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 17440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 1600*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 42320*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 16928*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      94640*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 37856*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 2320*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 1040*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 - 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 + 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -85840*Sqrt[2*(25 - 5*Sqrt[5])] + 34336*Sqrt[10*(25 - 5*Sqrt[5])] - 
      191760*Sqrt[2*(5 - Sqrt[5])] + 76704*Sqrt[10*(5 - Sqrt[5])] + 
      18880*Sqrt[2*(5 + Sqrt[5])] + 8352*Sqrt[10*(5 + Sqrt[5])] + 
      48400*Sqrt[2*(25 - 5*Sqrt[5])]*x - 19360*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      107760*Sqrt[2*(5 - Sqrt[5])]*x - 43104*Sqrt[10*(5 - Sqrt[5])]*x + 
      1520*Sqrt[2*(5 + Sqrt[5])]*x + 816*Sqrt[10*(5 + Sqrt[5])]*x - 
      17920*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 7168*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 39680*Sqrt[2*(5 - Sqrt[5])]*x^2 + 15872*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 3200*Sqrt[2*(5 + Sqrt[5])]*x^2 - 1408*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3 - 1920*Sqrt[2*(5 - Sqrt[5])]*x^3 + 768*Sqrt[10*(5 - Sqrt[5])]*
       x^3 + 240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      71120*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 28448*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 158960*Sqrt[2*(5 - Sqrt[5])]*x*y + 63584*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 1520*Sqrt[2*(5 + Sqrt[5])]*x*y + 624*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      28560*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 11424*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 63760*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      25504*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 960*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      416*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 5160*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y - 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 400*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      13640*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 5456*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 30480*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      12192*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 2180*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 972*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 848*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 
      1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 72960*Sqrt[2*(25 - 5*Sqrt[5])] - 
      29184*Sqrt[10*(25 - 5*Sqrt[5])] + 163200*Sqrt[2*(5 - Sqrt[5])] - 
      65280*Sqrt[10*(5 - Sqrt[5])] - 2400*Sqrt[2*(5 + Sqrt[5])] - 
      1120*Sqrt[10*(5 + Sqrt[5])] - 4920*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      1968*Sqrt[10*(25 - 5*Sqrt[5])]*x - 11160*Sqrt[2*(5 - Sqrt[5])]*x + 
      4464*Sqrt[10*(5 - Sqrt[5])]*x + 4160*Sqrt[2*(5 + Sqrt[5])]*x + 
      2000*Sqrt[10*(5 + Sqrt[5])]*x + 9080*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      3632*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 20440*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      8176*Sqrt[10*(5 - Sqrt[5])]*x^2 - 640*Sqrt[2*(5 + Sqrt[5])]*x^2 - 
      400*Sqrt[10*(5 + Sqrt[5])]*x^2 + 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 - 240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 + 22820*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      9128*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 51060*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      20424*Sqrt[10*(5 - Sqrt[5])]*x*y - 3040*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      1400*Sqrt[10*(5 + Sqrt[5])]*x*y - 6360*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y + 
      2544*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y - 14280*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y + 5712*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 1560*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y + 760*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 1960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y + 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 
      4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y + 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y + 
      930*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 372*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 2090*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 
      836*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 1360*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 620*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 960*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 5360*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      2144*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 460*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 + 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     165600*Sqrt[2*(25 - 5*Sqrt[5])] - 66240*Sqrt[10*(25 - 5*Sqrt[5])] + 
      370240*Sqrt[2*(5 - Sqrt[5])] - 148096*Sqrt[10*(5 - Sqrt[5])] + 
      2320*Sqrt[2*(5 + Sqrt[5])] + 1072*Sqrt[10*(5 + Sqrt[5])] - 
      72960*Sqrt[2*(25 - 5*Sqrt[5])]*x + 29184*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      163040*Sqrt[2*(5 - Sqrt[5])]*x + 65216*Sqrt[10*(5 - Sqrt[5])]*x - 
      6480*Sqrt[2*(5 + Sqrt[5])]*x - 2864*Sqrt[10*(5 + Sqrt[5])]*x - 
      15760*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 6304*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 35280*Sqrt[2*(5 - Sqrt[5])]*x^2 + 14112*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 2560*Sqrt[2*(5 + Sqrt[5])]*x^2 + 992*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 - 160*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      142160*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 56864*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 317840*Sqrt[2*(5 - Sqrt[5])]*x*y - 127136*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 3680*Sqrt[2*(5 + Sqrt[5])]*x*y + 1664*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      11520*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 4608*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 25760*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      10304*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 2960*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      1264*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 5760*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 2304*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      12880*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 5152*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 1240*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 552*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, -4968*Sqrt[25 - 5*Sqrt[5]] - 
      11080*Sqrt[5 - Sqrt[5]] + 12800*Sqrt[5 + Sqrt[5]] + 
      5712*Sqrt[5*(5 + Sqrt[5])] - 3680*Sqrt[25 - 5*Sqrt[5]]*x - 
      8160*Sqrt[5 - Sqrt[5]]*x - 480*Sqrt[5 + Sqrt[5]]*x - 
      224*Sqrt[5*(5 + Sqrt[5])]*x + 1024*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      2160*Sqrt[5 - Sqrt[5]]*x^2 - 1640*Sqrt[5 + Sqrt[5]]*x^2 - 
      728*Sqrt[5*(5 + Sqrt[5])]*x^2 + 104*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      280*Sqrt[5 - Sqrt[5]]*x^3 - 280*Sqrt[5 + Sqrt[5]]*x^3 - 
      120*Sqrt[5*(5 + Sqrt[5])]*x^3 + 1620*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      3620*Sqrt[5 - Sqrt[5]]*x*y - 80*Sqrt[5 + Sqrt[5]]*x*y - 
      56*Sqrt[5*(5 + Sqrt[5])]*x*y - 248*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      520*Sqrt[5 - Sqrt[5]]*x^2*y + 1880*Sqrt[5 + Sqrt[5]]*x^2*y + 
      856*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 312*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      720*Sqrt[5 - Sqrt[5]]*x^3*y + 500*Sqrt[5 + Sqrt[5]]*x^3*y + 
      220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 274*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      610*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 820*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      368*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      660*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 360*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      245*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 90*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, -258720*Sqrt[2*(25 - 5*Sqrt[5])] + 
      103488*Sqrt[10*(25 - 5*Sqrt[5])] - 578400*Sqrt[2*(5 - Sqrt[5])] + 
      231360*Sqrt[10*(5 - Sqrt[5])] + 46880*Sqrt[2*(5 + Sqrt[5])] + 
      20896*Sqrt[10*(5 + Sqrt[5])] + 90880*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      36352*Sqrt[10*(25 - 5*Sqrt[5])]*x + 202880*Sqrt[2*(5 - Sqrt[5])]*x - 
      81152*Sqrt[10*(5 - Sqrt[5])]*x - 6720*Sqrt[2*(5 + Sqrt[5])]*x - 
      2752*Sqrt[10*(5 + Sqrt[5])]*x - 63200*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      25280*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 140960*Sqrt[2*(5 - Sqrt[5])]*
       x^2 + 56384*Sqrt[10*(5 - Sqrt[5])]*x^2 - 5600*Sqrt[2*(5 + Sqrt[5])]*
       x^2 - 2784*Sqrt[10*(5 + Sqrt[5])]*x^2 + 640*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3 - 256*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 1280*Sqrt[2*(5 - Sqrt[5])]*
       x^3 - 512*Sqrt[10*(5 - Sqrt[5])]*x^3 - 960*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 - 143680*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      57472*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 321280*Sqrt[2*(5 - Sqrt[5])]*x*
       y + 128512*Sqrt[10*(5 - Sqrt[5])]*x*y + 6560*Sqrt[2*(5 + Sqrt[5])]*x*
       y + 2912*Sqrt[10*(5 + Sqrt[5])]*x*y + 144000*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y - 57600*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      321920*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 128768*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 2240*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 1088*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y - 7840*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 
      3136*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 17440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 1600*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 49000*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 19600*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      109560*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 43824*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 3000*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 1336*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 - 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 + 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     18480*Sqrt[2*(25 - 5*Sqrt[5])] - 7392*Sqrt[10*(25 - 5*Sqrt[5])] + 
      41520*Sqrt[2*(5 - Sqrt[5])] - 16608*Sqrt[10*(5 - Sqrt[5])] + 
      15520*Sqrt[2*(5 + Sqrt[5])] + 6848*Sqrt[10*(5 + Sqrt[5])] + 
      68400*Sqrt[2*(25 - 5*Sqrt[5])]*x - 27360*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      152400*Sqrt[2*(5 - Sqrt[5])]*x - 60960*Sqrt[10*(5 - Sqrt[5])]*x + 
      8400*Sqrt[2*(5 + Sqrt[5])]*x + 3984*Sqrt[10*(5 + Sqrt[5])]*x - 
      16640*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 6656*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 36800*Sqrt[2*(5 - Sqrt[5])]*x^2 + 14720*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 4320*Sqrt[2*(5 + Sqrt[5])]*x^2 - 1952*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3 - 1920*Sqrt[2*(5 - Sqrt[5])]*x^3 + 768*Sqrt[10*(5 - Sqrt[5])]*
       x^3 + 240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      123280*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 49312*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 275600*Sqrt[2*(5 - Sqrt[5])]*x*y + 110240*Sqrt[10*(5 - Sqrt[5])]*x*
       y - 2560*Sqrt[2*(5 + Sqrt[5])]*x*y - 1184*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      30080*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 12032*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 67200*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      26880*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 2720*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      1184*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 5160*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y - 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 400*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      13240*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 5296*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 29600*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      11840*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 1140*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 508*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 848*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 
      1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 213440*Sqrt[2*(25 - 5*Sqrt[5])] - 
      85376*Sqrt[10*(25 - 5*Sqrt[5])] + 477440*Sqrt[2*(5 - Sqrt[5])] - 
      190976*Sqrt[10*(5 - Sqrt[5])] + 1760*Sqrt[2*(5 + Sqrt[5])] + 
      672*Sqrt[10*(5 + Sqrt[5])] - 64800*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      25920*Sqrt[10*(25 - 5*Sqrt[5])]*x - 145440*Sqrt[2*(5 - Sqrt[5])]*x + 
      58176*Sqrt[10*(5 - Sqrt[5])]*x + 6720*Sqrt[2*(5 + Sqrt[5])]*x + 
      3456*Sqrt[10*(5 + Sqrt[5])]*x + 8160*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      3264*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 18720*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      7488*Sqrt[10*(5 - Sqrt[5])]*x^2 - 480*Sqrt[2*(5 + Sqrt[5])]*x^2 - 
      608*Sqrt[10*(5 + Sqrt[5])]*x^2 + 640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      256*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 1280*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      512*Sqrt[10*(5 - Sqrt[5])]*x^3 - 960*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 + 160720*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      64288*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 359440*Sqrt[2*(5 - Sqrt[5])]*x*
       y - 143776*Sqrt[10*(5 - Sqrt[5])]*x*y - 5760*Sqrt[2*(5 + Sqrt[5])]*x*
       y - 2656*Sqrt[10*(5 + Sqrt[5])]*x*y + 1920*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y - 768*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      4160*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 1664*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 
      2720*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 1376*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 
      7840*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 3136*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y - 17440*Sqrt[2*(5 - Sqrt[5])]*x^3*y + 
      6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 1600*Sqrt[2*(5 + Sqrt[5])]*x^3*y + 
      640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      5080*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 2032*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 3000*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 1368*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 - 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 + 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     76240*Sqrt[2*(25 - 5*Sqrt[5])] - 30496*Sqrt[10*(25 - 5*Sqrt[5])] + 
      170640*Sqrt[2*(5 - Sqrt[5])] - 68256*Sqrt[10*(5 - Sqrt[5])] + 
      7040*Sqrt[2*(5 + Sqrt[5])] + 3104*Sqrt[10*(5 + Sqrt[5])] - 
      73360*Sqrt[2*(25 - 5*Sqrt[5])]*x + 29344*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      164400*Sqrt[2*(5 - Sqrt[5])]*x + 65760*Sqrt[10*(5 - Sqrt[5])]*x - 
      9040*Sqrt[2*(5 + Sqrt[5])]*x - 4048*Sqrt[10*(5 + Sqrt[5])]*x - 
      2080*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 832*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 
      4320*Sqrt[2*(5 - Sqrt[5])]*x^2 + 1728*Sqrt[10*(5 - Sqrt[5])]*x^2 + 
      1760*Sqrt[2*(5 + Sqrt[5])]*x^2 + 864*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 
      1920*Sqrt[2*(5 - Sqrt[5])]*x^3 + 768*Sqrt[10*(5 - Sqrt[5])]*x^3 + 
      240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 80*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      84240*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 33696*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 188400*Sqrt[2*(5 - Sqrt[5])]*x*y - 75360*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 5520*Sqrt[2*(5 + Sqrt[5])]*x*y + 2448*Sqrt[10*(5 + Sqrt[5])]*x*y - 
      7200*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y + 2880*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y - 16160*Sqrt[2*(5 - Sqrt[5])]*x^2*y + 
      6464*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 2720*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      1248*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 5160*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y - 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 400*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y + 
      480*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 192*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 1080*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 
      432*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 1700*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 764*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 848*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 
      1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, -37040*Sqrt[2*(25 - 5*Sqrt[5])] + 
      14816*Sqrt[10*(25 - 5*Sqrt[5])] - 82800*Sqrt[2*(5 - Sqrt[5])] + 
      33120*Sqrt[10*(5 - Sqrt[5])] + 7680*Sqrt[2*(5 + Sqrt[5])] + 
      3424*Sqrt[10*(5 + Sqrt[5])] + 21280*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      8512*Sqrt[10*(25 - 5*Sqrt[5])]*x + 47520*Sqrt[2*(5 - Sqrt[5])]*x - 
      19008*Sqrt[10*(5 - Sqrt[5])]*x - 3200*Sqrt[2*(5 + Sqrt[5])]*x - 
      1408*Sqrt[10*(5 + Sqrt[5])]*x - 20000*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      8000*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 44640*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      17856*Sqrt[10*(5 - Sqrt[5])]*x^2 + 960*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      384*Sqrt[10*(5 + Sqrt[5])]*x^2 + 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 - 240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 26080*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      10432*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 58320*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      23328*Sqrt[10*(5 - Sqrt[5])]*x*y + 1960*Sqrt[2*(5 + Sqrt[5])]*x*y + 
      888*Sqrt[10*(5 + Sqrt[5])]*x*y + 37160*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      14864*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 83080*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 33232*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 1360*Sqrt[2*(5 + Sqrt[5])]*
       x^2*y - 608*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 
      1960*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*
       y - 4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y + 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*
       y + 400*Sqrt[2*(5 + Sqrt[5])]*x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y - 12360*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      4944*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 27640*Sqrt[2*(5 - Sqrt[5])]*
       x^2*y^2 + 11056*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 
      760*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 344*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y^2 + 2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      960*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 5360*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 2144*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 460*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 + 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -220960*Sqrt[2*(25 - 5*Sqrt[5])] + 88384*Sqrt[10*(25 - 5*Sqrt[5])] - 
      494080*Sqrt[2*(5 - Sqrt[5])] + 197632*Sqrt[10*(5 - Sqrt[5])] + 
      44080*Sqrt[2*(5 + Sqrt[5])] + 19728*Sqrt[10*(5 + Sqrt[5])] + 
      104480*Sqrt[2*(25 - 5*Sqrt[5])]*x - 41792*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      233600*Sqrt[2*(5 - Sqrt[5])]*x - 93440*Sqrt[10*(5 - Sqrt[5])]*x - 
      3120*Sqrt[2*(5 + Sqrt[5])]*x - 1296*Sqrt[10*(5 + Sqrt[5])]*x - 
      37040*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 14816*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 82800*Sqrt[2*(5 - Sqrt[5])]*x^2 + 33120*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 8960*Sqrt[2*(5 + Sqrt[5])]*x^2 - 4192*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 - 160*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      172800*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 69120*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 386400*Sqrt[2*(5 - Sqrt[5])]*x*y + 154560*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 6160*Sqrt[2*(5 + Sqrt[5])]*x*y + 2736*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      92320*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 36928*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 206400*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      82560*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 4400*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      2064*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 37480*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 14992*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      83800*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 33520*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 3800*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 1688*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 12280*Sqrt[25 - 5*Sqrt[5]] + 
      27480*Sqrt[5 - Sqrt[5]] - 3680*Sqrt[5 + Sqrt[5]] - 
      1680*Sqrt[5*(5 + Sqrt[5])] - 912*Sqrt[25 - 5*Sqrt[5]]*x - 
      2000*Sqrt[5 - Sqrt[5]]*x + 12000*Sqrt[5 + Sqrt[5]]*x + 
      5440*Sqrt[5*(5 + Sqrt[5])]*x + 208*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      320*Sqrt[5 - Sqrt[5]]*x^2 + 120*Sqrt[5 + Sqrt[5]]*x^2 + 
      40*Sqrt[5*(5 + Sqrt[5])]*x^2 + 104*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      280*Sqrt[5 - Sqrt[5]]*x^3 - 280*Sqrt[5 + Sqrt[5]]*x^3 - 
      120*Sqrt[5*(5 + Sqrt[5])]*x^3 + 572*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      1260*Sqrt[5 - Sqrt[5]]*x*y - 7920*Sqrt[5 + Sqrt[5]]*x*y - 
      3560*Sqrt[5*(5 + Sqrt[5])]*x*y - 696*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      1480*Sqrt[5 - Sqrt[5]]*x^2*y + 1720*Sqrt[5 + Sqrt[5]]*x^2*y + 
      760*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 312*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      720*Sqrt[5 - Sqrt[5]]*x^3*y + 500*Sqrt[5 + Sqrt[5]]*x^3*y + 
      220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 678*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      1510*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 2420*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      1080*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      660*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 360*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      245*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 90*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 226480*Sqrt[2*(25 - 5*Sqrt[5])] - 
      90592*Sqrt[10*(25 - 5*Sqrt[5])] + 506480*Sqrt[2*(5 - Sqrt[5])] - 
      202592*Sqrt[10*(5 - Sqrt[5])] - 3520*Sqrt[2*(5 + Sqrt[5])] - 
      1760*Sqrt[10*(5 + Sqrt[5])] - 71360*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      28544*Sqrt[10*(25 - 5*Sqrt[5])]*x - 159680*Sqrt[2*(5 - Sqrt[5])]*x + 
      63872*Sqrt[10*(5 - Sqrt[5])]*x + 15680*Sqrt[2*(5 + Sqrt[5])]*x + 
      7360*Sqrt[10*(5 + Sqrt[5])]*x + 26960*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      10784*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 60400*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      24160*Sqrt[10*(5 - Sqrt[5])]*x^2 - 1840*Sqrt[2*(5 + Sqrt[5])]*x^2 - 
      1200*Sqrt[10*(5 + Sqrt[5])]*x^2 + 1440*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      576*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 3200*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      1280*Sqrt[10*(5 - Sqrt[5])]*x^3 - 1200*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      400*Sqrt[10*(5 + Sqrt[5])]*x^3 + 144440*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      57776*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 323080*Sqrt[2*(5 - Sqrt[5])]*x*
       y - 129232*Sqrt[10*(5 - Sqrt[5])]*x*y - 11480*Sqrt[2*(5 + Sqrt[5])]*x*
       y - 5240*Sqrt[10*(5 + Sqrt[5])]*x*y - 13360*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y + 5344*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y - 
      30000*Sqrt[2*(5 - Sqrt[5])]*x^2*y + 12000*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 5280*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 2560*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y - 10120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 
      4048*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 22600*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 9040*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 2000*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 800*Sqrt[10*(5 + Sqrt[5])]*x^3*y + 2900*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 1160*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      6500*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 2600*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 5040*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 2280*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 11720*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      4688*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 26200*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 10480*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 
      1400*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 600*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 5390*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      2156*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 - 12050*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 + 4820*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 
      350*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 150*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     2232*Sqrt[25 - 5*Sqrt[5]] + 4992*Sqrt[5 - Sqrt[5]] - 
      940*Sqrt[5 + Sqrt[5]] - 420*Sqrt[5*(5 + Sqrt[5])] - 
      1496*Sqrt[25 - 5*Sqrt[5]]*x - 3352*Sqrt[5 - Sqrt[5]]*x + 
      80*Sqrt[5 + Sqrt[5]]*x + 32*Sqrt[5*(5 + Sqrt[5])]*x - 
      8*Sqrt[25 - 5*Sqrt[5]]*x^2 + 100*Sqrt[5 + Sqrt[5]]*x^2 + 
      44*Sqrt[5*(5 + Sqrt[5])]*x^2 + 1672*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      3752*Sqrt[5 - Sqrt[5]]*x*y - 80*Sqrt[5 + Sqrt[5]]*x*y - 
      32*Sqrt[5*(5 + Sqrt[5])]*x*y - 196*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      460*Sqrt[5 - Sqrt[5]]*x^2*y - 60*Sqrt[5 + Sqrt[5]]*x^2*y - 
      28*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 134*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      300*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 25*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      11*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, -330960*Sqrt[2*(25 - 5*Sqrt[5])] + 
      132384*Sqrt[10*(25 - 5*Sqrt[5])] - 739920*Sqrt[2*(5 - Sqrt[5])] + 
      295968*Sqrt[10*(5 - Sqrt[5])] + 57440*Sqrt[2*(5 + Sqrt[5])] + 
      25600*Sqrt[10*(5 + Sqrt[5])] + 137200*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      54880*Sqrt[10*(25 - 5*Sqrt[5])]*x + 306320*Sqrt[2*(5 - Sqrt[5])]*x - 
      122528*Sqrt[10*(5 - Sqrt[5])]*x - 22320*Sqrt[2*(5 + Sqrt[5])]*x - 
      9840*Sqrt[10*(5 + Sqrt[5])]*x - 30800*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      12320*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 68400*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      27360*Sqrt[10*(5 - Sqrt[5])]*x^2 + 400*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      80*Sqrt[10*(5 + Sqrt[5])]*x^2 + 1680*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      672*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 3600*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      1440*Sqrt[10*(5 - Sqrt[5])]*x^3 - 800*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 - 104920*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      41968*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 234520*Sqrt[2*(5 - Sqrt[5])]*x*
       y + 93808*Sqrt[10*(5 - Sqrt[5])]*x*y + 11760*Sqrt[2*(5 + Sqrt[5])]*x*
       y + 5280*Sqrt[10*(5 + Sqrt[5])]*x*y + 76080*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y - 30432*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      170000*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 68000*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y - 1200*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 560*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y - 7640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 
      3056*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 17000*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 6800*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 1400*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 600*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 27280*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 10912*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      61000*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 24400*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 1100*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 500*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 8240*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      3296*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 18400*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 7360*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 
      1000*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 440*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 3580*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      1432*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 - 8000*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^3 + 3200*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 250*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^3 + 110*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -8936*Sqrt[25 - 5*Sqrt[5]] - 19880*Sqrt[5 - Sqrt[5]] + 
      16880*Sqrt[5 + Sqrt[5]] + 7520*Sqrt[5*(5 + Sqrt[5])] + 
      7056*Sqrt[25 - 5*Sqrt[5]]*x + 15440*Sqrt[5 - Sqrt[5]]*x - 
      4800*Sqrt[5 + Sqrt[5]]*x - 2080*Sqrt[5*(5 + Sqrt[5])]*x - 
      2880*Sqrt[25 - 5*Sqrt[5]]*x^2 - 6000*Sqrt[5 - Sqrt[5]]*x^2 - 
      4120*Sqrt[5 + Sqrt[5]]*x^2 - 1960*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      40*Sqrt[25 - 5*Sqrt[5]]*x^3 - 280*Sqrt[5 - Sqrt[5]]*x^3 - 
      40*(5 + Sqrt[5])^(3/2)*x^3 - 8996*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      20100*Sqrt[5 - Sqrt[5]]*x*y + 4680*Sqrt[5 + Sqrt[5]]*x*y + 
      2080*Sqrt[5*(5 + Sqrt[5])]*x*y + 6560*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      14560*Sqrt[5 - Sqrt[5]]*x^2*y + 1840*Sqrt[5 + Sqrt[5]]*x^2*y + 
      880*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 120*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      160*Sqrt[5 - Sqrt[5]]*x^3*y + 300*Sqrt[5 + Sqrt[5]]*x^3*y + 
      100*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 2470*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      5510*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 1980*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      880*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 220*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      460*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 200*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      80*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 135*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      295*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 50*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      20*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 616*Sqrt[2*(25 - 5*Sqrt[5])] + 
      1200*Sqrt[2*(5 - Sqrt[5])] + 180*Sqrt[2*(5 + Sqrt[5])] + 
      220*Sqrt[10*(5 + Sqrt[5])] + 64*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      760*Sqrt[2*(5 - Sqrt[5])]*x + 1260*Sqrt[2*(5 + Sqrt[5])]*x + 
      180*Sqrt[10*(5 + Sqrt[5])]*x - 240*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      200*Sqrt[2*(5 + Sqrt[5])]*x^2 + 40*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      364*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 960*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      530*Sqrt[2*(5 + Sqrt[5])]*x*y - 150*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      60*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y + 180*Sqrt[2*(5 - Sqrt[5])]*x^2*y + 
      20*Sqrt[2]*(5 + Sqrt[5])^(3/2)*x^2*y - 30*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 90*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 
      10*Sqrt[2]*(5 + Sqrt[5])^(3/2)*x^2*y^2, 19080*Sqrt[25 - 5*Sqrt[5]] + 
      42760*Sqrt[5 - Sqrt[5]] + 3280*Sqrt[5 + Sqrt[5]] + 
      1440*Sqrt[5*(5 + Sqrt[5])] - 3040*Sqrt[25 - 5*Sqrt[5]]*x - 
      7200*Sqrt[5 - Sqrt[5]]*x - 3840*Sqrt[5 + Sqrt[5]]*x - 
      1600*Sqrt[5*(5 + Sqrt[5])]*x - 960*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      1680*Sqrt[5 - Sqrt[5]]*x^2 + 760*Sqrt[5 + Sqrt[5]]*x^2 + 
      200*Sqrt[5*(5 + Sqrt[5])]*x^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      280*Sqrt[5 - Sqrt[5]]*x^3 - 40*(5 + Sqrt[5])^(3/2)*x^3 + 
      10540*Sqrt[25 - 5*Sqrt[5]]*x*y + 23580*Sqrt[5 - Sqrt[5]]*x*y + 
      1680*Sqrt[5 + Sqrt[5]]*x*y + 760*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      520*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 1080*Sqrt[5 - Sqrt[5]]*x^2*y - 
      520*Sqrt[5 + Sqrt[5]]*x^2*y - 200*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      120*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 160*Sqrt[5 - Sqrt[5]]*x^3*y + 
      300*Sqrt[5 + Sqrt[5]]*x^3*y + 100*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      290*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 650*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      40*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 20*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      220*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 460*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      200*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 80*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      135*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 295*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      50*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -5520*Sqrt[2*(25 - 5*Sqrt[5])] + 2208*Sqrt[10*(25 - 5*Sqrt[5])] - 
      12400*Sqrt[2*(5 - Sqrt[5])] + 4960*Sqrt[10*(5 - Sqrt[5])] + 
      2800*Sqrt[2*(5 + Sqrt[5])] + 1200*Sqrt[10*(5 + Sqrt[5])] - 
      2000*Sqrt[2*(25 - 5*Sqrt[5])]*x + 800*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      4400*Sqrt[2*(5 - Sqrt[5])]*x + 1760*Sqrt[10*(5 - Sqrt[5])]*x - 
      2000*Sqrt[2*(5 + Sqrt[5])]*x - 720*Sqrt[10*(5 + Sqrt[5])]*x - 
      880*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 352*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 
      2000*Sqrt[2*(5 - Sqrt[5])]*x^2 + 800*Sqrt[10*(5 - Sqrt[5])]*x^2 + 
      400*Sqrt[2*(5 + Sqrt[5])]*x^2 + 80*Sqrt[10*(5 + Sqrt[5])]*x^2 + 
      3040*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 1216*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 6800*Sqrt[2*(5 - Sqrt[5])]*x*y - 2720*Sqrt[10*(5 - Sqrt[5])]*x*y + 
      1000*Sqrt[2*(5 + Sqrt[5])]*x*y + 440*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      1160*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 464*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y + 2600*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 1040*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y - 400*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y - 580*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      232*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 1300*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 + 520*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 200*Sqrt[2*(5 + Sqrt[5])]*
       x^2*y^2 + 80*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2, 
     -195120*Sqrt[2*(25 - 5*Sqrt[5])] + 78048*Sqrt[10*(25 - 5*Sqrt[5])] - 
      436400*Sqrt[2*(5 - Sqrt[5])] + 174560*Sqrt[10*(5 - Sqrt[5])] + 
      48800*Sqrt[2*(5 + Sqrt[5])] + 21760*Sqrt[10*(5 + Sqrt[5])] + 
      74480*Sqrt[2*(25 - 5*Sqrt[5])]*x - 29792*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      166800*Sqrt[2*(5 - Sqrt[5])]*x - 66720*Sqrt[10*(5 - Sqrt[5])]*x - 
      20080*Sqrt[2*(5 + Sqrt[5])]*x - 8880*Sqrt[10*(5 + Sqrt[5])]*x - 
      77600*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 31040*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 173600*Sqrt[2*(5 - Sqrt[5])]*x^2 + 69440*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 1280*Sqrt[2*(5 + Sqrt[5])]*x^2 + 320*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 1440*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      576*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 3200*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      1280*Sqrt[10*(5 - Sqrt[5])]*x^3 - 1200*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      400*Sqrt[10*(5 + Sqrt[5])]*x^3 - 157760*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      63104*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 352800*Sqrt[2*(5 - Sqrt[5])]*x*
       y + 141120*Sqrt[10*(5 - Sqrt[5])]*x*y + 11920*Sqrt[2*(5 + Sqrt[5])]*x*
       y + 5360*Sqrt[10*(5 + Sqrt[5])]*x*y + 166720*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y - 66688*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      372800*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 149120*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y - 3360*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 1440*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y - 10120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 
      4048*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 22600*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 9040*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 2000*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 800*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 52320*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 20928*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      117000*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 46800*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 2980*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 1340*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 11720*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      4688*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 26200*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 10480*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 
      1400*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 600*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 5390*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      2156*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 - 12050*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 + 4820*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 
      350*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 150*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -120*Sqrt[25 - 5*Sqrt[5]] - 280*Sqrt[5 - Sqrt[5]] + 
      2000*Sqrt[5 + Sqrt[5]] + 896*Sqrt[5*(5 + Sqrt[5])] + 
      444*Sqrt[25 - 5*Sqrt[5]]*x + 1020*Sqrt[5 - Sqrt[5]]*x + 
      520*Sqrt[5 + Sqrt[5]]*x + 224*Sqrt[5*(5 + Sqrt[5])]*x - 
      204*Sqrt[25 - 5*Sqrt[5]]*x^2 - 460*Sqrt[5 - Sqrt[5]]*x^2 - 
      360*Sqrt[5 + Sqrt[5]]*x^2 - 160*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      1186*Sqrt[25 - 5*Sqrt[5]]*x*y - 2650*Sqrt[5 - Sqrt[5]]*x*y - 
      120*Sqrt[5 + Sqrt[5]]*x*y - 52*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      416*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 920*Sqrt[5 - Sqrt[5]]*x^2*y + 
      220*Sqrt[5 + Sqrt[5]]*x^2*y + 100*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      137*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 305*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      90*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 40*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 
     346560*Sqrt[2*(25 - 5*Sqrt[5])] - 138624*Sqrt[10*(25 - 5*Sqrt[5])] + 
      775200*Sqrt[2*(5 - Sqrt[5])] - 310080*Sqrt[10*(5 - Sqrt[5])] + 
      9040*Sqrt[2*(5 + Sqrt[5])] + 3760*Sqrt[10*(5 + Sqrt[5])] + 
      15680*Sqrt[2*(25 - 5*Sqrt[5])]*x - 6272*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      34400*Sqrt[2*(5 - Sqrt[5])]*x - 13760*Sqrt[10*(5 - Sqrt[5])]*x + 
      26160*Sqrt[2*(5 + Sqrt[5])]*x + 12240*Sqrt[10*(5 + Sqrt[5])]*x + 
      36080*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 14432*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 + 81200*Sqrt[2*(5 - Sqrt[5])]*x^2 - 32480*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 4800*Sqrt[2*(5 + Sqrt[5])]*x^2 - 2400*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 1680*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      672*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 3600*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      1440*Sqrt[10*(5 - Sqrt[5])]*x^3 - 800*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 + 36240*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      14496*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 81200*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      32480*Sqrt[10*(5 - Sqrt[5])]*x*y - 17680*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      8080*Sqrt[10*(5 + Sqrt[5])]*x*y - 43200*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y + 17280*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y - 
      96800*Sqrt[2*(5 - Sqrt[5])]*x^2*y + 38720*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 9200*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 4240*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y - 7640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 
      3056*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 17000*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 6800*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 1400*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 600*Sqrt[10*(5 + Sqrt[5])]*x^3*y + 14920*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 5968*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      33400*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 13360*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 7000*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 3160*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 8240*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      3296*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 18400*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 7360*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 
      1000*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 440*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 3580*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      1432*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 - 8000*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^3 + 3200*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 250*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^3 + 110*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     6056*Sqrt[25 - 5*Sqrt[5]] + 13480*Sqrt[5 - Sqrt[5]] - 
      5520*Sqrt[5 + Sqrt[5]] - 2496*Sqrt[5*(5 + Sqrt[5])] - 
      2680*Sqrt[25 - 5*Sqrt[5]]*x - 5800*Sqrt[5 - Sqrt[5]]*x + 
      3800*Sqrt[5 + Sqrt[5]]*x + 1752*Sqrt[5*(5 + Sqrt[5])]*x - 
      360*Sqrt[25 - 5*Sqrt[5]]*x^2 - 1000*Sqrt[5 - Sqrt[5]]*x^2 + 
      2320*Sqrt[5 + Sqrt[5]]*x^2 + 1024*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      104*Sqrt[25 - 5*Sqrt[5]]*x^3 + 280*Sqrt[5 - Sqrt[5]]*x^3 - 
      280*Sqrt[5 + Sqrt[5]]*x^3 - 120*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      2520*Sqrt[25 - 5*Sqrt[5]]*x*y + 5600*Sqrt[5 - Sqrt[5]]*x*y - 
      3500*Sqrt[5 + Sqrt[5]]*x*y - 1572*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      200*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 520*Sqrt[5 - Sqrt[5]]*x^2*y - 
      800*Sqrt[5 + Sqrt[5]]*x^2*y - 368*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      312*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 720*Sqrt[5 - Sqrt[5]]*x^3*y + 
      500*Sqrt[5 + Sqrt[5]]*x^3*y + 220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 
      440*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 980*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 
      1450*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 646*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 660*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      360*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 245*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      90*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     133520*Sqrt[2*(25 - 5*Sqrt[5])] - 53408*Sqrt[10*(25 - 5*Sqrt[5])] + 
      298800*Sqrt[2*(5 - Sqrt[5])] - 119520*Sqrt[10*(5 - Sqrt[5])] - 
      13040*Sqrt[2*(5 + Sqrt[5])] - 6000*Sqrt[10*(5 + Sqrt[5])] - 
      93520*Sqrt[2*(25 - 5*Sqrt[5])]*x + 37408*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      209840*Sqrt[2*(5 - Sqrt[5])]*x + 83936*Sqrt[10*(5 - Sqrt[5])]*x + 
      7440*Sqrt[2*(5 + Sqrt[5])]*x + 3920*Sqrt[10*(5 + Sqrt[5])]*x + 
      4480*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 1792*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 + 10560*Sqrt[2*(5 - Sqrt[5])]*x^2 - 4224*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 2080*Sqrt[2*(5 + Sqrt[5])]*x^2 + 480*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 256*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3 + 1280*Sqrt[2*(5 - Sqrt[5])]*x^3 - 512*Sqrt[10*(5 - Sqrt[5])]*
       x^3 - 960*Sqrt[2*(5 + Sqrt[5])]*x^3 - 320*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      98360*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 39344*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 220040*Sqrt[2*(5 - Sqrt[5])]*x*y - 88016*Sqrt[10*(5 - Sqrt[5])]*x*
       y - 5720*Sqrt[2*(5 + Sqrt[5])]*x*y - 2680*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      28720*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 11488*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 64080*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      25632*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 80*Sqrt[2]*(5 + Sqrt[5])^(3/2)*x^2*
       y + 32*Sqrt[10]*(5 + Sqrt[5])^(3/2)*x^2*y - 
      7840*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 3136*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y - 17440*Sqrt[2*(5 - Sqrt[5])]*x^3*y + 
      6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 1600*Sqrt[2*(5 + Sqrt[5])]*x^3*y + 
      640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 13800*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 5520*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      30840*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 12336*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 1800*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 840*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 - 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 + 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     29920*Sqrt[2*(25 - 5*Sqrt[5])] - 11968*Sqrt[10*(25 - 5*Sqrt[5])] + 
      67040*Sqrt[2*(5 - Sqrt[5])] - 26816*Sqrt[10*(5 - Sqrt[5])] + 
      1920*Sqrt[2*(5 + Sqrt[5])] + 832*Sqrt[10*(5 + Sqrt[5])] + 
      54240*Sqrt[2*(25 - 5*Sqrt[5])]*x - 21696*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      120960*Sqrt[2*(5 - Sqrt[5])]*x - 48384*Sqrt[10*(5 - Sqrt[5])]*x - 
      4880*Sqrt[2*(5 + Sqrt[5])]*x - 2224*Sqrt[10*(5 + Sqrt[5])]*x - 
      7520*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 3008*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 16480*Sqrt[2*(5 - Sqrt[5])]*x^2 + 6592*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 960*Sqrt[2*(5 + Sqrt[5])]*x^2 + 512*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 
      1920*Sqrt[2*(5 - Sqrt[5])]*x^3 + 768*Sqrt[10*(5 - Sqrt[5])]*x^3 + 
      240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      41320*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 16528*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 92360*Sqrt[2*(5 - Sqrt[5])]*x*y + 36944*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 2880*Sqrt[2*(5 + Sqrt[5])]*x*y + 1264*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      5120*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 2048*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 11360*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      4544*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 1360*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      624*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 5160*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y - 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 400*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      3800*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 1520*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 8480*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      3392*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 740*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 332*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 848*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 
      1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, -340*Sqrt[2*(25 - 5*Sqrt[5])] + 
      136*Sqrt[10*(25 - 5*Sqrt[5])] - 740*Sqrt[2*(5 - Sqrt[5])] + 
      296*Sqrt[10*(5 - Sqrt[5])] + 3040*Sqrt[2*(5 + Sqrt[5])] + 
      1336*Sqrt[10*(5 + Sqrt[5])] + 16840*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      6736*Sqrt[10*(25 - 5*Sqrt[5])]*x + 37600*Sqrt[2*(5 - Sqrt[5])]*x - 
      15040*Sqrt[10*(5 - Sqrt[5])]*x + 2660*Sqrt[2*(5 + Sqrt[5])]*x + 
      1228*Sqrt[10*(5 + Sqrt[5])]*x - 16660*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      6664*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 37180*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      14872*Sqrt[10*(5 - Sqrt[5])]*x^2 - 260*Sqrt[2*(5 + Sqrt[5])]*x^2 - 
      164*Sqrt[10*(5 + Sqrt[5])]*x^2 + 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 - 240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 12700*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      5080*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 28400*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      11360*Sqrt[10*(5 - Sqrt[5])]*x*y - 1230*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      538*Sqrt[10*(5 + Sqrt[5])]*x*y + 28740*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      11496*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 64260*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 25704*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 120*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y + 48*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 1960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y + 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 
      4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y + 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      8855*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 3542*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 19805*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      7922*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 125*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 61*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 960*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 5360*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      2144*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 460*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 + 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -309120*Sqrt[2*(25 - 5*Sqrt[5])] + 123648*Sqrt[10*(25 - 5*Sqrt[5])] - 
      691200*Sqrt[2*(5 - Sqrt[5])] + 276480*Sqrt[10*(5 - Sqrt[5])] + 
      54080*Sqrt[2*(5 + Sqrt[5])] + 24256*Sqrt[10*(5 + Sqrt[5])] + 
      82880*Sqrt[2*(25 - 5*Sqrt[5])]*x - 33152*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      185280*Sqrt[2*(5 - Sqrt[5])]*x - 74112*Sqrt[10*(5 - Sqrt[5])]*x - 
      6080*Sqrt[2*(5 + Sqrt[5])]*x - 2752*Sqrt[10*(5 + Sqrt[5])]*x - 
      30320*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 12128*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 67760*Sqrt[2*(5 - Sqrt[5])]*x^2 + 27104*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 10240*Sqrt[2*(5 + Sqrt[5])]*x^2 - 4704*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 - 160*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      71760*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 28704*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 160480*Sqrt[2*(5 - Sqrt[5])]*x*y + 64192*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 8200*Sqrt[2*(5 + Sqrt[5])]*x*y + 3672*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      69920*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 27968*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 156320*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      62528*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 5120*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      2368*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 31200*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 12480*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      69760*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 27904*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 4160*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 1856*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, -87360*Sqrt[2*(25 - 5*Sqrt[5])] + 
      34944*Sqrt[10*(25 - 5*Sqrt[5])] - 195200*Sqrt[2*(5 - Sqrt[5])] + 
      78080*Sqrt[10*(5 - Sqrt[5])] + 19040*Sqrt[2*(5 + Sqrt[5])] + 
      8480*Sqrt[10*(5 + Sqrt[5])] + 29280*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      11712*Sqrt[10*(25 - 5*Sqrt[5])]*x + 64960*Sqrt[2*(5 - Sqrt[5])]*x - 
      25984*Sqrt[10*(5 - Sqrt[5])]*x - 3440*Sqrt[2*(5 + Sqrt[5])]*x - 
      1360*Sqrt[10*(5 + Sqrt[5])]*x - 11200*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      4480*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 24640*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      9856*Sqrt[10*(5 - Sqrt[5])]*x^2 - 3520*Sqrt[2*(5 + Sqrt[5])]*x^2 - 
      1600*Sqrt[10*(5 + Sqrt[5])]*x^2 - 800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      320*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 1920*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      768*Sqrt[10*(5 - Sqrt[5])]*x^3 + 240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 35240*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      14096*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 78760*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      31504*Sqrt[10*(5 - Sqrt[5])]*x*y + 3920*Sqrt[2*(5 + Sqrt[5])]*x*y + 
      1760*Sqrt[10*(5 + Sqrt[5])]*x*y + 17760*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y - 7104*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 39680*Sqrt[2*(5 - Sqrt[5])]*
       x^2*y - 15872*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 
      1360*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 560*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 
      2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y - 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*
       y + 5160*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*
       y - 400*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y - 8960*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      3584*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 20040*Sqrt[2*(5 - Sqrt[5])]*
       x^2*y^2 + 8016*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 
      2100*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 940*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y^2 - 2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      848*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 + 1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 40780*Sqrt[2*(25 - 5*Sqrt[5])] - 
      16312*Sqrt[10*(25 - 5*Sqrt[5])] + 91260*Sqrt[2*(5 - Sqrt[5])] - 
      36504*Sqrt[10*(5 - Sqrt[5])] - 4320*Sqrt[2*(5 + Sqrt[5])] - 
      1992*Sqrt[10*(5 + Sqrt[5])] - 20920*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      8368*Sqrt[10*(25 - 5*Sqrt[5])]*x - 46960*Sqrt[2*(5 - Sqrt[5])]*x + 
      18784*Sqrt[10*(5 - Sqrt[5])]*x + 2540*Sqrt[2*(5 + Sqrt[5])]*x + 
      1284*Sqrt[10*(5 + Sqrt[5])]*x + 5740*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      2296*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 12980*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      5192*Sqrt[10*(5 - Sqrt[5])]*x^2 + 580*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      148*Sqrt[10*(5 + Sqrt[5])]*x^2 + 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 - 240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 + 21340*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      8536*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 47760*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      19104*Sqrt[10*(5 - Sqrt[5])]*x*y - 1970*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      934*Sqrt[10*(5 + Sqrt[5])]*x*y + 2060*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      824*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 4540*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 1816*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 80*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y + 104*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 1960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y + 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 
      4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y + 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      2575*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 1030*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 5745*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      2298*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 725*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 337*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 960*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 5360*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      2144*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 460*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 + 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     150240*Sqrt[2*(25 - 5*Sqrt[5])] - 60096*Sqrt[10*(25 - 5*Sqrt[5])] + 
      335840*Sqrt[2*(5 - Sqrt[5])] - 134336*Sqrt[10*(5 - Sqrt[5])] - 
      16320*Sqrt[2*(5 + Sqrt[5])] - 7296*Sqrt[10*(5 + Sqrt[5])] - 
      11520*Sqrt[2*(25 - 5*Sqrt[5])]*x + 4608*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      25600*Sqrt[2*(5 - Sqrt[5])]*x + 10240*Sqrt[10*(5 - Sqrt[5])]*x - 
      4160*Sqrt[2*(5 + Sqrt[5])]*x - 1728*Sqrt[10*(5 + Sqrt[5])]*x - 
      22480*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 8992*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 50320*Sqrt[2*(5 - Sqrt[5])]*x^2 + 20128*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 3840*Sqrt[2*(5 + Sqrt[5])]*x^2 + 1504*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 - 160*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      27920*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 11168*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 62400*Sqrt[2*(5 - Sqrt[5])]*x*y - 24960*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 1960*Sqrt[2*(5 + Sqrt[5])]*x*y + 888*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      33920*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 13568*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 75840*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      30336*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 3680*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      1568*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 12040*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 4816*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      26920*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 10768*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 880*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 384*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, -6760*Sqrt[25 - 5*Sqrt[5]] - 
      15080*Sqrt[5 - Sqrt[5]] + 13840*Sqrt[5 + Sqrt[5]] + 
      6208*Sqrt[5*(5 + Sqrt[5])] + 2744*Sqrt[25 - 5*Sqrt[5]]*x + 
      6120*Sqrt[5 - Sqrt[5]]*x + 3880*Sqrt[5 + Sqrt[5]]*x + 
      1704*Sqrt[5*(5 + Sqrt[5])]*x + 1592*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      3480*Sqrt[5 - Sqrt[5]]*x^2 - 3840*Sqrt[5 + Sqrt[5]]*x^2 - 
      1712*Sqrt[5*(5 + Sqrt[5])]*x^2 + 104*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      280*Sqrt[5 - Sqrt[5]]*x^3 - 280*Sqrt[5 + Sqrt[5]]*x^3 - 
      120*Sqrt[5*(5 + Sqrt[5])]*x^3 - 2304*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      5160*Sqrt[5 - Sqrt[5]]*x*y - 2580*Sqrt[5 + Sqrt[5]]*x*y - 
      1164*Sqrt[5*(5 + Sqrt[5])]*x*y - 1144*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      2520*Sqrt[5 - Sqrt[5]]*x^2*y + 4400*Sqrt[5 + Sqrt[5]]*x^2*y + 
      1984*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 312*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      720*Sqrt[5 - Sqrt[5]]*x^3*y + 500*Sqrt[5 + Sqrt[5]]*x^3*y + 
      220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 512*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      1140*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 1790*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      802*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      660*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 360*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      245*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 90*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, -160720*Sqrt[2*(25 - 5*Sqrt[5])] + 
      64288*Sqrt[10*(25 - 5*Sqrt[5])] - 359280*Sqrt[2*(5 - Sqrt[5])] + 
      143712*Sqrt[10*(5 - Sqrt[5])] + 35440*Sqrt[2*(5 + Sqrt[5])] + 
      15728*Sqrt[10*(5 + Sqrt[5])] + 37840*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      15136*Sqrt[10*(25 - 5*Sqrt[5])]*x + 84400*Sqrt[2*(5 - Sqrt[5])]*x - 
      33760*Sqrt[10*(5 - Sqrt[5])]*x + 9520*Sqrt[2*(5 + Sqrt[5])]*x + 
      4464*Sqrt[10*(5 + Sqrt[5])]*x - 59520*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      23808*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 132800*Sqrt[2*(5 - Sqrt[5])]*
       x^2 + 53120*Sqrt[10*(5 - Sqrt[5])]*x^2 - 8160*Sqrt[2*(5 + Sqrt[5])]*
       x^2 - 3872*Sqrt[10*(5 + Sqrt[5])]*x^2 + 640*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3 - 256*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 1280*Sqrt[2*(5 - Sqrt[5])]*
       x^3 - 512*Sqrt[10*(5 - Sqrt[5])]*x^3 - 960*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 - 33720*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      13488*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 75400*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      30160*Sqrt[10*(5 - Sqrt[5])]*x*y - 1960*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      904*Sqrt[10*(5 + Sqrt[5])]*x*y + 117200*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y - 46880*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      262000*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 104800*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 5200*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 2384*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y - 7840*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 
      3136*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 17440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 1600*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 37480*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 14992*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      83800*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 33520*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 1800*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 808*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 - 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 + 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -124640*Sqrt[2*(25 - 5*Sqrt[5])] + 49856*Sqrt[10*(25 - 5*Sqrt[5])] - 
      278560*Sqrt[2*(5 - Sqrt[5])] + 111424*Sqrt[10*(5 - Sqrt[5])] + 
      36320*Sqrt[2*(5 + Sqrt[5])] + 16224*Sqrt[10*(5 + Sqrt[5])] + 
      5920*Sqrt[2*(25 - 5*Sqrt[5])]*x - 2368*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      12800*Sqrt[2*(5 - Sqrt[5])]*x - 5120*Sqrt[10*(5 - Sqrt[5])]*x - 
      14960*Sqrt[2*(5 + Sqrt[5])]*x - 6608*Sqrt[10*(5 + Sqrt[5])]*x - 
      12480*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 4992*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 27520*Sqrt[2*(5 - Sqrt[5])]*x^2 + 11008*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 2400*Sqrt[2*(5 + Sqrt[5])]*x^2 - 1056*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3 - 1920*Sqrt[2*(5 - Sqrt[5])]*x^3 + 768*Sqrt[10*(5 - Sqrt[5])]*
       x^3 + 240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 80*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      11880*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 4752*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 26600*Sqrt[2*(5 - Sqrt[5])]*x*y - 10640*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 10320*Sqrt[2*(5 + Sqrt[5])]*x*y + 4608*Sqrt[10*(5 + Sqrt[5])]*x*
       y + 16240*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      6496*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 36240*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 14496*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 400*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y - 208*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 2280*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y - 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 
      5160*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      9360*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 3744*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 20920*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      8368*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 + 3140*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 + 1404*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 848*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 
      1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 46260*Sqrt[2*(25 - 5*Sqrt[5])] - 
      18504*Sqrt[10*(25 - 5*Sqrt[5])] + 103500*Sqrt[2*(5 - Sqrt[5])] - 
      41400*Sqrt[10*(5 - Sqrt[5])] - 4420*Sqrt[2*(5 + Sqrt[5])] - 
      2036*Sqrt[10*(5 + Sqrt[5])] - 27240*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      10896*Sqrt[10*(25 - 5*Sqrt[5])]*x - 61080*Sqrt[2*(5 - Sqrt[5])]*x + 
      24432*Sqrt[10*(5 - Sqrt[5])]*x - 40*Sqrt[2*(5 + Sqrt[5])]*x + 
      152*Sqrt[10*(5 + Sqrt[5])]*x + 5420*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 
      2168*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 + 12260*Sqrt[2*(5 - Sqrt[5])]*x^2 - 
      4904*Sqrt[10*(5 - Sqrt[5])]*x^2 + 1100*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      364*Sqrt[10*(5 + Sqrt[5])]*x^2 + 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 - 240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 + 18220*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      7288*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 40780*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      16312*Sqrt[10*(5 - Sqrt[5])]*x*y - 680*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      352*Sqrt[10*(5 + Sqrt[5])]*x*y + 4580*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      1832*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 10180*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 4072*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 440*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y - 128*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 1960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y + 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 
      4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y + 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      3075*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 1230*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 6865*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      2746*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 575*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 271*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      2400*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 960*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 5360*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      2144*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 460*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 + 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     106400*Sqrt[2*(25 - 5*Sqrt[5])] - 42560*Sqrt[10*(25 - 5*Sqrt[5])] + 
      237920*Sqrt[2*(5 - Sqrt[5])] - 95168*Sqrt[10*(5 - Sqrt[5])] - 
      3680*Sqrt[2*(5 + Sqrt[5])] - 1632*Sqrt[10*(5 + Sqrt[5])] + 
      22560*Sqrt[2*(25 - 5*Sqrt[5])]*x - 9024*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      50400*Sqrt[2*(5 - Sqrt[5])]*x - 20160*Sqrt[10*(5 - Sqrt[5])]*x - 
      6240*Sqrt[2*(5 + Sqrt[5])]*x - 2656*Sqrt[10*(5 + Sqrt[5])]*x - 
      24880*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 9952*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 55600*Sqrt[2*(5 - Sqrt[5])]*x^2 + 22240*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 4320*Sqrt[2*(5 + Sqrt[5])]*x^2 + 1728*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 - 160*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      50800*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 20320*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 113600*Sqrt[2*(5 - Sqrt[5])]*x*y + 45440*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 3400*Sqrt[2*(5 + Sqrt[5])]*x*y + 1496*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      50640*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 20256*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 113200*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      45280*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 4560*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 
      1936*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 21560*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 8624*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      48200*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 19280*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 1480*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 648*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 2600*Sqrt[25 - 5*Sqrt[5]] + 
      5800*Sqrt[5 - Sqrt[5]] + 9680*Sqrt[5 + Sqrt[5]] + 
      4320*Sqrt[5*(5 + Sqrt[5])] + 3208*Sqrt[25 - 5*Sqrt[5]]*x + 
      7320*Sqrt[5 - Sqrt[5]]*x + 9240*Sqrt[5 + Sqrt[5]]*x + 
      4120*Sqrt[5*(5 + Sqrt[5])]*x + 1448*Sqrt[25 - 5*Sqrt[5]]*x^2 + 
      3080*Sqrt[5 - Sqrt[5]]*x^2 - 4480*Sqrt[5 + Sqrt[5]]*x^2 - 
      2000*Sqrt[5*(5 + Sqrt[5])]*x^2 + 104*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      280*Sqrt[5 - Sqrt[5]]*x^3 - 280*Sqrt[5 + Sqrt[5]]*x^3 - 
      120*Sqrt[5*(5 + Sqrt[5])]*x^3 - 3088*Sqrt[25 - 5*Sqrt[5]]*x*y - 
      6920*Sqrt[5 - Sqrt[5]]*x*y - 5740*Sqrt[5 + Sqrt[5]]*x*y - 
      2580*Sqrt[5*(5 + Sqrt[5])]*x*y - 1376*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 
      3040*Sqrt[5 - Sqrt[5]]*x^2*y + 5520*Sqrt[5 + Sqrt[5]]*x^2*y + 
      2480*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 312*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      720*Sqrt[5 - Sqrt[5]]*x^3*y + 500*Sqrt[5 + Sqrt[5]]*x^3*y + 
      220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 788*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      1760*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 2570*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      1150*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      660*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 360*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      245*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 90*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, -92800*Sqrt[2*(25 - 5*Sqrt[5])] + 
      37120*Sqrt[10*(25 - 5*Sqrt[5])] - 207360*Sqrt[2*(5 - Sqrt[5])] + 
      82944*Sqrt[10*(5 - Sqrt[5])] + 46400*Sqrt[2*(5 + Sqrt[5])] + 
      20672*Sqrt[10*(5 + Sqrt[5])] + 16320*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      6528*Sqrt[10*(25 - 5*Sqrt[5])]*x + 36160*Sqrt[2*(5 - Sqrt[5])]*x - 
      14464*Sqrt[10*(5 - Sqrt[5])]*x + 13760*Sqrt[2*(5 + Sqrt[5])]*x + 
      6336*Sqrt[10*(5 + Sqrt[5])]*x - 51520*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      20608*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 114880*Sqrt[2*(5 - Sqrt[5])]*
       x^2 + 45952*Sqrt[10*(5 - Sqrt[5])]*x^2 - 10560*Sqrt[2*(5 + Sqrt[5])]*
       x^2 - 4928*Sqrt[10*(5 + Sqrt[5])]*x^2 + 640*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3 - 256*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 1280*Sqrt[2*(5 - Sqrt[5])]*
       x^3 - 512*Sqrt[10*(5 - Sqrt[5])]*x^3 - 960*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 + 21760*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      8704*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 48640*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      19456*Sqrt[10*(5 - Sqrt[5])]*x*y - 4160*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      1856*Sqrt[10*(5 + Sqrt[5])]*x*y + 96320*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y - 38528*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      215360*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 86144*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 7680*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 3456*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y - 7840*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 
      3136*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 17440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 1600*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 30800*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 12320*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      68880*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 27552*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 1120*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 512*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 - 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 + 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -161760*Sqrt[2*(25 - 5*Sqrt[5])] + 64704*Sqrt[10*(25 - 5*Sqrt[5])] - 
      361760*Sqrt[2*(5 - Sqrt[5])] + 144704*Sqrt[10*(5 - Sqrt[5])] + 
      50080*Sqrt[2*(5 + Sqrt[5])] + 22432*Sqrt[10*(5 + Sqrt[5])] + 
      8960*Sqrt[2*(25 - 5*Sqrt[5])]*x - 3584*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      20160*Sqrt[2*(5 - Sqrt[5])]*x - 8064*Sqrt[10*(5 - Sqrt[5])]*x - 
      3360*Sqrt[2*(5 + Sqrt[5])]*x - 1504*Sqrt[10*(5 + Sqrt[5])]*x - 
      27920*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 11168*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 62480*Sqrt[2*(5 - Sqrt[5])]*x^2 + 24992*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 10720*Sqrt[2*(5 + Sqrt[5])]*x^2 - 4928*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 1040*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 
      416*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 2320*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      928*Sqrt[10*(5 - Sqrt[5])]*x^3 - 160*Sqrt[2*(5 + Sqrt[5])]*x^3 + 
      20160*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 8064*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y + 45040*Sqrt[2*(5 - Sqrt[5])]*x*y - 18016*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 6440*Sqrt[2*(5 + Sqrt[5])]*x*y + 2904*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      53200*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 21280*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 118960*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      47584*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 6000*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      2736*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 200*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y + 80*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 176*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 200*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 21680*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 8672*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      48480*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 19392*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 3560*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 1592*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 1360*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      544*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 3040*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 1216*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 120*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 40*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      1020*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 408*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 2280*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      912*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 30*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 
      10*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 2152*Sqrt[25 - 5*Sqrt[5]] + 
      4840*Sqrt[5 - Sqrt[5]] + 2960*Sqrt[5 + Sqrt[5]] + 
      1312*Sqrt[5*(5 + Sqrt[5])] - 5240*Sqrt[25 - 5*Sqrt[5]]*x - 
      11720*Sqrt[5 - Sqrt[5]]*x - 1240*Sqrt[5 + Sqrt[5]]*x - 
      504*Sqrt[5*(5 + Sqrt[5])]*x - 216*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      600*Sqrt[5 - Sqrt[5]]*x^2 + 2960*Sqrt[5 + Sqrt[5]]*x^2 + 
      1312*Sqrt[5*(5 + Sqrt[5])]*x^2 + 104*Sqrt[25 - 5*Sqrt[5]]*x^3 + 
      280*Sqrt[5 - Sqrt[5]]*x^3 - 280*Sqrt[5 + Sqrt[5]]*x^3 - 
      120*Sqrt[5*(5 + Sqrt[5])]*x^3 + 4000*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      8920*Sqrt[5 - Sqrt[5]]*x*y - 500*Sqrt[5 + Sqrt[5]]*x*y - 
      236*Sqrt[5*(5 + Sqrt[5])]*x*y + 432*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      1040*Sqrt[5 - Sqrt[5]]*x^2*y - 1920*Sqrt[5 + Sqrt[5]]*x^2*y - 
      864*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 312*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      720*Sqrt[5 - Sqrt[5]]*x^3*y + 500*Sqrt[5 + Sqrt[5]]*x^3*y + 
      220*Sqrt[5*(5 + Sqrt[5])]*x^3*y + 164*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 
      360*Sqrt[5 - Sqrt[5]]*x^2*y^2 - 670*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 
      298*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 292*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      660*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 360*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      160*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 109*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      245*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 90*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      40*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 169120*Sqrt[2*(25 - 5*Sqrt[5])] - 
      67648*Sqrt[10*(25 - 5*Sqrt[5])] + 378400*Sqrt[2*(5 - Sqrt[5])] - 
      151360*Sqrt[10*(5 - Sqrt[5])] - 15360*Sqrt[2*(5 + Sqrt[5])] - 
      7104*Sqrt[10*(5 + Sqrt[5])] - 111840*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      44736*Sqrt[10*(25 - 5*Sqrt[5])]*x - 250720*Sqrt[2*(5 - Sqrt[5])]*x + 
      100288*Sqrt[10*(5 - Sqrt[5])]*x + 3840*Sqrt[2*(5 + Sqrt[5])]*x + 
      2368*Sqrt[10*(5 + Sqrt[5])]*x - 3520*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      1408*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 7360*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      2944*Sqrt[10*(5 - Sqrt[5])]*x^2 + 4480*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      1536*Sqrt[10*(5 + Sqrt[5])]*x^2 + 640*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      256*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 1280*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      512*Sqrt[10*(5 - Sqrt[5])]*x^3 - 960*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 + 56080*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      22432*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 125520*Sqrt[2*(5 - Sqrt[5])]*x*
       y - 50208*Sqrt[10*(5 - Sqrt[5])]*x*y - 3840*Sqrt[2*(5 + Sqrt[5])]*x*
       y - 1888*Sqrt[10*(5 + Sqrt[5])]*x*y + 49600*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y - 19840*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      110720*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 44288*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y - 2720*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 992*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y - 7840*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 
      3136*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 17440*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 6976*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 1600*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 640*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 20480*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 8192*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      45760*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 18304*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 1120*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 544*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 9600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      3840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 21440*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 8576*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 
      1120*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 480*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 4600*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      1840*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 - 10280*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 + 4112*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 
      280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     97760*Sqrt[2*(25 - 5*Sqrt[5])] - 39104*Sqrt[10*(25 - 5*Sqrt[5])] + 
      218720*Sqrt[2*(5 - Sqrt[5])] - 87488*Sqrt[10*(5 - Sqrt[5])] + 
      3840*Sqrt[2*(5 + Sqrt[5])] + 1728*Sqrt[10*(5 + Sqrt[5])] + 
      110720*Sqrt[2*(25 - 5*Sqrt[5])]*x - 44288*Sqrt[10*(25 - 5*Sqrt[5])]*x + 
      247200*Sqrt[2*(5 - Sqrt[5])]*x - 98880*Sqrt[10*(5 - Sqrt[5])]*x - 
      3280*Sqrt[2*(5 + Sqrt[5])]*x - 1456*Sqrt[10*(5 + Sqrt[5])]*x - 
      6240*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 2496*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 - 13600*Sqrt[2*(5 - Sqrt[5])]*x^2 + 5440*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 160*Sqrt[2*(5 + Sqrt[5])]*x^2 - 32*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      800*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 
      1920*Sqrt[2*(5 - Sqrt[5])]*x^3 + 768*Sqrt[10*(5 - Sqrt[5])]*x^3 + 
      240*Sqrt[2*(5 + Sqrt[5])]*x^3 + 80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 
      111720*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 44688*Sqrt[10*(25 - 5*Sqrt[5])]*x*
       y - 249800*Sqrt[2*(5 - Sqrt[5])]*x*y + 99920*Sqrt[10*(5 - Sqrt[5])]*x*
       y + 1440*Sqrt[2*(5 + Sqrt[5])]*x*y + 656*Sqrt[10*(5 + Sqrt[5])]*x*y + 
      6640*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 2656*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y + 14800*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 
      5920*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 400*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 
      144*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 2280*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y - 912*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y + 5160*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y - 2064*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 400*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y - 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      3400*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 1360*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 7600*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      3040*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 300*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 132*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      2120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 848*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 4760*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 + 
      1904*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      790*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 316*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 + 1770*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 
      708*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 - 70*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 - 
      30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 1820*Sqrt[2*(25 - 5*Sqrt[5])] - 
      728*Sqrt[10*(25 - 5*Sqrt[5])] + 4100*Sqrt[2*(5 - Sqrt[5])] - 
      1640*Sqrt[10*(5 - Sqrt[5])] + 7940*Sqrt[2*(5 + Sqrt[5])] + 
      3540*Sqrt[10*(5 + Sqrt[5])] + 31440*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      12576*Sqrt[10*(25 - 5*Sqrt[5])]*x + 70240*Sqrt[2*(5 - Sqrt[5])]*x - 
      28096*Sqrt[10*(5 - Sqrt[5])]*x + 2760*Sqrt[2*(5 + Sqrt[5])]*x + 
      1240*Sqrt[10*(5 + Sqrt[5])]*x - 16340*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      6536*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 36460*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      14584*Sqrt[10*(5 - Sqrt[5])]*x^2 - 780*Sqrt[2*(5 + Sqrt[5])]*x^2 - 
      380*Sqrt[10*(5 + Sqrt[5])]*x^2 + 160*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      64*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 320*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      128*Sqrt[10*(5 - Sqrt[5])]*x^3 - 240*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      80*Sqrt[10*(5 + Sqrt[5])]*x^3 - 15400*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 
      6160*Sqrt[10*(25 - 5*Sqrt[5])]*x*y - 34440*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      13776*Sqrt[10*(5 - Sqrt[5])]*x*y - 1280*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      560*Sqrt[10*(5 + Sqrt[5])]*x*y + 26220*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      10488*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 58620*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 23448*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 640*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y + 280*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 1960*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y + 784*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 
      4360*Sqrt[2*(5 - Sqrt[5])]*x^3*y + 1744*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 
      400*Sqrt[2*(5 + Sqrt[5])]*x^3*y + 160*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      8355*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 3342*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 18685*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 
      7474*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 25*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 5*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 2400*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 960*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 
      5360*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 2144*Sqrt[10*(5 - Sqrt[5])]*x^3*
       y^2 - 280*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 120*Sqrt[10*(5 + Sqrt[5])]*
       x^3*y^2 - 1150*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      460*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 - 2570*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^3 + 1028*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 70*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^3 + 30*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -3848*Sqrt[25 - 5*Sqrt[5]] - 8608*Sqrt[5 - Sqrt[5]] + 
      7460*Sqrt[5 + Sqrt[5]] + 3340*Sqrt[5*(5 + Sqrt[5])] + 
      324*Sqrt[25 - 5*Sqrt[5]]*x + 748*Sqrt[5 - Sqrt[5]]*x - 
      1220*Sqrt[5 + Sqrt[5]]*x - 548*Sqrt[5*(5 + Sqrt[5])]*x + 
      52*Sqrt[25 - 5*Sqrt[5]]*x^2 + 100*Sqrt[5 - Sqrt[5]]*x^2 - 
      1200*Sqrt[5 + Sqrt[5]]*x^2 - 536*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      38*Sqrt[25 - 5*Sqrt[5]]*x*y - 98*Sqrt[5 - Sqrt[5]]*x*y + 
      1070*Sqrt[5 + Sqrt[5]]*x*y + 478*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      104*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 240*Sqrt[5 - Sqrt[5]]*x^2*y + 
      740*Sqrt[5 + Sqrt[5]]*x^2*y + 332*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      101*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 225*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      300*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 134*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 
     165440*Sqrt[2*(25 - 5*Sqrt[5])] - 66176*Sqrt[10*(25 - 5*Sqrt[5])] + 
      370080*Sqrt[2*(5 - Sqrt[5])] - 148032*Sqrt[10*(5 - Sqrt[5])] - 
      14960*Sqrt[2*(5 + Sqrt[5])] - 6800*Sqrt[10*(5 + Sqrt[5])] - 
      40800*Sqrt[2*(25 - 5*Sqrt[5])]*x + 16320*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      91680*Sqrt[2*(5 - Sqrt[5])]*x + 36672*Sqrt[10*(5 - Sqrt[5])]*x - 
      7520*Sqrt[2*(5 + Sqrt[5])]*x - 3040*Sqrt[10*(5 + Sqrt[5])]*x + 
      6800*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 2720*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 + 15600*Sqrt[2*(5 - Sqrt[5])]*x^2 - 6240*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 6000*Sqrt[2*(5 + Sqrt[5])]*x^2 + 2480*Sqrt[10*(5 + Sqrt[5])]*
       x^2 + 1680*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      672*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 3600*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      1440*Sqrt[10*(5 - Sqrt[5])]*x^3 - 800*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      320*Sqrt[10*(5 + Sqrt[5])]*x^3 + 52080*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      20832*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 116480*Sqrt[2*(5 - Sqrt[5])]*x*
       y - 46592*Sqrt[10*(5 - Sqrt[5])]*x*y - 40*Sqrt[2*(5 + Sqrt[5])]*x*y - 
      120*Sqrt[10*(5 + Sqrt[5])]*x*y + 8080*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      3232*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 18000*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 7200*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 2400*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y - 960*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 7640*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3*y + 3056*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 
      17000*Sqrt[2*(5 - Sqrt[5])]*x^3*y + 6800*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 
      1400*Sqrt[2*(5 + Sqrt[5])]*x^3*y + 600*Sqrt[10*(5 + Sqrt[5])]*x^3*y + 
      3120*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 1248*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 7000*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 
      2800*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 3300*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 1500*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      8240*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 3296*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 + 18400*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      7360*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 1000*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 440*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 
      3580*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 1432*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^3 - 8000*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 + 
      3200*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 250*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^3 + 110*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 3264*Sqrt[25 - 5*Sqrt[5]] + 
      7520*Sqrt[5 - Sqrt[5]] + 80*Sqrt[5 + Sqrt[5]] - 
      80*Sqrt[5*(5 + Sqrt[5])] + 656*Sqrt[25 - 5*Sqrt[5]]*x + 
      640*Sqrt[5 - Sqrt[5]]*x - 5000*Sqrt[5 + Sqrt[5]]*x - 
      1880*Sqrt[5*(5 + Sqrt[5])]*x - 1480*Sqrt[25 - 5*Sqrt[5]]*x^2 - 
      2600*Sqrt[5 - Sqrt[5]]*x^2 + 2880*Sqrt[5 + Sqrt[5]]*x^2 + 
      1040*Sqrt[5*(5 + Sqrt[5])]*x^2 - 40*Sqrt[25 - 5*Sqrt[5]]*x^3 - 
      280*Sqrt[5 - Sqrt[5]]*x^3 - 40*(5 + Sqrt[5])^(3/2)*x^3 - 
      1196*Sqrt[25 - 5*Sqrt[5]]*x*y - 2500*Sqrt[5 - Sqrt[5]]*x*y + 
      2780*Sqrt[5 + Sqrt[5]]*x*y + 1180*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      3760*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 8160*Sqrt[5 - Sqrt[5]]*x^2*y - 
      3160*Sqrt[5 + Sqrt[5]]*x^2*y - 1320*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      120*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 160*Sqrt[5 - Sqrt[5]]*x^3*y + 
      300*Sqrt[5 + Sqrt[5]]*x^3*y + 100*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      1920*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 4260*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      1230*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 530*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      220*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 460*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      200*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 80*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 
      135*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 295*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 
      50*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 20*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     616*Sqrt[2*(25 - 5*Sqrt[5])] + 1400*Sqrt[2*(5 - Sqrt[5])] + 
      280*Sqrt[2*(5 + Sqrt[5])] + 120*Sqrt[10*(5 + Sqrt[5])] + 
      664*Sqrt[2*(25 - 5*Sqrt[5])]*x + 1160*Sqrt[2*(5 - Sqrt[5])]*x - 
      40*Sqrt[2*(5 + Sqrt[5])]*x + 280*Sqrt[10*(5 + Sqrt[5])]*x + 
      160*Sqrt[2*(5 - Sqrt[5])]*x^2 - 160*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      564*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 1260*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      180*Sqrt[2*(5 + Sqrt[5])]*x*y - 100*Sqrt[10*(5 + Sqrt[5])]*x*y - 
      40*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 120*Sqrt[2*(5 - Sqrt[5])]*x^2*y + 
      200*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 120*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 
      20*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 60*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 - 100*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 60*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2, 6480*Sqrt[2*(25 - 5*Sqrt[5])] - 
      2592*Sqrt[10*(25 - 5*Sqrt[5])] + 14480*Sqrt[2*(5 - Sqrt[5])] - 
      5792*Sqrt[10*(5 - Sqrt[5])] + 28480*Sqrt[2*(5 + Sqrt[5])] + 
      12640*Sqrt[10*(5 + Sqrt[5])] + 12640*Sqrt[2*(25 - 5*Sqrt[5])]*x - 
      5056*Sqrt[10*(25 - 5*Sqrt[5])]*x + 28320*Sqrt[2*(5 - Sqrt[5])]*x - 
      11328*Sqrt[10*(5 - Sqrt[5])]*x + 21280*Sqrt[2*(5 + Sqrt[5])]*x + 
      9760*Sqrt[10*(5 + Sqrt[5])]*x - 57040*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      22816*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 127600*Sqrt[2*(5 - Sqrt[5])]*
       x^2 + 51040*Sqrt[10*(5 - Sqrt[5])]*x^2 - 7440*Sqrt[2*(5 + Sqrt[5])]*
       x^2 - 3600*Sqrt[10*(5 + Sqrt[5])]*x^2 + 1440*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^3 - 576*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 3200*Sqrt[2*(5 - Sqrt[5])]*
       x^3 - 1280*Sqrt[10*(5 - Sqrt[5])]*x^3 - 1200*Sqrt[2*(5 + Sqrt[5])]*
       x^3 - 400*Sqrt[10*(5 + Sqrt[5])]*x^3 + 11240*Sqrt[2*(25 - 5*Sqrt[5])]*
       x*y - 4496*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 25080*Sqrt[2*(5 - Sqrt[5])]*
       x*y - 10032*Sqrt[10*(5 - Sqrt[5])]*x*y - 9880*Sqrt[2*(5 + Sqrt[5])]*x*
       y - 4440*Sqrt[10*(5 + Sqrt[5])]*x*y + 101040*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y - 40416*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 
      226000*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 90400*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y + 6480*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 2960*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y - 10120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 
      4048*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y - 22600*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 9040*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 2000*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 800*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 27500*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 11000*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      61500*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 24600*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 640*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 280*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 11720*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      4688*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 26200*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 10480*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 
      1400*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 600*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 5390*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      2156*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 - 12050*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 + 4820*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 
      350*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 150*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     -72*Sqrt[25 - 5*Sqrt[5]] - 136*Sqrt[5 - Sqrt[5]] + 
      6032*Sqrt[5 + Sqrt[5]] + 2688*Sqrt[5*(5 + Sqrt[5])] + 
      136*Sqrt[25 - 5*Sqrt[5]]*x + 216*Sqrt[5 - Sqrt[5]]*x - 
      72*Sqrt[5 + Sqrt[5]]*x - 8*Sqrt[5*(5 + Sqrt[5])]*x - 
      696*Sqrt[25 - 5*Sqrt[5]]*x^2 - 1464*Sqrt[5 - Sqrt[5]]*x^2 - 
      880*Sqrt[5 + Sqrt[5]]*x^2 - 416*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      8*Sqrt[25 - 5*Sqrt[5]]*x^3 - 56*Sqrt[5 - Sqrt[5]]*x^3 - 
      8*(5 + Sqrt[5])^(3/2)*x^3 + 728*Sqrt[25 - 5*Sqrt[5]]*x*y + 
      1632*Sqrt[5 - Sqrt[5]]*x*y + 516*Sqrt[5 + Sqrt[5]]*x*y + 
      236*Sqrt[5*(5 + Sqrt[5])]*x*y + 992*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 
      2208*Sqrt[5 - Sqrt[5]]*x^2*y + 400*Sqrt[5 + Sqrt[5]]*x^2*y + 
      176*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 24*Sqrt[25 - 5*Sqrt[5]]*x^3*y - 
      32*Sqrt[5 - Sqrt[5]]*x^3*y + 60*Sqrt[5 + Sqrt[5]]*x^3*y + 
      20*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 376*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 
      844*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 430*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 
      194*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 44*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 + 
      92*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 40*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 
      16*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 - 27*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 - 
      59*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 10*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 
      4*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 2208*Sqrt[(2*(25 - 5*Sqrt[5]))/5] - 
      1104*Sqrt[2*(25 - 5*Sqrt[5])] - 2480*Sqrt[2*(5 - Sqrt[5])] + 
      992*Sqrt[10*(5 - Sqrt[5])] + 560*Sqrt[2*(5 + Sqrt[5])] + 
      240*Sqrt[10*(5 + Sqrt[5])] - 400*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      160*Sqrt[10*(25 - 5*Sqrt[5])]*x - 880*Sqrt[2*(5 - Sqrt[5])]*x + 
      352*Sqrt[10*(5 - Sqrt[5])]*x - 400*Sqrt[2*(5 + Sqrt[5])]*x - 
      144*Sqrt[10*(5 + Sqrt[5])]*x + 352*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 - 
      176*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 - 400*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      160*Sqrt[10*(5 - Sqrt[5])]*x^2 + 80*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      16*Sqrt[10*(5 + Sqrt[5])]*x^2 - 1216*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x*y + 
      608*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 1360*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      544*Sqrt[10*(5 - Sqrt[5])]*x*y + 200*Sqrt[2*(5 + Sqrt[5])]*x*y + 
      88*Sqrt[10*(5 + Sqrt[5])]*x*y - 464*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2*
       y + 232*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y + 520*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 208*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 80*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y - 32*Sqrt[10*(5 + Sqrt[5])]*x^2*y + 232*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*
       x^2*y^2 - 116*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      260*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 104*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 + 40*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 16*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y^2, 230400*Sqrt[2*(25 - 5*Sqrt[5])] - 
      92160*Sqrt[10*(25 - 5*Sqrt[5])] + 515200*Sqrt[2*(5 - Sqrt[5])] - 
      206080*Sqrt[10*(5 - Sqrt[5])] - 13120*Sqrt[2*(5 + Sqrt[5])] - 
      6080*Sqrt[10*(5 + Sqrt[5])] - 120160*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      48064*Sqrt[10*(25 - 5*Sqrt[5])]*x - 268800*Sqrt[2*(5 - Sqrt[5])]*x + 
      107520*Sqrt[10*(5 - Sqrt[5])]*x - 9520*Sqrt[2*(5 + Sqrt[5])]*x - 
      3600*Sqrt[10*(5 + Sqrt[5])]*x - 13280*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 
      5312*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 29600*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      11840*Sqrt[10*(5 - Sqrt[5])]*x^2 + 9440*Sqrt[2*(5 + Sqrt[5])]*x^2 + 
      3680*Sqrt[10*(5 + Sqrt[5])]*x^2 + 1440*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      576*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 + 3200*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      1280*Sqrt[10*(5 - Sqrt[5])]*x^3 - 1200*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      400*Sqrt[10*(5 + Sqrt[5])]*x^3 + 32440*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 
      12976*Sqrt[10*(25 - 5*Sqrt[5])]*x*y + 72600*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      29040*Sqrt[10*(5 - Sqrt[5])]*x*y + 1600*Sqrt[2*(5 + Sqrt[5])]*x*y + 
      560*Sqrt[10*(5 + Sqrt[5])]*x*y + 68560*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y - 
      27424*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y + 153200*Sqrt[2*(5 - Sqrt[5])]*
       x^2*y - 61280*Sqrt[10*(5 - Sqrt[5])]*x^2*y - 
      6480*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 2640*Sqrt[10*(5 + Sqrt[5])]*x^2*y - 
      10120*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 4048*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y - 22600*Sqrt[2*(5 - Sqrt[5])]*x^3*y + 
      9040*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 2000*Sqrt[2*(5 + Sqrt[5])]*x^3*y + 
      800*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 21480*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y^2 + 8592*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*y^2 - 
      48000*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 19200*Sqrt[10*(5 - Sqrt[5])]*x^2*
       y^2 - 1460*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 700*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y^2 + 11720*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      4688*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 + 26200*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 - 10480*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 
      1400*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 600*Sqrt[10*(5 + Sqrt[5])]*x^3*
       y^2 - 5390*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 + 
      2156*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^3 - 12050*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 + 4820*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 
      350*Sqrt[2*(5 + Sqrt[5])]*x^3*y^3 + 150*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3, 
     116*Sqrt[25 - 5*Sqrt[5]] - 244*Sqrt[5 - Sqrt[5]] + 
      132*Sqrt[5 + Sqrt[5]] - 44*Sqrt[5*(5 + Sqrt[5])] - 
      360*Sqrt[25 - 5*Sqrt[5]]*x + 840*Sqrt[5 - Sqrt[5]]*x + 
      152*Sqrt[5 + Sqrt[5]]*x - 72*Sqrt[5*(5 + Sqrt[5])]*x + 
      140*Sqrt[25 - 5*Sqrt[5]]*x^2 - 316*Sqrt[5 - Sqrt[5]]*x^2 - 
      44*Sqrt[5 + Sqrt[5]]*x^2 + 20*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      4*Sqrt[25 - 5*Sqrt[5]]*x*y - 60*Sqrt[5 - Sqrt[5]]*x*y + 
      40*Sqrt[5 + Sqrt[5]]*x*y - 16*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      52*Sqrt[25 - 5*Sqrt[5]]*x^2*y - 108*Sqrt[5 - Sqrt[5]]*x^2*y - 
      72*Sqrt[5 + Sqrt[5]]*x^2*y + 32*Sqrt[5*(5 + Sqrt[5])]*x^2*y - 
      19*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 39*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      11*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 5*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2, 
     -87552*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 43776*Sqrt[2*(25 - 5*Sqrt[5])] + 
      97920*Sqrt[2*(5 - Sqrt[5])] - 39168*Sqrt[10*(5 - Sqrt[5])] + 
      5504*Sqrt[2*(5 + Sqrt[5])] + 2432*Sqrt[10*(5 + Sqrt[5])] - 
      41408*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x + 20704*Sqrt[2*(25 - 5*Sqrt[5])]*
       x + 46240*Sqrt[2*(5 - Sqrt[5])]*x - 18496*Sqrt[10*(5 - Sqrt[5])]*x + 
      4896*Sqrt[2*(5 + Sqrt[5])]*x + 2208*Sqrt[10*(5 + Sqrt[5])]*x + 
      2272*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2 - 1136*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2 - 2480*Sqrt[2*(5 - Sqrt[5])]*x^2 + 992*Sqrt[10*(5 - Sqrt[5])]*
       x^2 - 1920*Sqrt[2*(5 + Sqrt[5])]*x^2 - 864*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 672*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3 + 
      336*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 + 720*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      288*Sqrt[10*(5 - Sqrt[5])]*x^3 - 160*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      64*Sqrt[10*(5 + Sqrt[5])]*x^3 + 23904*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x*
       y - 11952*Sqrt[2*(25 - 5*Sqrt[5])]*x*y - 26720*Sqrt[2*(5 - Sqrt[5])]*x*
       y + 10688*Sqrt[10*(5 - Sqrt[5])]*x*y - 2888*Sqrt[2*(5 + Sqrt[5])]*x*
       y - 1304*Sqrt[10*(5 + Sqrt[5])]*x*y - 
      5664*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2*y + 2832*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y + 6320*Sqrt[2*(5 - Sqrt[5])]*x^2*y - 2528*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y + 2320*Sqrt[2*(5 + Sqrt[5])]*x^2*y + 1040*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y + 3056*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3*y - 
      1528*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y - 3400*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y + 1360*Sqrt[10*(5 - Sqrt[5])]*x^3*y + 280*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y + 120*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 
      928*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^2*y^2 + 464*Sqrt[2*(25 - 5*Sqrt[5])]*
       x^2*y^2 + 1040*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 
      416*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 1040*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 464*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      3296*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3*y^2 + 
      1648*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 3680*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 1472*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 200*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 - 88*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      1432*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x^3*y^3 - 
      716*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^3 - 1600*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^3 + 640*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3 + 50*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^3 + 22*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3}
