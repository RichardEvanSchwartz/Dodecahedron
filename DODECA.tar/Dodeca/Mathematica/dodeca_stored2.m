CONFINEX = {5*(-8*(47 + 21*Sqrt[5]) + x*(16*(9 + 4*Sqrt[5]) + 
         (16 + 4*Sqrt[5] + 2*Sqrt[70 - 30*Sqrt[5]] + 
           15*Sqrt[30 - 10*Sqrt[5]] + 10*Sqrt[14 - 6*Sqrt[5]] + 
           39*Sqrt[6 - 2*Sqrt[5]])*y) + x^2*(-4*(2 + Sqrt[5]) + 
         (9 + 3*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 6*Sqrt[6 - 2*Sqrt[5]])*y + 
         (-5 + Sqrt[5])*(3 + Sqrt[9 - 4*Sqrt[5]])*y^2)), 
     5*x*(-4*(29 + 13*Sqrt[5]) + (8 + 4*Sqrt[5] + 2*Sqrt[70 - 30*Sqrt[5]] + 
         11*Sqrt[30 - 10*Sqrt[5]] + 2*Sqrt[14 - 6*Sqrt[5]] + 
         23*Sqrt[6 - 2*Sqrt[5]])*y + x*(4*(2 + Sqrt[5]) + 
         (-9 - 3*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]])*y - (-1 + Sqrt[5])*
          (3 + Sqrt[9 - 4*Sqrt[5]])*y^2)), 
     -5*x*y*(2*Sqrt[2]*(3*Sqrt[7 - 3*Sqrt[5]] + Sqrt[5*(7 - 3*Sqrt[5])] + 
         2*Sqrt[3 - Sqrt[5]]*(7 + 3*Sqrt[5])) + 
       x*(Sqrt[6 - 2*Sqrt[5]]*(3 + Sqrt[5]) - 2*(3 + Sqrt[9 - 4*Sqrt[5]])*
          y)), 5*(464 + 208*Sqrt[5] - x*(176 + 80*Sqrt[5] + 
         (-68 - 32*Sqrt[5] + 34*Sqrt[70 - 30*Sqrt[5]] + 
           57*Sqrt[30 - 10*Sqrt[5]] + 58*Sqrt[14 - 6*Sqrt[5]] + 
           117*Sqrt[6 - 2*Sqrt[5]])*y) + x^2*(4*(3 + Sqrt[5]) - 
         (3 + Sqrt[5] + Sqrt[70 - 30*Sqrt[5]] - Sqrt[30 - 10*Sqrt[5]] - 
           3*Sqrt[14 - 6*Sqrt[5]] - 12*Sqrt[6 - 2*Sqrt[5]])*y + 
         (55 - 23*Sqrt[5] + 7*Sqrt[70 - 30*Sqrt[5]] + 
           15*Sqrt[14 - 6*Sqrt[5]] - 5*Sqrt[9 - 4*Sqrt[5]] + 
           Sqrt[5*(9 - 4*Sqrt[5])])*y^2)), 
     -5*x*(-8*(9 + 4*Sqrt[5]) - (-56 - 28*Sqrt[5] + 
         22*Sqrt[70 - 30*Sqrt[5]] + 19*Sqrt[30 - 10*Sqrt[5]] + 
         38*Sqrt[14 - 6*Sqrt[5]] + 35*Sqrt[6 - 2*Sqrt[5]])*y + 
       x*(2*(3 + Sqrt[5]) - (3 + Sqrt[5] + Sqrt[70 - 30*Sqrt[5]] + 
           Sqrt[30 - 10*Sqrt[5]] + Sqrt[14 - 6*Sqrt[5]] - 
           2*Sqrt[6 - 2*Sqrt[5]])*y + (23 - 11*Sqrt[5] + 
           6*Sqrt[70 - 30*Sqrt[5]] + 10*Sqrt[14 - 6*Sqrt[5]] + 
           3*Sqrt[9 - 4*Sqrt[5]] + 5*Sqrt[5*(9 - 4*Sqrt[5])])*y^2)), 
     5*x*y*(4*Sqrt[2]*(Sqrt[7 - 3*Sqrt[5]] + Sqrt[5*(7 - 3*Sqrt[5])] + 
         4*Sqrt[3 - Sqrt[5]]*(2 + Sqrt[5])) - 
       x*(2*Sqrt[14 - 6*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]]*(5 + Sqrt[5]) - 
         2*(-8 + 3*Sqrt[5] + 2*Sqrt[9 - 4*Sqrt[5]] + Sqrt[5*(9 - 4*Sqrt[5])])*
          y)), 5*(-16*(25 + 11*Sqrt[5]) + 2*x*(44 + 20*Sqrt[5] + 
         (-104 - 56*Sqrt[5] + 10*Sqrt[70 - 30*Sqrt[5]] + 
           33*Sqrt[30 - 10*Sqrt[5]] + 16*Sqrt[14 - 6*Sqrt[5]] + 
           63*Sqrt[6 - 2*Sqrt[5]])*y) + x^2*(4*(3 + Sqrt[5]) - 
         (12 + 4*Sqrt[5] + Sqrt[70 - 30*Sqrt[5]] + 2*Sqrt[30 - 10*Sqrt[5]] - 
           3*Sqrt[14 - 6*Sqrt[5]] - 24*Sqrt[6 - 2*Sqrt[5]])*y + 
         (70 - 26*Sqrt[5] + 13*Sqrt[70 - 30*Sqrt[5]] + 
           15*Sqrt[14 - 6*Sqrt[5]] + 10*Sqrt[9 - 4*Sqrt[5]] - 
           2*Sqrt[5*(9 - 4*Sqrt[5])])*y^2)), 
     -5*x*(2*(8*(15 + 7*Sqrt[5]) + (-128 - 64*Sqrt[5] + 
           10*Sqrt[70 - 30*Sqrt[5]] + 19*Sqrt[30 - 10*Sqrt[5]] + 
           20*Sqrt[14 - 6*Sqrt[5]] + 41*Sqrt[6 - 2*Sqrt[5]])*y) + 
       x*(8*(3 + Sqrt[5]) - (12 + 4*Sqrt[5] + Sqrt[70 - 30*Sqrt[5]] + 
           4*Sqrt[30 - 10*Sqrt[5]] + Sqrt[14 - 6*Sqrt[5]] - 
           2*Sqrt[6 - 2*Sqrt[5]])*y + (26 - 14*Sqrt[5] + 
           15*Sqrt[70 - 30*Sqrt[5]] + 25*Sqrt[14 - 6*Sqrt[5]] + 
           6*Sqrt[9 - 4*Sqrt[5]] + 2*Sqrt[5*(9 - 4*Sqrt[5])])*y^2)), 
     -5*x*y*(2*Sqrt[2]*(Sqrt[7 - 3*Sqrt[5]] + Sqrt[5*(7 - 3*Sqrt[5])] + 
         10*Sqrt[3 - Sqrt[5]]*(2 + Sqrt[5])) + 
       x*(2*Sqrt[14 - 6*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]]*(11 + Sqrt[5]) - 
         2*(-11 + 3*Sqrt[5] - Sqrt[9 - 4*Sqrt[5]] + Sqrt[5*(9 - 4*Sqrt[5])])*
          y)), 5*(16*(20 + 9*Sqrt[5]) - x*(8*(9 + 4*Sqrt[5]) + 
         (-16 - 4*Sqrt[5] + Sqrt[70 - 30*Sqrt[5]] + 
           21*Sqrt[30 - 10*Sqrt[5]] + 5*Sqrt[14 - 6*Sqrt[5]] + 
           51*Sqrt[6 - 2*Sqrt[5]])*y) + x^2*(-4*(2 + Sqrt[5]) + 
         (9 + 3*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 6*Sqrt[6 - 2*Sqrt[5]])*y + 
         (-5 + Sqrt[5])*(3 + Sqrt[9 - 4*Sqrt[5]])*y^2)), 
     5*x*(100 + 44*Sqrt[5] - (-8 - 4*Sqrt[5] + Sqrt[70 - 30*Sqrt[5]] + 
         7*Sqrt[30 - 10*Sqrt[5]] + Sqrt[14 - 6*Sqrt[5]] + 
         13*Sqrt[6 - 2*Sqrt[5]])*y + x*(4*(2 + Sqrt[5]) + 
         (-9 - 3*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]])*y - (-1 + Sqrt[5])*
          (3 + Sqrt[9 - 4*Sqrt[5]])*y^2)), 
     5*x*y*(Sqrt[2]*(3*Sqrt[7 - 3*Sqrt[5]] + Sqrt[5*(7 - 3*Sqrt[5])] + 
         5*Sqrt[3 - Sqrt[5]]*(7 + 3*Sqrt[5])) - 
       x*(Sqrt[6 - 2*Sqrt[5]]*(3 + Sqrt[5]) - 2*(3 + Sqrt[9 - 4*Sqrt[5]])*
          y)), -5*x*(-210 - 94*Sqrt[5] + 2*(15 + 7*Sqrt[5])*y + 
       x*(-5*(9 + 4*Sqrt[5]) + 2*(5 + 2*Sqrt[5])*y + (5 + 2*Sqrt[5])*y^2)), 
     -5*(-8*(38 + 17*Sqrt[5]) + x*(145 + 65*Sqrt[5] + (43 + 19*Sqrt[5])*y) + 
       x^2*(5*(9 + 4*Sqrt[5]) - (25 + 11*Sqrt[5])*y + (2 + Sqrt[5])*y^2)), 
     5*x*y*(102 + 46*Sqrt[5] + x*(-15 - 7*Sqrt[5] + (7 + 3*Sqrt[5])*y)), 
     -5*Sqrt[2]*x*(300 + 134*Sqrt[5] - 10*(9 + 4*Sqrt[5])*y + 
       x*(-5*(9 + 4*Sqrt[5]) + 2*(5 + 2*Sqrt[5])*y + (5 + 2*Sqrt[5])*y^2)), 
     -5*Sqrt[2]*(434 + 194*Sqrt[5] - x*(365 + 163*Sqrt[5] + 
         (11 + 5*Sqrt[5])*y) + x^2*(5*(9 + 4*Sqrt[5]) - (25 + 11*Sqrt[5])*y + 
         (2 + Sqrt[5])*y^2)), 5*Sqrt[2]*x*y*(-8*(9 + 4*Sqrt[5]) + 
       x*(-15 - 7*Sqrt[5] + (7 + 3*Sqrt[5])*y)), 
     5*x*(5*(-4 + Sqrt[30 - 10*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]])*x^2*y^2 + 
       8*(-8*(65 + 29*Sqrt[5]) + (160 + 68*Sqrt[5] + 
           29*Sqrt[30 - 10*Sqrt[5]] + 65*Sqrt[6 - 2*Sqrt[5]])*y) + 
       2*x*(-40*(11 + 5*Sqrt[5]) + 2*(40 + 20*Sqrt[5] + 
           7*Sqrt[30 - 10*Sqrt[5]] + 15*Sqrt[6 - 2*Sqrt[5]])*y + 
         (-100 - 56*Sqrt[5] + 3*Sqrt[30 - 10*Sqrt[5]] - 
           5*Sqrt[6 - 2*Sqrt[5]])*y^2)), 
     5*(-64*(47 + 21*Sqrt[5]) + (5*Sqrt[6 - 2*Sqrt[5]] + 
         Sqrt[5]*(-4 + Sqrt[6 - 2*Sqrt[5]]))*x^3*y^2 - 
       8*x*(-20*(9 + 4*Sqrt[5]) + (12 + 4*Sqrt[5] + 
           23*Sqrt[30 - 10*Sqrt[5]] + 51*Sqrt[6 - 2*Sqrt[5]])*y) + 
       x^2*(40*(11 + 5*Sqrt[5]) - 4*(-60 - 24*Sqrt[5] + 
           7*Sqrt[30 - 10*Sqrt[5]] + 15*Sqrt[6 - 2*Sqrt[5]])*y + 
         (152 + 80*Sqrt[5] - 2*Sqrt[30 - 10*Sqrt[5]] + 6*Sqrt[6 - 2*Sqrt[5]])*
          y^2)), -5*x*y*(32*(16 + 7*Sqrt[5]) + 
       (3*Sqrt[30 - 10*Sqrt[5]] + 5*Sqrt[6 - 2*Sqrt[5]] - 2*(5 + Sqrt[5]))*
        x^2*y + 2*x*(100 + 44*Sqrt[5] + (-2 - 2*Sqrt[5] + 
           Sqrt[30 - 10*Sqrt[5]] - Sqrt[6 - 2*Sqrt[5]])*y)), 
     -5*x*(5*(-4 + Sqrt[30 - 10*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]])*x^2*y^2 + 
       4*(-4*(185 + 83*Sqrt[5]) + 5*(-26 - 10*Sqrt[5] + 
           5*Sqrt[30 - 10*Sqrt[5]] + 11*Sqrt[6 - 2*Sqrt[5]])*y) - 
       2*x*(-20*(11 + 5*Sqrt[5]) + (-20 + 8*Sqrt[5] + 
           7*Sqrt[30 - 10*Sqrt[5]] + 15*Sqrt[6 - 2*Sqrt[5]])*y + 
         (-110 - 46*Sqrt[5] + 3*Sqrt[30 - 10*Sqrt[5]] + 
           5*Sqrt[6 - 2*Sqrt[5]])*y^2)), 
     -5*(-128*(67 + 30*Sqrt[5]) + (5*Sqrt[6 - 2*Sqrt[5]] + 
         Sqrt[5]*(-4 + Sqrt[6 - 2*Sqrt[5]]))*x^3*y^2 - 
       4*x*(-8*(225 + 101*Sqrt[5]) + (-486 - 214*Sqrt[5] + 
           31*Sqrt[30 - 10*Sqrt[5]] + 69*Sqrt[6 - 2*Sqrt[5]])*y) - 
       2*x^2*(40*(11 + 5*Sqrt[5]) + (180 + 72*Sqrt[5] - 
           7*Sqrt[30 - 10*Sqrt[5]] - 15*Sqrt[6 - 2*Sqrt[5]])*y + 
         (86 + 38*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 3*Sqrt[6 - 2*Sqrt[5]])*
          y^2)), 5*x*y*(64*(11 + 5*Sqrt[5]) + 
       (3*Sqrt[30 - 10*Sqrt[5]] + 5*Sqrt[6 - 2*Sqrt[5]] - 2*(5 + Sqrt[5]))*
        x^2*y - 4*x*(20*(2 + Sqrt[5]) + (-11 - 5*Sqrt[5] + 
           Sqrt[30 - 10*Sqrt[5]] + 2*Sqrt[6 - 2*Sqrt[5]])*y)), 
     -5*x*(4*(4*(995 + 445*Sqrt[5] + 38*Sqrt[30 - 10*Sqrt[5]] + 
           85*Sqrt[6 - 2*Sqrt[5]]) + (-1346 - 602*Sqrt[5] + 
           47*Sqrt[30 - 10*Sqrt[5]] + 105*Sqrt[6 - 2*Sqrt[5]])*y) + 
       x*(-8*(-205 - 91*Sqrt[5] + 2*Sqrt[30 - 10*Sqrt[5]] + 
           5*Sqrt[6 - 2*Sqrt[5]]) + 4*(-330 - 146*Sqrt[5] + 
           7*Sqrt[30 - 10*Sqrt[5]] + 17*Sqrt[6 - 2*Sqrt[5]])*y + 
         (192 + 84*Sqrt[5] + 11*Sqrt[30 - 10*Sqrt[5]] + 
           23*Sqrt[6 - 2*Sqrt[5]])*y^2)), 
     -5*(64*(445 + 199*Sqrt[5]) + 16*x*(-1440 - 644*Sqrt[5] + 
         55*Sqrt[30 - 10*Sqrt[5]] + 123*Sqrt[6 - 2*Sqrt[5]] + 
         (105 + 47*Sqrt[5] + 17*Sqrt[30 - 10*Sqrt[5]] + 
           38*Sqrt[6 - 2*Sqrt[5]])*y) + 
       x^2*(4*(124 + 56*Sqrt[5] + 19*Sqrt[30 - 10*Sqrt[5]] + 
           43*Sqrt[6 - 2*Sqrt[5]]) + 4*(-52 - 24*Sqrt[5] + 
           7*Sqrt[30 - 10*Sqrt[5]] + 15*Sqrt[6 - 2*Sqrt[5]])*y + 
         (-114 - 50*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 3*Sqrt[6 - 2*Sqrt[5]])*
          y^2)), 5*x*(2*(-3820 - 1708*Sqrt[5] + 398*Sqrt[30 - 10*Sqrt[5]] + 
         890*Sqrt[6 - 2*Sqrt[5]] + (-572 - 256*Sqrt[5] + 
           123*Sqrt[30 - 10*Sqrt[5]] + 275*Sqrt[6 - 2*Sqrt[5]])*y) + 
       x*(1068 + 476*Sqrt[5] + 30*Sqrt[30 - 10*Sqrt[5]] + 
         66*Sqrt[6 - 2*Sqrt[5]] + 4*(-191 - 85*Sqrt[5] + 
           7*Sqrt[30 - 10*Sqrt[5]] + 16*Sqrt[6 - 2*Sqrt[5]])*y + 
         (39 + 17*Sqrt[5] + 6*Sqrt[30 - 10*Sqrt[5]] + 13*Sqrt[6 - 2*Sqrt[5]])*
          y^2)), 
     5*x*(-16*(4*(-3115 - 1393*Sqrt[5] + 237*Sqrt[30 - 10*Sqrt[5]] + 
           530*Sqrt[6 - 2*Sqrt[5]]) + (1910 + 854*Sqrt[5] + 
           293*Sqrt[30 - 10*Sqrt[5]] + 655*Sqrt[6 - 2*Sqrt[5]])*y) - 
       8*x*(-7780 - 3476*Sqrt[5] + 94*Sqrt[30 - 10*Sqrt[5]] + 
         210*Sqrt[6 - 2*Sqrt[5]] + 2*(1028 + 456*Sqrt[5] + 
           33*Sqrt[30 - 10*Sqrt[5]] + 73*Sqrt[6 - 2*Sqrt[5]])*y + 
         (-77 - 31*Sqrt[5] + 11*Sqrt[30 - 10*Sqrt[5]] + 
           26*Sqrt[6 - 2*Sqrt[5]])*y^2) + 
       x^2*(-40*(-8 - 4*Sqrt[5] + 3*Sqrt[30 - 10*Sqrt[5]] + 
           7*Sqrt[6 - 2*Sqrt[5]]) - 8*(-25 - 7*Sqrt[5] + 
           8*Sqrt[30 - 10*Sqrt[5]] + 15*Sqrt[6 - 2*Sqrt[5]])*y + 
         2*(-10 + 6*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - 5*Sqrt[6 - 2*Sqrt[5]])*
          y^2 + (5*Sqrt[6 - 2*Sqrt[5]] + Sqrt[5]*(-4 + Sqrt[6 - 2*Sqrt[5]]))*
          y^3)), 5*(1280*(199 + 89*Sqrt[5]) - 
       64*x*(4*(293 + 131*Sqrt[5] + 17*Sqrt[30 - 10*Sqrt[5]] + 
           38*Sqrt[6 - 2*Sqrt[5]]) + (22 + 10*Sqrt[5] + 
           21*Sqrt[30 - 10*Sqrt[5]] + 47*Sqrt[6 - 2*Sqrt[5]])*y) - 
       8*x^2*(8800 + 3936*Sqrt[5] + 2*(-1678 - 750*Sqrt[5] + 
           11*Sqrt[30 - 10*Sqrt[5]] + 25*Sqrt[6 - 2*Sqrt[5]])*y + 
         (324 + 144*Sqrt[5] + 7*Sqrt[30 - 10*Sqrt[5]] + 
           15*Sqrt[6 - 2*Sqrt[5]])*y^2) + 
       x^3*(-8*(-20 - 8*Sqrt[5] + 7*Sqrt[30 - 10*Sqrt[5]] + 
           15*Sqrt[6 - 2*Sqrt[5]]) - 8*(-7 - 5*Sqrt[5] + 
           3*Sqrt[30 - 10*Sqrt[5]] + 8*Sqrt[6 - 2*Sqrt[5]])*y - 
         2*(-6 + 2*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - Sqrt[6 - 2*Sqrt[5]])*
          y^2 + (-4 + Sqrt[30 - 10*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]])*y^3)), 
     -5*x*(-8*(2*(550 + 246*Sqrt[5] + 597*Sqrt[30 - 10*Sqrt[5]] + 
           1335*Sqrt[6 - 2*Sqrt[5]]) + (2164 + 968*Sqrt[5] + 
           369*Sqrt[30 - 10*Sqrt[5]] + 825*Sqrt[6 - 2*Sqrt[5]])*y) - 
       4*x*(3100 + 1388*Sqrt[5] + 94*Sqrt[30 - 10*Sqrt[5]] + 
         210*Sqrt[6 - 2*Sqrt[5]] + 4*(-425 - 191*Sqrt[5] + 
           22*Sqrt[30 - 10*Sqrt[5]] + 49*Sqrt[6 - 2*Sqrt[5]])*y + 
         (303 + 137*Sqrt[5] + 18*Sqrt[30 - 10*Sqrt[5]] + 
           41*Sqrt[6 - 2*Sqrt[5]])*y^2) + 
       x^2*(8*(30 + 14*Sqrt[5] - 11*Sqrt[30 - 10*Sqrt[5]] - 
           25*Sqrt[6 - 2*Sqrt[5]]) + (128 + 48*Sqrt[5] - 
           44*Sqrt[30 - 10*Sqrt[5]] - 92*Sqrt[6 - 2*Sqrt[5]])*y + 
         4*(-1 + Sqrt[5] - Sqrt[6 - 2*Sqrt[5]])*y^2 + 
         (-2 - 2*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 3*Sqrt[6 - 2*Sqrt[5]])*
          y^3)), 5*x*(-64*(-1540 - 688*Sqrt[5] + 123*Sqrt[30 - 10*Sqrt[5]] + 
         275*Sqrt[6 - 2*Sqrt[5]] + (509 + 227*Sqrt[5] + 
           38*Sqrt[30 - 10*Sqrt[5]] + 85*Sqrt[6 - 2*Sqrt[5]])*y) + 
       4*x*(8000 + 3568*Sqrt[5] - 236*Sqrt[30 - 10*Sqrt[5]] - 
         540*Sqrt[6 - 2*Sqrt[5]] - 8*(145 + 63*Sqrt[5] + 
           6*Sqrt[30 - 10*Sqrt[5]] + 11*Sqrt[6 - 2*Sqrt[5]])*y + 
         (394 + 170*Sqrt[5] + 11*Sqrt[30 - 10*Sqrt[5]] + 
           17*Sqrt[6 - 2*Sqrt[5]])*y^2) + 
       x^2*(-40*(-8 - 4*Sqrt[5] + 3*Sqrt[30 - 10*Sqrt[5]] + 
           7*Sqrt[6 - 2*Sqrt[5]]) - 8*(-25 - 7*Sqrt[5] + 
           8*Sqrt[30 - 10*Sqrt[5]] + 15*Sqrt[6 - 2*Sqrt[5]])*y + 
         2*(-10 + 6*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - 5*Sqrt[6 - 2*Sqrt[5]])*
          y^2 + (5*Sqrt[6 - 2*Sqrt[5]] + Sqrt[5]*(-4 + Sqrt[6 - 2*Sqrt[5]]))*
          y^3)), 5*(512*(199 + 89*Sqrt[5]) + 
       64*x*(-716 - 320*Sqrt[5] + 97*Sqrt[30 - 10*Sqrt[5]] + 
         217*Sqrt[6 - 2*Sqrt[5]] + (119 + 53*Sqrt[5] + 
           30*Sqrt[30 - 10*Sqrt[5]] + 67*Sqrt[6 - 2*Sqrt[5]])*y) - 
       4*x^2*(7088 + 3168*Sqrt[5] - 228*Sqrt[30 - 10*Sqrt[5]] - 
         516*Sqrt[6 - 2*Sqrt[5]] - 8*(-19 - 9*Sqrt[5] + 
           5*Sqrt[30 - 10*Sqrt[5]] + 10*Sqrt[6 - 2*Sqrt[5]])*y + 
         (126 + 54*Sqrt[5] + 11*Sqrt[30 - 10*Sqrt[5]] + 
           21*Sqrt[6 - 2*Sqrt[5]])*y^2) + 
       x^3*(-8*(-20 - 8*Sqrt[5] + 7*Sqrt[30 - 10*Sqrt[5]] + 
           15*Sqrt[6 - 2*Sqrt[5]]) - 8*(-7 - 5*Sqrt[5] + 
           3*Sqrt[30 - 10*Sqrt[5]] + 8*Sqrt[6 - 2*Sqrt[5]])*y - 
         2*(-6 + 2*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - Sqrt[6 - 2*Sqrt[5]])*
          y^2 + (-4 + Sqrt[30 - 10*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]])*y^3)), 
     -5*x*(-64*(268 + 120*Sqrt[5] + 83*y + 37*Sqrt[5]*y) - 
       8*x*(2*(406 + 182*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 
           3*Sqrt[6 - 2*Sqrt[5]]) + 2*(64 + 28*Sqrt[5] + 
           Sqrt[30 - 10*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]])*y + 
         (-39 - 17*Sqrt[5] + Sqrt[6 - 2*Sqrt[5]])*y^2) + 
       x^2*(8*(30 + 14*Sqrt[5] - 11*Sqrt[30 - 10*Sqrt[5]] - 
           25*Sqrt[6 - 2*Sqrt[5]]) + (128 + 48*Sqrt[5] - 
           44*Sqrt[30 - 10*Sqrt[5]] - 92*Sqrt[6 - 2*Sqrt[5]])*y + 
         4*(-1 + Sqrt[5] - Sqrt[6 - 2*Sqrt[5]])*y^2 + 
         (-2 - 2*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 3*Sqrt[6 - 2*Sqrt[5]])*
          y^3)), 5*x*(40*(38 + 17*Sqrt[5]) - 2*(163 + 73*Sqrt[5])*y + 
       x*(-2 + y)*(-130 - 58*Sqrt[5] + 7*y + 3*Sqrt[5]*y)), 
     -5*Sqrt[2]*(-8*(161 + 72*Sqrt[5]) + x^2*(-2 + y)*(-47 - 21*Sqrt[5] + 
         (9 + 4*Sqrt[5])*y) + x*(796 + 356*Sqrt[5] - (29 + 13*Sqrt[5])*y)), 
     5*x*(x*(-2 + y)*(36 + 16*Sqrt[5] + 11*y + 5*Sqrt[5]*y) + 
       4*(217 + 97*Sqrt[5] + (67 + 30*Sqrt[5])*y)), 
     5*x*(-16*(-7300 - 3268*Sqrt[5] + 210*Sqrt[30 - 10*Sqrt[5]] + 
         470*Sqrt[6 - 2*Sqrt[5]] + (548 + 248*Sqrt[5] + 
           65*Sqrt[30 - 10*Sqrt[5]] + 145*Sqrt[6 - 2*Sqrt[5]])*y) - 
       4*x*(-8*(-695 - 313*Sqrt[5] + 20*Sqrt[30 - 10*Sqrt[5]] + 
           45*Sqrt[6 - 2*Sqrt[5]]) - 8*(-13 - 3*Sqrt[5] + 
           6*Sqrt[30 - 10*Sqrt[5]] + 13*Sqrt[6 - 2*Sqrt[5]])*y + 
         (236 + 112*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]])*
          y^2) + x^2*(-40*(-8 - 4*Sqrt[5] + 3*Sqrt[30 - 10*Sqrt[5]] + 
           7*Sqrt[6 - 2*Sqrt[5]]) - 8*(-25 - 7*Sqrt[5] + 
           8*Sqrt[30 - 10*Sqrt[5]] + 15*Sqrt[6 - 2*Sqrt[5]])*y + 
         2*(-10 + 6*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - 5*Sqrt[6 - 2*Sqrt[5]])*
          y^2 + (5*Sqrt[6 - 2*Sqrt[5]] + Sqrt[5]*(-4 + Sqrt[6 - 2*Sqrt[5]]))*
          y^3)), 5*(1024*(284 + 127*Sqrt[5]) + 
       16*x*(-19364 - 8660*Sqrt[5] + 262*Sqrt[30 - 10*Sqrt[5]] + 
         586*Sqrt[6 - 2*Sqrt[5]] + (848 + 380*Sqrt[5] + 
           81*Sqrt[30 - 10*Sqrt[5]] + 181*Sqrt[6 - 2*Sqrt[5]])*y) + 
       4*x^2*(8*(1481 + 663*Sqrt[5] - 12*Sqrt[30 - 10*Sqrt[5]] - 
           27*Sqrt[6 - 2*Sqrt[5]]) - 8*(85 + 39*Sqrt[5] + 
           Sqrt[30 - 10*Sqrt[5]] + 2*Sqrt[6 - 2*Sqrt[5]])*y + 
         (156 + 72*Sqrt[5] + 7*Sqrt[30 - 10*Sqrt[5]] + 
           15*Sqrt[6 - 2*Sqrt[5]])*y^2) + 
       x^3*(-8*(-20 - 8*Sqrt[5] + 7*Sqrt[30 - 10*Sqrt[5]] + 
           15*Sqrt[6 - 2*Sqrt[5]]) - 8*(-7 - 5*Sqrt[5] + 
           3*Sqrt[30 - 10*Sqrt[5]] + 8*Sqrt[6 - 2*Sqrt[5]])*y - 
         2*(-6 + 2*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - Sqrt[6 - 2*Sqrt[5]])*
          y^2 + (-4 + Sqrt[30 - 10*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]])*y^3)), 
     -5*x*(-256*(94 + 42*Sqrt[5] + (29 + 13*Sqrt[5])*y) + 
       4*x*(8*(133 + 59*Sqrt[5] + 4*Sqrt[30 - 10*Sqrt[5]] + 
           9*Sqrt[6 - 2*Sqrt[5]]) + 4*(2 + 2*Sqrt[5] + 
           5*Sqrt[30 - 10*Sqrt[5]] + 11*Sqrt[6 - 2*Sqrt[5]])*y + 
         (-96 - 44*Sqrt[5] + 3*Sqrt[30 - 10*Sqrt[5]] + 7*Sqrt[6 - 2*Sqrt[5]])*
          y^2) + x^2*(8*(30 + 14*Sqrt[5] - 11*Sqrt[30 - 10*Sqrt[5]] - 
           25*Sqrt[6 - 2*Sqrt[5]]) + (128 + 48*Sqrt[5] - 
           44*Sqrt[30 - 10*Sqrt[5]] - 92*Sqrt[6 - 2*Sqrt[5]])*y + 
         4*(-1 + Sqrt[5] - Sqrt[6 - 2*Sqrt[5]])*y^2 + 
         (-2 - 2*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 3*Sqrt[6 - 2*Sqrt[5]])*
          y^3)), 10*Sqrt[2]*x*(x*(-2 + y)*(-30 - 14*Sqrt[5] + y + 
         Sqrt[5]*y) + 2*(-210 - 94*Sqrt[5] + (69 + 31*Sqrt[5])*y)), 
     -20*Sqrt[2]*(434 + 194*Sqrt[5] + (47 + 21*Sqrt[5])*x*(-8 + y) + 
       x^2*(-2 + y)*(-11 - 5*Sqrt[5] + (2 + Sqrt[5])*y)), 
     5*Sqrt[2]*x*(x*(-2 + y)*(6 + 2*Sqrt[5] + y + Sqrt[5]*y) - 
       4*(22 + 10*Sqrt[5] + (7 + 3*Sqrt[5])*y)), 
     5*x*(-80*(4*(-923 - 413*Sqrt[5] + 30*Sqrt[30 - 10*Sqrt[5]] + 
           67*Sqrt[6 - 2*Sqrt[5]]) + (826 + 370*Sqrt[5] + 
           37*Sqrt[30 - 10*Sqrt[5]] + 83*Sqrt[6 - 2*Sqrt[5]])*y) + 
       16*x*(4*(-820 - 368*Sqrt[5] + 7*Sqrt[30 - 10*Sqrt[5]] + 
           15*Sqrt[6 - 2*Sqrt[5]]) + (712 + 324*Sqrt[5] + 
           33*Sqrt[30 - 10*Sqrt[5]] + 77*Sqrt[6 - 2*Sqrt[5]])*y + 
         (1 - Sqrt[5] + 8*Sqrt[30 - 10*Sqrt[5]] + 17*Sqrt[6 - 2*Sqrt[5]])*
          y^2) + x^2*(-40*(-8 - 4*Sqrt[5] + 3*Sqrt[30 - 10*Sqrt[5]] + 
           7*Sqrt[6 - 2*Sqrt[5]]) - 8*(-25 - 7*Sqrt[5] + 
           8*Sqrt[30 - 10*Sqrt[5]] + 15*Sqrt[6 - 2*Sqrt[5]])*y + 
         2*(-10 + 6*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - 5*Sqrt[6 - 2*Sqrt[5]])*
          y^2 + (5*Sqrt[6 - 2*Sqrt[5]] + Sqrt[5]*(-4 + Sqrt[6 - 2*Sqrt[5]]))*
          y^3)), 5*(512*(1165 + 521*Sqrt[5]) - 
       32*x*(17824 + 7972*Sqrt[5] + 223*Sqrt[30 - 10*Sqrt[5]] + 
         499*Sqrt[6 - 2*Sqrt[5]] + (-2335 - 1045*Sqrt[5] + 
           69*Sqrt[30 - 10*Sqrt[5]] + 154*Sqrt[6 - 2*Sqrt[5]])*y) + 
       8*x^2*(2*(5590 + 2502*Sqrt[5] + 33*Sqrt[30 - 10*Sqrt[5]] + 
           75*Sqrt[6 - 2*Sqrt[5]]) + 2*(-1886 - 846*Sqrt[5] + 
           19*Sqrt[30 - 10*Sqrt[5]] + 41*Sqrt[6 - 2*Sqrt[5]])*y + 
         (339 + 153*Sqrt[5] + 5*Sqrt[30 - 10*Sqrt[5]] + 
           12*Sqrt[6 - 2*Sqrt[5]])*y^2) + 
       x^3*(-8*(-20 - 8*Sqrt[5] + 7*Sqrt[30 - 10*Sqrt[5]] + 
           15*Sqrt[6 - 2*Sqrt[5]]) - 8*(-7 - 5*Sqrt[5] + 
           3*Sqrt[30 - 10*Sqrt[5]] + 8*Sqrt[6 - 2*Sqrt[5]])*y - 
         2*(-6 + 2*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - Sqrt[6 - 2*Sqrt[5]])*
          y^2 + (-4 + Sqrt[30 - 10*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]])*y^3)), 
     -5*x*(-8*(20*(235 + 105*Sqrt[5] + 51*Sqrt[30 - 10*Sqrt[5]] + 
           114*Sqrt[6 - 2*Sqrt[5]]) + (-374 - 166*Sqrt[5] + 
           315*Sqrt[30 - 10*Sqrt[5]] + 705*Sqrt[6 - 2*Sqrt[5]])*y) + 
       4*x*(2*(1270 + 566*Sqrt[5] + 61*Sqrt[30 - 10*Sqrt[5]] + 
           135*Sqrt[6 - 2*Sqrt[5]]) + 4*(-487 - 217*Sqrt[5] + 
           26*Sqrt[30 - 10*Sqrt[5]] + 59*Sqrt[6 - 2*Sqrt[5]])*y + 
         (285 + 127*Sqrt[5] + 21*Sqrt[30 - 10*Sqrt[5]] + 
           46*Sqrt[6 - 2*Sqrt[5]])*y^2) + 
       x^2*(8*(30 + 14*Sqrt[5] - 11*Sqrt[30 - 10*Sqrt[5]] - 
           25*Sqrt[6 - 2*Sqrt[5]]) + (128 + 48*Sqrt[5] - 
           44*Sqrt[30 - 10*Sqrt[5]] - 92*Sqrt[6 - 2*Sqrt[5]])*y + 
         4*(-1 + Sqrt[5] - Sqrt[6 - 2*Sqrt[5]])*y^2 + 
         (-2 - 2*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 3*Sqrt[6 - 2*Sqrt[5]])*
          y^3)), -5*x*(-8*(5*(340 + 152*Sqrt[5] + 13*Sqrt[30 - 10*Sqrt[5]] + 
           29*Sqrt[6 - 2*Sqrt[5]]) + (-575 - 257*Sqrt[5] + 
           20*Sqrt[30 - 10*Sqrt[5]] + 45*Sqrt[6 - 2*Sqrt[5]])*y) + 
       x*(-8*(-205 - 91*Sqrt[5] + 2*Sqrt[30 - 10*Sqrt[5]] + 
           5*Sqrt[6 - 2*Sqrt[5]]) + 4*(-330 - 146*Sqrt[5] + 
           7*Sqrt[30 - 10*Sqrt[5]] + 17*Sqrt[6 - 2*Sqrt[5]])*y + 
         (192 + 84*Sqrt[5] + 11*Sqrt[30 - 10*Sqrt[5]] + 
           23*Sqrt[6 - 2*Sqrt[5]])*y^2)), 
     -5*(-64*(521 + 233*Sqrt[5]) - 
       4*x*(4*(-1827 - 817*Sqrt[5] + 59*Sqrt[30 - 10*Sqrt[5]] + 
           132*Sqrt[6 - 2*Sqrt[5]]) + (318 + 142*Sqrt[5] + 
           73*Sqrt[30 - 10*Sqrt[5]] + 163*Sqrt[6 - 2*Sqrt[5]])*y) + 
       x^2*(4*(124 + 56*Sqrt[5] + 19*Sqrt[30 - 10*Sqrt[5]] + 
           43*Sqrt[6 - 2*Sqrt[5]]) + 4*(-52 - 24*Sqrt[5] + 
           7*Sqrt[30 - 10*Sqrt[5]] + 15*Sqrt[6 - 2*Sqrt[5]])*y + 
         (-114 - 50*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 3*Sqrt[6 - 2*Sqrt[5]])*
          y^2)), 5*x*(2*(1868 + 836*Sqrt[5] - 340*Sqrt[30 - 10*Sqrt[5]] - 
         760*Sqrt[6 - 2*Sqrt[5]] + (1186 + 530*Sqrt[5] - 
           105*Sqrt[30 - 10*Sqrt[5]] - 235*Sqrt[6 - 2*Sqrt[5]])*y) + 
       x*(1068 + 476*Sqrt[5] + 30*Sqrt[30 - 10*Sqrt[5]] + 
         66*Sqrt[6 - 2*Sqrt[5]] + 4*(-191 - 85*Sqrt[5] + 
           7*Sqrt[30 - 10*Sqrt[5]] + 16*Sqrt[6 - 2*Sqrt[5]])*y + 
         (39 + 17*Sqrt[5] + 6*Sqrt[30 - 10*Sqrt[5]] + 13*Sqrt[6 - 2*Sqrt[5]])*
          y^2)), 5*x*(-16*(70 + 34*Sqrt[5] - 26*Sqrt[30 - 10*Sqrt[5]] - 
         60*Sqrt[6 - 2*Sqrt[5]] + (60 + 32*Sqrt[5] + 
           9*Sqrt[30 - 10*Sqrt[5]] + 25*Sqrt[6 - 2*Sqrt[5]])*y) + 
       4*x*(-110 + 18*Sqrt[5] + 23*Sqrt[30 - 10*Sqrt[5]] + 
         5*Sqrt[6 - 2*Sqrt[5]] - 4*(59 - 3*Sqrt[5] + 
           10*Sqrt[30 - 10*Sqrt[5]] - 11*Sqrt[6 - 2*Sqrt[5]])*y + 
         (72 - 44*Sqrt[5] + 9*Sqrt[30 - 10*Sqrt[5]] - 11*Sqrt[6 - 2*Sqrt[5]])*
          y^2) + x^2*(5*(-4 + Sqrt[30 - 10*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]]) + 
         (50 - 22*Sqrt[5] - 7*Sqrt[30 - 10*Sqrt[5]] + 15*Sqrt[6 - 2*Sqrt[5]])*
          y + (-50 + 26*Sqrt[5] + 6*Sqrt[30 - 10*Sqrt[5]] - 
           20*Sqrt[6 - 2*Sqrt[5]])*y^2 + (-20 + 8*Sqrt[5] + 
           3*Sqrt[30 - 10*Sqrt[5]] - 5*Sqrt[6 - 2*Sqrt[5]])*y^3)), 
     -5*(1280*(3 + Sqrt[5]) + 
       64*x*(-2*(12 + 2*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 
           2*Sqrt[6 - 2*Sqrt[5]]) + (6 - 2*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 
           Sqrt[6 - 2*Sqrt[5]])*y) + 
       8*x^2*(-2*(5 + 3*Sqrt[5] + 5*Sqrt[6 - 2*Sqrt[5]]) - 
         4*(22 - 2*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - 5*Sqrt[6 - 2*Sqrt[5]])*
          y + (Sqrt[30 - 10*Sqrt[5]] - 5*Sqrt[6 - 2*Sqrt[5]] - 
           18*(1 + Sqrt[5]))*y^2) + x^3*(-5*Sqrt[6 - 2*Sqrt[5]] - 
         Sqrt[5]*(-4 + Sqrt[6 - 2*Sqrt[5]]) + 
         (22 - 10*Sqrt[5] - 3*Sqrt[30 - 10*Sqrt[5]] + 7*Sqrt[6 - 2*Sqrt[5]])*
          y + 2*(-13 + 5*Sqrt[5] + 2*Sqrt[30 - 10*Sqrt[5]] - 
           3*Sqrt[6 - 2*Sqrt[5]])*y^2 + (-8 + 4*Sqrt[5] + 
           Sqrt[30 - 10*Sqrt[5]] - 3*Sqrt[6 - 2*Sqrt[5]])*y^3)), 
     -5*x*(-8*(-150 - 38*Sqrt[5] - 33*Sqrt[30 - 10*Sqrt[5]] - 
         75*Sqrt[6 - 2*Sqrt[5]] + 2*(41 + 15*Sqrt[5] + 
           6*Sqrt[30 - 10*Sqrt[5]] + 15*Sqrt[6 - 2*Sqrt[5]])*y) + 
       2*x*(-90 + 62*Sqrt[5] + 23*Sqrt[30 - 10*Sqrt[5]] + 
         25*Sqrt[6 - 2*Sqrt[5]] - 4*(15 + Sqrt[5] + 8*Sqrt[30 - 10*Sqrt[5]] - 
           Sqrt[6 - 2*Sqrt[5]])*y + (92 + 8*Sqrt[5] + 
           7*Sqrt[30 - 10*Sqrt[5]] - Sqrt[6 - 2*Sqrt[5]])*y^2) + 
       x^2*(-10 - 2*Sqrt[5] + 3*Sqrt[30 - 10*Sqrt[5]] + 
         5*Sqrt[6 - 2*Sqrt[5]] - 2*(-7 + 3*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - 
           2*Sqrt[6 - 2*Sqrt[5]])*y + (-12 + 8*Sqrt[5] + 
           Sqrt[30 - 10*Sqrt[5]] - 7*Sqrt[6 - 2*Sqrt[5]])*y^2 + 
         (-6 + 2*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - Sqrt[6 - 2*Sqrt[5]])*
          y^3)), 5*x*(-80*(2*(7 + Sqrt[5] - 2*Sqrt[30 - 10*Sqrt[5]] - 
           3*Sqrt[6 - 2*Sqrt[5]]) + (48 + 4*Sqrt[5] + 
           3*Sqrt[30 - 10*Sqrt[5]] - Sqrt[6 - 2*Sqrt[5]])*y) + 
       8*x*(50 - 6*Sqrt[5] - 11*Sqrt[30 - 10*Sqrt[5]] - 
         5*Sqrt[6 - 2*Sqrt[5]] + 8*(19 - 3*Sqrt[5] + 
           2*Sqrt[30 - 10*Sqrt[5]] - Sqrt[6 - 2*Sqrt[5]])*y + 
         (36 - 16*Sqrt[5] + 3*Sqrt[30 - 10*Sqrt[5]] - 13*Sqrt[6 - 2*Sqrt[5]])*
          y^2) + x^2*(5*(-4 + Sqrt[30 - 10*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]]) + 
         (50 - 22*Sqrt[5] - 7*Sqrt[30 - 10*Sqrt[5]] + 15*Sqrt[6 - 2*Sqrt[5]])*
          y + (-50 + 26*Sqrt[5] + 6*Sqrt[30 - 10*Sqrt[5]] - 
           20*Sqrt[6 - 2*Sqrt[5]])*y^2 + (-20 + 8*Sqrt[5] + 
           3*Sqrt[30 - 10*Sqrt[5]] - 5*Sqrt[6 - 2*Sqrt[5]])*y^3)), 
     -5*(512*(15 + 7*Sqrt[5]) + 16*x*(-216 - 124*Sqrt[5] - 
         11*Sqrt[30 - 10*Sqrt[5]] - 31*Sqrt[6 - 2*Sqrt[5]] + 
         (-210 - 50*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 19*Sqrt[6 - 2*Sqrt[5]])*
          y) + 4*x^2*(10 + 42*Sqrt[5] + 3*Sqrt[30 - 10*Sqrt[5]] + 
         25*Sqrt[6 - 2*Sqrt[5]] + 4*(43 + Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - 
           8*Sqrt[6 - 2*Sqrt[5]])*y + (96 + 12*Sqrt[5] + 
           5*Sqrt[30 - 10*Sqrt[5]] - 7*Sqrt[6 - 2*Sqrt[5]])*y^2) + 
       x^3*(-5*Sqrt[6 - 2*Sqrt[5]] - Sqrt[5]*(-4 + Sqrt[6 - 2*Sqrt[5]]) + 
         (22 - 10*Sqrt[5] - 3*Sqrt[30 - 10*Sqrt[5]] + 7*Sqrt[6 - 2*Sqrt[5]])*
          y + 2*(-13 + 5*Sqrt[5] + 2*Sqrt[30 - 10*Sqrt[5]] - 
           3*Sqrt[6 - 2*Sqrt[5]])*y^2 + (-8 + 4*Sqrt[5] + 
           Sqrt[30 - 10*Sqrt[5]] - 3*Sqrt[6 - 2*Sqrt[5]])*y^3)), 
     -5*x*(-8*(-2*(15 + 13*Sqrt[5] + 15*Sqrt[30 - 10*Sqrt[5]] + 
           30*Sqrt[6 - 2*Sqrt[5]]) + (28 - 24*Sqrt[5] + 
           15*Sqrt[30 - 10*Sqrt[5]] + 15*Sqrt[6 - 2*Sqrt[5]])*y) + 
       2*x*(90 - 22*Sqrt[5] - 25*Sqrt[30 - 10*Sqrt[5]] - 
         35*Sqrt[6 - 2*Sqrt[5]] + 4*(33 - 13*Sqrt[5] + 
           7*Sqrt[30 - 10*Sqrt[5]] + 4*Sqrt[6 - 2*Sqrt[5]])*y + 
         (-40 - 28*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - 19*Sqrt[6 - 2*Sqrt[5]])*
          y^2) + x^2*(-10 - 2*Sqrt[5] + 3*Sqrt[30 - 10*Sqrt[5]] + 
         5*Sqrt[6 - 2*Sqrt[5]] - 2*(-7 + 3*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - 
           2*Sqrt[6 - 2*Sqrt[5]])*y + (-12 + 8*Sqrt[5] + 
           Sqrt[30 - 10*Sqrt[5]] - 7*Sqrt[6 - 2*Sqrt[5]])*y^2 + 
         (-6 + 2*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - Sqrt[6 - 2*Sqrt[5]])*
          y^3)), 
     5*x*(4*(5*(-4 + Sqrt[30 - 10*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]]) + 
         (30 + 22*Sqrt[5] - 5*Sqrt[30 - 10*Sqrt[5]] + 5*Sqrt[6 - 2*Sqrt[5]])*
          y) + x*(-6*(-5 + Sqrt[5] + Sqrt[30 - 10*Sqrt[5]]) + 
         2*(20 - 8*Sqrt[5] + 5*Sqrt[30 - 10*Sqrt[5]] - 3*Sqrt[6 - 2*Sqrt[5]])*
          y + (6 - 18*Sqrt[5] + 3*Sqrt[30 - 10*Sqrt[5]] - 
           11*Sqrt[6 - 2*Sqrt[5]])*y^2)), 
     -5*(-64*(7 + 3*Sqrt[5]) + 4*x*(86 + 34*Sqrt[5] - 
         6*Sqrt[30 - 10*Sqrt[5]] - 16*Sqrt[6 - 2*Sqrt[5]] + 
         (4 + 8*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 9*Sqrt[6 - 2*Sqrt[5]])*y) + 
       x^2*(-28 - 8*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 9*Sqrt[6 - 2*Sqrt[5]] + 
         2*(22 + 6*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - 5*Sqrt[6 - 2*Sqrt[5]])*
          y + 2*(1 - 5*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - 
           2*Sqrt[6 - 2*Sqrt[5]])*y^2)), 
     -5*x*(-4*(86 + 34*Sqrt[5] - 10*Sqrt[30 - 10*Sqrt[5]] - 
         20*Sqrt[6 - 2*Sqrt[5]] + (-28 - 24*Sqrt[5] + 
           5*Sqrt[30 - 10*Sqrt[5]] + 5*Sqrt[6 - 2*Sqrt[5]])*y) + 
       x*(58 + 2*Sqrt[5] - 7*Sqrt[30 - 10*Sqrt[5]] - 9*Sqrt[6 - 2*Sqrt[5]] + 
         4*(-1 - 7*Sqrt[5] + 2*Sqrt[30 - 10*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]])*
          y + (4 - 8*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - 7*Sqrt[6 - 2*Sqrt[5]])*
          y^2)), 5*x*(4*(10 + 6*Sqrt[5] - 4*Sqrt[30 - 10*Sqrt[5]] - 
         10*Sqrt[6 - 2*Sqrt[5]] + (-48 - 20*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 
           5*Sqrt[6 - 2*Sqrt[5]])*y) + 
       x*(-6*(-5 + Sqrt[5] + Sqrt[30 - 10*Sqrt[5]]) + 
         2*(20 - 8*Sqrt[5] + 5*Sqrt[30 - 10*Sqrt[5]] - 3*Sqrt[6 - 2*Sqrt[5]])*
          y + (6 - 18*Sqrt[5] + 3*Sqrt[30 - 10*Sqrt[5]] - 
           11*Sqrt[6 - 2*Sqrt[5]])*y^2)), 
     -5*(64*(5 + 3*Sqrt[5]) - 8*x*(20 + 16*Sqrt[5] - 
         3*Sqrt[30 - 10*Sqrt[5]] - 7*Sqrt[6 - 2*Sqrt[5]] + 
         (10 + 2*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 3*Sqrt[6 - 2*Sqrt[5]])*
          y) + x^2*(-28 - 8*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] + 
         9*Sqrt[6 - 2*Sqrt[5]] + 2*(22 + 6*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - 
           5*Sqrt[6 - 2*Sqrt[5]])*y + 2*(1 - 5*Sqrt[5] + 
           Sqrt[30 - 10*Sqrt[5]] - 2*Sqrt[6 - 2*Sqrt[5]])*y^2)), 
     -5*x*(4*(70 + 38*Sqrt[5] - 11*Sqrt[30 - 10*Sqrt[5]] - 
         25*Sqrt[6 - 2*Sqrt[5]] + 2*(-13 - 3*Sqrt[5] + 
           2*Sqrt[30 - 10*Sqrt[5]] + 5*Sqrt[6 - 2*Sqrt[5]])*y) + 
       x*(58 + 2*Sqrt[5] - 7*Sqrt[30 - 10*Sqrt[5]] - 9*Sqrt[6 - 2*Sqrt[5]] + 
         4*(-1 - 7*Sqrt[5] + 2*Sqrt[30 - 10*Sqrt[5]] + Sqrt[6 - 2*Sqrt[5]])*
          y + (4 - 8*Sqrt[5] + Sqrt[30 - 10*Sqrt[5]] - 7*Sqrt[6 - 2*Sqrt[5]])*
          y^2))}
 
STABLEX = {-8*Sqrt[(2*(25 - 5*Sqrt[5]))/5] + 4*Sqrt[2*(25 - 5*Sqrt[5])] + 
      100*Sqrt[2*(5 - Sqrt[5])] - 40*Sqrt[10*(5 - Sqrt[5])] + 
      192*Sqrt[2*(5 + Sqrt[5])] - 40*Sqrt[10*(5 + Sqrt[5])] - 
      28*Sqrt[(2*(25 - 5*Sqrt[5]))/5]*x + 14*Sqrt[2*(25 - 5*Sqrt[5])]*x + 
      110*Sqrt[2*(5 - Sqrt[5])]*x - 44*Sqrt[10*(5 - Sqrt[5])]*x + 
      116*Sqrt[2*(5 + Sqrt[5])]*x - 48*Sqrt[10*(5 + Sqrt[5])]*x - 
      5*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 2*Sqrt[10*(25 - 5*Sqrt[5])]*x^2 - 
      65*Sqrt[2*(5 - Sqrt[5])]*x^2 + 26*Sqrt[10*(5 - Sqrt[5])]*x^2 - 
      68*Sqrt[2*(5 + Sqrt[5])]*x^2 + 26*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      4*Sqrt[(50 - 10*Sqrt[5])/5]*x^3 + 2*Sqrt[50 - 10*Sqrt[5]]*x^3 - 
      15*Sqrt[2*(5 + Sqrt[5])]*x^3 + 7*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      24*Sqrt[5 - 2*Sqrt[5]]*x*y + 8*Sqrt[5*(5 - 2*Sqrt[5])]*x*y - 
      48*Sqrt[5 - 2*Sqrt[5]]*x^2*y - 16*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y + 
      4*Sqrt[5 - 2*Sqrt[5]]*x^3*y - 4*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 
      75*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 30*Sqrt[10*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 185*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 + 74*Sqrt[10*(5 - Sqrt[5])]*
       x^2*y^2 - 400*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 + 
      182*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 10*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^2 - 4*Sqrt[10*(25 - 5*Sqrt[5])]*x^3*y^2 - 20*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 8*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 145*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^2 + 65*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 
      60*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 - 28*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y^3, 
     -1000*Sqrt[2*(25 - 5*Sqrt[5])] - 2240*Sqrt[2*(5 - Sqrt[5])] + 
      1820*Sqrt[2*(5 + Sqrt[5])] + 820*Sqrt[10*(5 + Sqrt[5])] - 
      554*Sqrt[2*(25 - 5*Sqrt[5])]*x - 1250*Sqrt[2*(5 - Sqrt[5])]*x + 
      1340*Sqrt[2*(5 + Sqrt[5])]*x + 592*Sqrt[10*(5 + Sqrt[5])]*x - 
      181*Sqrt[50 - 10*Sqrt[5]]*x^2 - 395*Sqrt[10 - 2*Sqrt[5]]*x^2 + 
      345*Sqrt[2*(5 + Sqrt[5])]*x^2 + 149*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      5*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 5*Sqrt[2*(5 - Sqrt[5])]*x^3 + 
      25*Sqrt[2*(5 + Sqrt[5])]*x^3 + 9*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      800*Sqrt[5 - 2*Sqrt[5]]*x*y + 368*Sqrt[5*(5 - 2*Sqrt[5])]*x*y + 
      800*Sqrt[5 - 2*Sqrt[5]]*x^2*y + 384*Sqrt[5*(5 - 2*Sqrt[5])]*x^2*y - 
      10*Sqrt[5 - 2*Sqrt[5]]*x^3*y - 2*Sqrt[5*(5 - 2*Sqrt[5])]*x^3*y + 
      85*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 + 155*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y^2 - 25*Sqrt[2*(5 + Sqrt[5])]*x^2*y^2 - 85*Sqrt[10*(5 + Sqrt[5])]*x^2*
       y^2 - 15*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 + 25*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^2 + 35*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 - 5*Sqrt[10*(5 + Sqrt[5])]*
       x^3*y^2 - 30*Sqrt[5 - 2*Sqrt[5]]*x^3*y^3 + 10*Sqrt[5*(5 - 2*Sqrt[5])]*
       x^3*y^3, -144*Sqrt[25 - 5*Sqrt[5]] - 48*Sqrt[5*(25 - 5*Sqrt[5])] - 
      288*Sqrt[5 - Sqrt[5]] - 96*Sqrt[5*(5 - Sqrt[5])] + 
      3120*Sqrt[5 + Sqrt[5]] + 1392*Sqrt[5*(5 + Sqrt[5])] + 
      846*Sqrt[25 - 5*Sqrt[5]]*x + 282*Sqrt[5*(25 - 5*Sqrt[5])]*x + 
      1710*Sqrt[5 - Sqrt[5]]*x + 570*Sqrt[5*(5 - Sqrt[5])]*x + 
      4860*Sqrt[5 + Sqrt[5]]*x + 2196*Sqrt[5*(5 + Sqrt[5])]*x - 
      297*Sqrt[25 - 5*Sqrt[5]]*x^2 - 99*Sqrt[5*(25 - 5*Sqrt[5])]*x^2 - 
      585*Sqrt[5 - Sqrt[5]]*x^2 - 195*Sqrt[5*(5 - Sqrt[5])]*x^2 - 
      1110*Sqrt[5 + Sqrt[5]]*x^2 - 498*Sqrt[5*(5 + Sqrt[5])]*x^2 - 
      90*Sqrt[25 - 5*Sqrt[5]]*x^3 - 30*Sqrt[5*(25 - 5*Sqrt[5])]*x^3 - 
      180*Sqrt[5 - Sqrt[5]]*x^3 - 60*Sqrt[5*(5 - Sqrt[5])]*x^3 - 
      450*Sqrt[5 + Sqrt[5]]*x^3 - 210*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      26832*Sqrt[5 - Sqrt[5]]*x*y + 12000*Sqrt[5*(5 - Sqrt[5])]*x*y - 
      26400*Sqrt[5 - Sqrt[5]]*x^2*y - 11808*Sqrt[5*(5 - Sqrt[5])]*x^2*y + 
      480*Sqrt[5 - Sqrt[5]]*x^3*y + 216*Sqrt[5*(5 - Sqrt[5])]*x^3*y + 
      45*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 + 15*Sqrt[5*(25 - 5*Sqrt[5])]*x^2*y^2 + 
      117*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 39*Sqrt[5*(5 - Sqrt[5])]*x^2*y^2 + 
      342*Sqrt[5 + Sqrt[5]]*x^2*y^2 + 162*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 - 
      18*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 6*Sqrt[5*(25 - 5*Sqrt[5])]*x^3*y^2 - 
      30*Sqrt[5 + Sqrt[5]]*x^3*y^2 - 30*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      48*Sqrt[5 - Sqrt[5]]*x^3*y^3 + 24*Sqrt[5*(5 - Sqrt[5])]*x^3*y^3, 
     42560*Sqrt[2*(25 - 5*Sqrt[5])] + 42560*Sqrt[10*(25 - 5*Sqrt[5])] + 
      95040*Sqrt[2*(5 - Sqrt[5])] + 95040*Sqrt[10*(5 - Sqrt[5])] - 
      467840*Sqrt[2*(5 + Sqrt[5])] - 209280*Sqrt[10*(5 + Sqrt[5])] - 
      34720*Sqrt[2*(25 - 5*Sqrt[5])]*x - 34720*Sqrt[10*(25 - 5*Sqrt[5])]*x - 
      78080*Sqrt[2*(5 - Sqrt[5])]*x - 78080*Sqrt[10*(5 - Sqrt[5])]*x + 
      79360*Sqrt[2*(5 + Sqrt[5])]*x + 34880*Sqrt[10*(5 + Sqrt[5])]*x + 
      28920*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 28920*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2 + 65400*Sqrt[2*(5 - Sqrt[5])]*x^2 + 65400*Sqrt[10*(5 - Sqrt[5])]*
       x^2 + 71600*Sqrt[2*(5 + Sqrt[5])]*x^2 + 32880*Sqrt[10*(5 + Sqrt[5])]*
       x^2 - 3900*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 
      3900*Sqrt[10*(25 - 5*Sqrt[5])]*x^3 - 8900*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      8900*Sqrt[10*(5 - Sqrt[5])]*x^3 - 9800*Sqrt[2*(5 + Sqrt[5])]*x^3 - 
      4600*Sqrt[10*(5 + Sqrt[5])]*x^3 + 456320*Sqrt[2*(5 - Sqrt[5])]*x*y + 
      204160*Sqrt[10*(5 - Sqrt[5])]*x*y - 273600*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y - 122560*Sqrt[10*(5 - Sqrt[5])]*x^2*y + 35200*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y + 15840*Sqrt[10*(5 - Sqrt[5])]*x^3*y - 
      2440*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y^2 - 2440*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^2*y^2 - 6120*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 
      6120*Sqrt[10*(5 - Sqrt[5])]*x^2*y^2 - 16720*Sqrt[2*(5 + Sqrt[5])]*x^2*
       y^2 - 7760*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 - 
      340*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 340*Sqrt[10*(25 - 5*Sqrt[5])]*
       x^3*y^2 - 1100*Sqrt[2*(5 - Sqrt[5])]*x^3*y^2 - 
      1100*Sqrt[10*(5 - Sqrt[5])]*x^3*y^2 - 600*Sqrt[2*(5 + Sqrt[5])]*x^3*
       y^2 - 680*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 + 3520*Sqrt[2*(5 - Sqrt[5])]*
       x^3*y^3 + 1760*Sqrt[10*(5 - Sqrt[5])]*x^3*y^3, 
     480*Sqrt[25 - 5*Sqrt[5]] - 960*Sqrt[5 - Sqrt[5]] - 
      1200*Sqrt[5 + Sqrt[5]] + 240*Sqrt[5*(5 + Sqrt[5])] - 
      3990*Sqrt[25 - 5*Sqrt[5]]*x - 3510*Sqrt[5 - Sqrt[5]]*x + 
      2700*Sqrt[5 + Sqrt[5]]*x - 1440*Sqrt[5*(5 + Sqrt[5])]*x + 
      1560*Sqrt[25 - 5*Sqrt[5]]*x^2 + 2340*Sqrt[5 - Sqrt[5]]*x^2 - 
      210*Sqrt[5 + Sqrt[5]]*x^2 - 30*Sqrt[5*(5 + Sqrt[5])]*x^2 + 
      15*Sqrt[25 - 5*Sqrt[5]]*x^3 - 165*Sqrt[5 - Sqrt[5]]*x^3 - 
      300*Sqrt[5 + Sqrt[5]]*x^3 + 150*Sqrt[5*(5 + Sqrt[5])]*x^3 + 
      630*Sqrt[25 - 5*Sqrt[5]]*x*y + 2970*Sqrt[5 - Sqrt[5]]*x*y + 
      630*Sqrt[5 + Sqrt[5]]*x*y - 450*Sqrt[5*(5 + Sqrt[5])]*x*y + 
      660*Sqrt[25 - 5*Sqrt[5]]*x^2*y + 780*Sqrt[5 - Sqrt[5]]*x^2*y - 
      60*Sqrt[5 + Sqrt[5]]*x^2*y + 180*Sqrt[5*(5 + Sqrt[5])]*x^2*y + 
      15*Sqrt[25 - 5*Sqrt[5]]*x^3*y + 45*Sqrt[5 - Sqrt[5]]*x^3*y - 
      75*Sqrt[5 + Sqrt[5]]*x^3*y + 45*Sqrt[5*(5 + Sqrt[5])]*x^3*y - 
      318*Sqrt[25 - 5*Sqrt[5]]*x^2*y^2 - 930*Sqrt[5 - Sqrt[5]]*x^2*y^2 + 
      210*Sqrt[5 + Sqrt[5]]*x^2*y^2 - 102*Sqrt[5*(5 + Sqrt[5])]*x^2*y^2 + 
      24*Sqrt[25 - 5*Sqrt[5]]*x^3*y^2 - 90*Sqrt[5 - Sqrt[5]]*x^3*y^2 - 
      225*Sqrt[5 + Sqrt[5]]*x^3*y^2 + 105*Sqrt[5*(5 + Sqrt[5])]*x^3*y^2 + 
      3*Sqrt[25 - 5*Sqrt[5]]*x^3*y^3 + 15*Sqrt[5 - Sqrt[5]]*x^3*y^3 - 
      60*Sqrt[5 + Sqrt[5]]*x^3*y^3 + 30*Sqrt[5*(5 + Sqrt[5])]*x^3*y^3, 
     -20480*Sqrt[2*(25 - 5*Sqrt[5])] - 163840*Sqrt[2*(5 - Sqrt[5])] + 
      112640*Sqrt[2*(5 + Sqrt[5])] + 92160*Sqrt[10*(5 + Sqrt[5])] - 
      78080*Sqrt[2*(25 - 5*Sqrt[5])]*x - 398080*Sqrt[2*(5 - Sqrt[5])]*x - 
      270080*Sqrt[2*(5 + Sqrt[5])]*x + 108800*Sqrt[10*(5 + Sqrt[5])]*x + 
      8320*Sqrt[2*(25 - 5*Sqrt[5])]*x^2 + 200320*Sqrt[2*(5 - Sqrt[5])]*x^2 + 
      197120*Sqrt[2*(5 + Sqrt[5])]*x^2 - 70400*Sqrt[10*(5 + Sqrt[5])]*x^2 - 
      320*Sqrt[2*(25 - 5*Sqrt[5])]*x^3 - 29120*Sqrt[2*(5 - Sqrt[5])]*x^3 - 
      24000*Sqrt[2*(5 + Sqrt[5])]*x^3 + 11840*Sqrt[10*(5 + Sqrt[5])]*x^3 + 
      72704*Sqrt[2*(25 - 5*Sqrt[5])]*x*y + 151040*Sqrt[2*(5 - Sqrt[5])]*x*y - 
      80640*Sqrt[2*(5 + Sqrt[5])]*x*y + 27392*Sqrt[10*(5 + Sqrt[5])]*x*y - 
      26880*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*y + 32000*Sqrt[2*(5 - Sqrt[5])]*x^2*
       y + 88320*Sqrt[2*(5 + Sqrt[5])]*x^2*y - 65280*Sqrt[10*(5 + Sqrt[5])]*
       x^2*y + 2560*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y + 
      13440*Sqrt[2*(5 - Sqrt[5])]*x^3*y - 6080*Sqrt[2*(5 + Sqrt[5])]*x^3*y + 
      3520*Sqrt[10*(5 + Sqrt[5])]*x^3*y - 1024*Sqrt[2*(25 - 5*Sqrt[5])]*x^2*
       y^2 - 62720*Sqrt[2*(5 - Sqrt[5])]*x^2*y^2 - 8320*Sqrt[2*(5 + Sqrt[5])]*
       x^2*y^2 + 4224*Sqrt[10*(5 + Sqrt[5])]*x^2*y^2 + 
      2752*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*y^2 - 14400*Sqrt[2*(5 - Sqrt[5])]*x^3*
       y^2 - 17920*Sqrt[2*(5 + Sqrt[5])]*x^3*y^2 + 
      8320*Sqrt[10*(5 + Sqrt[5])]*x^3*y^2 - 64*Sqrt[2*(25 - 5*Sqrt[5])]*x^3*
       y^3 + 5440*Sqrt[2*(5 - Sqrt[5])]*x^3*y^3 - 4800*Sqrt[2*(5 + Sqrt[5])]*
       x^3*y^3 + 2368*Sqrt[10*(5 + Sqrt[5])]*x^3*y^3}
