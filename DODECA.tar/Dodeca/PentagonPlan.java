import java.applet.Applet;
import java.awt.event.*;
import java.awt.*;

public class PentagonPlan {

    public static PolyFlip[] main() {
	Color[] COL={new Color(50,100,255),new Color(200,0,200),new Color(255,80,0),new Color(0,200,0),new Color(255,180,0)};
	PolyFlip HOME=new PolyFlip(5,1,0,0,new Complex(0,0),0,1,COL);
	PolyFlip[] POLY=new PolyFlip[26];
				   
	int count=0;
	POLY[0]=new PolyFlip(HOME);
	count=1;
	for(int i=0;i<5;++i) {
	    POLY[count]=HOME.flip(i);
	    ++count;
	}

	for(int i=0;i<5;++i) {
	    for(int j=0;j<5;++j) {
	      if(nonAdjacent(i,j)==true) {
		PolyFlip Q=new PolyFlip(HOME);
		Q=Q.flip(i);
		Q=Q.flip(j);
		POLY[count]=Q;
		++count;
	      }
	    }
	}

	for(int i=0;i<5;++i) {
	    for(int j=0;j<5;++j) {
		for(int k=0;k<5;++k) {
		    if((i!=k)&&(nonAdjacent(i,j)==true)&&(nonAdjacent(j,k)==true)) {
		        PolyFlip Q=new PolyFlip(HOME);
		        Q=Q.flip(i);
		        Q=Q.flip(j);
		        Q=Q.flip(k);
		        POLY[count]=Q;
		        ++count;
		    }
		}
	    }
	}

	POLY[24].a[1]=1;
	POLY[25].a[1]=2;
	POLY[22].a[1]=3;
	POLY[23].a[1]=4;
	POLY[21].a[1]=0;
	POLY[20].a[1]=1;
	POLY[18].a[1]=2;
	POLY[19].a[1]=3;
	POLY[16].a[1]=4;
	POLY[17].a[1]=0;

	for(int i=1;i<6;++i) {
	    for(int j=0;j<5;++j) {
		POLY[i].COL[j]=new Color(180,180,180);
	    }
	}
	for(int i=6;i<16;++i) {
	    for(int j=0;j<5;++j) {
		POLY[i].COL[j]=new Color(120,120,120);
	    }
	}

	
	POLY[0].a[1]=3;

	int[] y={24,25,22,23,21,20,18,19,16,17};
	PolyFlip[] POLY2=new PolyFlip[10];
	for(int i=0;i<10;++i) POLY2[i]=new PolyFlip(POLY[y[i]]);
	for(int i=16;i<26;++i) POLY[i]=new PolyFlip(POLY2[i-16]);

	return POLY;
    }

    public static boolean nonAdjacent(int i,int j) {
	int t=(i-j+5)%5;
	if(t==2) return true;
	if(t==3) return true;
	return false;
    }


}
