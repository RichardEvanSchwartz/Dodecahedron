import java.awt.*;

public class PopupFormulaCanvas extends PopupPanel {
    FormulaCanvas X;

    public PopupFormulaCanvas() {
        super("Formula Window", 800,500);
        X=new FormulaCanvas();
        X.setSize(800,500);
        add(X);
        X.setBackground(Color.black);
        setVisible(true);
        F.setSize(800,500);
    }

    public void resized(int w, int h){
	try {X.setSize(w,h);}
	catch(Exception e) {}
    }
    
}
