import java.awt.*;

public class PopupPictureCanvas extends PopupPanel {
    PictureCanvas P;

    public PopupPictureCanvas(int type) {
        super("Picture Window", 500,500);
        P=new PictureCanvas(type);
        P.setSize(500,500);
        add(P);
        P.setBackground(Color.black);
        setVisible(true);
        F.setSize(500,500);
    }

    public void resized(int w, int h){
	try {P.setSize(w,h);}
	catch(Exception e) {}
    }
    
}
