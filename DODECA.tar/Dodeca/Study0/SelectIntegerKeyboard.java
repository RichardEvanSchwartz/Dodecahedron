import java.applet.Applet;
import java.awt.event.*;
import java.awt.*;
import java.awt.geom.*;

/*This is a basic class for a rectangular integer entry button*/

public class SelectIntegerKeyboard {
    double x,y,w,h;
    int val,on;
    Font FONT;
    int limit;

    /*rectangle*/

    public SelectIntegerKeyboard(double x,double y,double w,double h,int val) {
	this.x=x;
	this.y=y;
	this.w=w;
	this.h=h;
	this.val=val;
	this.on=0;  
        this.FONT=new Font("Helvetica",Font.PLAIN,11);
	limit=100000;
    }


    public SelectIntegerKeyboard(double x,double y,double w,double h,int val,int lim) {
	this.x=x;
	this.y=y;
	this.w=w;
	this.h=h;
	this.val=val;
	this.on=0;  
        this.FONT=new Font("Helvetica",Font.PLAIN,11);
	this.limit=lim;
    }




    public int inside(Point p) {
        int test=0;
	if((p.x>x)&&(p.x<x+w)&&(p.y>y)&&(p.y<y+h)) test=1;
	return(test);
    }

    /* drawing methods */

    public void render(Graphics g,Color C1,Color C2,Color C3,Color C4) {
	g.setColor(C1);
	g.fillRect((int)(x),(int)(y),(int)(w),(int)(h));
	if(on==0) g.setColor(C2);
	if(on==1) g.setColor(C3);
	g.drawRect((int)(x),(int)(y),(int)(w),(int)(h));
	g.setColor(C4);
	Integer VAL=new Integer(val);
        g.setFont(FONT);
	g.drawString(VAL.toString(),(int)(x+3),(int)(y+h-2));
    }


    public void modify(KeyEvent e) {
            int temp=val;

            if (e.getKeyChar()==KeyEvent.VK_BACK_SPACE) {
                temp=temp/10;
            }

            if (e.getKeyChar()==KeyEvent.VK_DELETE) {
                temp=1;
            }

            int ch=(int)(e.getKeyChar()-'0');
            if ((ch>=0)&&(ch<10)){
		temp=10*temp+ch;
            }
	    val=temp;
	    if(val>limit) val=limit;
    }


    public void modifySign(KeyEvent e) {
            int temp=val;
            char test=e.getKeyChar();

            if (e.getKeyChar()==KeyEvent.VK_BACK_SPACE) {
                temp=temp/10;
            }

            if (e.getKeyChar()==KeyEvent.VK_DELETE) {
                temp=1;
            }

            int ch=(int)(e.getKeyChar()-'0');
            if ((ch>=0)&&(ch<10)){
                temp=10*temp+ch;
            }            
            val=temp;
            if(val>99999999) val=99999999;
            if(test=='-') val=-val;
    }


}
