import java.applet.Applet;
import java.awt.*;
import java.applet.*;
import java.math.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.*;
import java.util.*;


public class Main extends Applet {
    ControlCanvas C;
    PopupPictureCanvas PP0,PP1;
    Manager M;

    public static void main(String[] args) {  
        Main a=new Main();
        Frame F=new Frame();
	a.setBackground(Color.black);
        a.init();
	F.add(a);
	F.pack();
	F.addWindowListener(new WinList(F));
	F.setVisible(true);
    }


    public void init() {  
	C=new ControlCanvas();
	PP0=new PopupPictureCanvas(0);
	PP1=new PopupPictureCanvas(1);
	M=new Manager();
	C.setSize(500,420);
	M.P0=PP0.P;
	M.P1=PP1.P;
	M.C=C;
        C.M=M;
	PP0.P.M=M;
	PP1.P.M=M;
	add(C);
    } 
}

