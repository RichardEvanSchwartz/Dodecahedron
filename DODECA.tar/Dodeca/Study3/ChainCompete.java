import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.geom.*;
import java.math.*;


public class ChainCompete {

    public static Chain getChainBad(int k) {


    int[][] b={{2,1,9,11},{2,10,9,11},{3,2,9,11},{3,10,9,11},{3,2,10,9,11},{4,3,10,9,11},
	       {1,2,9,11},{1,8, 9,11},{5,1,9,11},{5,8, 9,11},{5,1,8, 9,11},{4,5,8, 9,11}};
    int[] B=b[k];
    Chain c=Chain.setChain(B);
    return c;
    }


    public static Chain getChainGood(int k) {
	int[][] b={{2,10,11},{1,9,11},{1,8,11},{5,7,11},{4,6,11},{3,6,11}};

    int[] B=b[k];
    Chain c=Chain.setChain(B);
    return c;
    }


    public static Complex transplant(int[] I,Complex z) {
	Complex rot=Chain.rootOfUnity10(I[5]);
	Complex w=z.conjugate();
	w=Complex.times(w,rot);
	Complex t=NumberRecognizer.integerCombo(I);
	w=Complex.plus(w,t);
	return w;
    }

    public static int[] transplantCodeGood(int i) {
        int[][] t={{0,3,3,1,0,7},{3,3,1,0,0,3},{3,3,0,0,1,1},{3,0,0,1,3,7},{0,0,1,3,3,3},{0,0,3,3,1,1}};
	return t[i];
    }

    
    public static int[] transplantCodeBad(int i) {
	int[][] t={{2,4,3,0,1,4},{1,4,3,2,0,6},{1,3,4,2,0,6},{0,2,4,3,1,8},{2,2,0,3,0,7},{1,0,1,3,0,9},
		   {3,4,2,1,0,4},{3,4,1,0,2,2},{4,3,1,0,2,2},{4,2,0,1,3,0},{0,2,2,0,3,1},{3,2,0,2,0,9}};
	return t[i];
    }




    public static int[] getSequence(int k) {
	int[][] s={{2,1,9,11},{2,10,9,11},{3,2,9,11},{3,10,9,11},{3,2,10,9,11},{4,3,10,9,11},
		    {1,2,9,11},{1,8,9,11}, {5,1,9,11},{5,8,9,11}, {5,1,8,9,11}, {4,5,8,9,11}};
	return s[k];
    }
    
    
}

