import java.awt.*;

/**This class has a few routines for getting the current time.**/

public class Time {

    /**Time in milliseconds**/

    public static long time() {
	long t=System.currentTimeMillis();
	return(t);
    }

    /**Convert to hours, seconds, days**/

    public static void print(String A,long s) {
	String FINAL=toString(A,s);
	System.out.println(FINAL);
    }

    public static String toString(String A,long s) {
	String FINAL="";
	FINAL=FINAL+A;
	long s0=s;
	long t1=s0%1000;        //milliseconds
	long s1=(s0-t1)/1000;
	long t2=s1%60;          //seconds
	long s2=(s1-t2)/60;
	long t3=s2%60;          //minutes
        long s3=(s2-t3)/60;
	long t4=s3;             //hours

	long[] t={t1,t2,t3,t4};
	Integer[] T=new Integer[4];
	for(int i=0;i<4;++i) T[i]=new Integer((int)(t[i]));
	String[] S={"millis","sec","min","hours"};
	for(int i=3;i>-1;--i) {
	    FINAL=FINAL+T[i].toString()+" "+S[i]+"   ";
	}
	return FINAL;
    }

}
